# 数据字典

- `input/historical_panel.csv.gz`：三个结局（measure_id 2 DALYs、6 incidence、1 deaths）的年龄标准化率；`val`单位每十万人。历史范围1990–2020，保留缺失fid记录以复现排除步骤。`absolute_cumulative_heat`为ACH，`relative_cumulative_heat`为RCH，`mixed_cumulative_heat`为MCH；单位°C-days。`SDI`及五个SEV指标是六项原尺度协变量。缺失国家键排除后，每个结局6293行、203国。Côte d’Ivoire地区修补在分析副本中执行。
- `input/natural_forcing_panel.csv.gz`：`ACH_observed`、`ACH_natural_source`、`ACH_natural_calibrated`及其差值。`ACH_natural_calibrated`是实际健康转换所用自然强迫年度暴露；本构造不执行额外国家年度暴露平移。`SDI_group`使用1990–1994固定分组。203国×31年。
- `input/ssp_models_annual.csv.gz`：203国×80年×4情景×3模式。`delta_ACH_vs_reference`为该模型情景ACH减同模型SSP2-4.5在2016–2020年的均值。`ERA5_reference_ACH`为同国ERA5基线，`ACH_era5_anchored_linear`为其加上变化值。负锚定值只解释为有符号指标。`SDI_group_2015_2020`是2015–2020固定基线组。
- `input/ssp_ensemble_annual.csv.gz`：对应三模型等权的国家年度集合，203×80×4行。模式为BCC-CSM2-MR、CanESM5、KACE-1-0-G，各r1i1p1f1。
- `figure_source/F1_three_outcome_*`：当前Figure2的回归摘要和真实残差坐标，文件名前缀沿用旧编号。
- `figure_source/F2_*`、`SF1_*`：当前Figure3/S1的年度观察、国家多年均值、箱体和SDI分箱摘要；每国多年均值是分布检验的单位。
- `figure_source/SDI_boxplot_*`：四项omnibus单独Holm校正；ACH/ASDR/ASIR/ASMR全部12项pairwise另成一个Holm集合。
- `figure_source/S2_lower_minus_higher_SDI.csv`：当前历史零ACH条件率差及低减高组差；系数CI与国家bootstrap区间分列。
- `figure_source/F4_*`：21个源定义GBD地区的自然/人为暴露转换及定位。份额是暴露转换构成，不是观测疾病归因比例。
- `figure_source/F5_*`：主系数的情景条件率差与三模型范围。`F5_gap_change_uniform_windows.csv`使用统一20年窗口，区间由共同系数CI直接转换。

gzip CSV可由pandas或R的gzfile直接读取。对输入仅选择研究所需行列并以17位有效精度写出，没有填补缺失或改变原始定义。`SOURCE_MANIFEST.json`保留原来源文件的SHA-256和选取说明；`FILE_MANIFEST.json`另给实际包内文件校验值。
