# 数据来源

- 心血管结局与协变量：IHME GBD Results Tool，https://vizhub.healthdata.org/gbd-results/ 。原始本地导出使用GBD2021文件标签；作者报告于2025年8月获取，后确认与稿件所引GBD2023数值一致。该核对未附逐条比较文件，原标签不改写。
- ERA5：C3S hourly data on single levels，https://doi.org/10.24381/cds.adbb2d47 。1990–2020，0.25°小时2米气温取日最大值；面积加权国家ACH。30°C，至少连续两天；排除2月29日并中断连续性。
- 自然强迫：BCC-CSM2-MR r1i1p1f1，historical v20201019、hist-nat v20190426、SSP2-4.5 v20190318；1990–2014 historical + 2015–2020 SSP245，与1990–2020 hist-nat比较。月空间信号按平滑年度幅度缩放，减去ERA5后重算ACH。
- BCC集合：historical https://doi.org/10.22033/ESGF/CMIP6.2948 ，hist-nat https://doi.org/10.22033/ESGF/CMIP6.2929 ，ssp245 https://doi.org/10.22033/ESGF/CMIP6.3030 。五个自然强迫文件的跟踪ID及SHA256曾与官方记录核验。
- SSP：BCC-CSM2-MR、CanESM5、KACE-1-0-G；每个模式r1i1p1f1；SSP126/245/370/585。ESGF https://esgf.llnl.gov/ 。未来输入发布候选：BCC SSP126 v20190315，其余BCC SSP v20190318；CanESM5 v20190429；KACE v20200317。并非所有未来文件版本都完成独立字节认证，模式间范围不表示概率预测区间。
- KACE 360日日历先将日温插值到365日再计算阈值事件。BCC和KACE末年缺少2101年向前查看资料，该边界限制保留。

本包输入从现有已采用年度数据中选取，不包含大规模日NetCDF、WorldPop未采用敏感性栅格或未来发展代理。没有把修改日期作为真实下载日期。
