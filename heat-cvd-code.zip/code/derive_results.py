"""Recompute key conditional summaries and exploratory country-mean comparisons."""
from pathlib import Path
import itertools,json
import numpy as np
import pandas as pd
from scipy.stats import kruskal,mannwhitneyu
from statsmodels.stats.multitest import multipletests
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data';OUT=ROOT/'results/derived';OUT.mkdir(parents=True,exist_ok=True)
coef=pd.read_csv(DATA/'figure_source/F1_three_outcome_models.csv').set_index('metric').loc['ASDR']
beta,lo,hi=coef[['beta','ci_low','ci_high']]
raw=pd.read_csv(DATA/'input/historical_panel.csv.gz');d=raw[raw.measure_id.eq(2)&raw.fid.notna()].copy()
base=d[d.year.between(1990,1994)].groupby('fid').SDI.mean();cut=base.quantile([0,1/3,2/3,1]).to_numpy();group=pd.cut(base,cut,labels=['Low','Middle','High'],include_lowest=True);d['group']=d.fid.map(group)
assert d.groupby('group',observed=True).fid.nunique().tolist()==[68,67,68]
historical=[]
for g in ['Low','Middle','High']:
 x=d[d.group.eq(g)].absolute_cumulative_heat.mean();historical.append(dict(group=g,mean_ACH=x,rate_difference=beta*x,ci_low=lo*x,ci_high=hi*x))
pd.DataFrame(historical).to_csv(OUT/'historical_reference0.csv',index=False)
n=pd.read_csv(DATA/'input/natural_forcing_panel.csv.gz');assert len(n)==6293
np.testing.assert_allclose(n.ACH_observed-n.ACH_natural_calibrated,n.delta_ACH_anthropogenic,atol=1e-8)
x=n.delta_ACH_anthropogenic.mean();pd.DataFrame([dict(mean_ACH_contrast=x,rate_difference=beta*x,ci_low=lo*x,ci_high=hi*x)]).to_csv(OUT/'natural_forcing_overall.csv',index=False)
a=pd.read_csv(DATA/'input/ssp_ensemble_annual.csv.gz');model=pd.read_csv(DATA/'input/ssp_models_annual.csv.gz')
assert len(a)==203*80*4 and len(model)==203*80*4*3
m=model.groupby(['fid','year','ssp']).delta_ACH_vs_reference.mean();o=a.set_index(['fid','year','ssp']).delta_ACH_vs_reference;np.testing.assert_allclose(m.sort_index(),o.sort_index(),atol=1e-9)
periods=[(2041,2060),(2081,2100)];rows=[];gaprows=[]
for ssp in sorted(a.ssp.unique()):
 gaps=[]
 for start,end in periods:
  z=a[a.ssp.eq(ssp)&a.year.between(start,end)];x=z.delta_ACH_vs_reference.mean();rows.append(dict(ssp=ssp,period=f'{start}-{end}',delta_ACH_vs_reference=x,DALYs_rate_difference_primary=beta*x,DALYs_primary_ci_low=lo*x,DALYs_primary_ci_high=hi*x))
  means=z.groupby('SDI_group_2015_2020').delta_ACH_vs_reference.mean();gaps.append(means.Low-means.High)
 x=gaps[1]-gaps[0];gaprows.append(dict(ssp=ssp,rate_gap_change=beta*x,ci_low=min(lo*x,hi*x),ci_high=max(lo*x,hi*x)))
r=pd.DataFrame(rows);ref=pd.read_csv(DATA/'figure_source/F5_overall.csv');j=r.merge(ref,on=['ssp','period'],suffixes=('_new','_saved'),validate='one_to_one')
for k in ['delta_ACH_vs_reference','DALYs_rate_difference_primary','DALYs_primary_ci_low','DALYs_primary_ci_high']:np.testing.assert_allclose(j[k+'_new'],j[k+'_saved'],atol=1e-7,rtol=1e-9)
r.to_csv(OUT/'ssp_period_summaries.csv',index=False);gap=pd.DataFrame(gaprows);ref=pd.read_csv(DATA/'figure_source/F5_gap_change_uniform_windows.csv').set_index('ssp')
for row in gap.itertuples():
 for k in ['rate_gap_change','ci_low','ci_high']:assert np.isclose(getattr(row,k),ref.loc[row.ssp,k],atol=1e-8)
gap.to_csv(OUT/'ssp_gap_change.csv',index=False)
means=pd.read_csv(DATA/'figure_source/F2_SF1_country_means.csv');pair=[];omni=[]
for metric in ['ACH','ASDR','ASIR','ASMR']:
 z=means[means.metric.eq(metric)];v={g:z[z.group.eq(g)].value.to_numpy() for g in ['Low','Middle','High']};assert sum(map(len,v.values()))==203
 k=kruskal(*v.values());omni.append(dict(metric=metric,H=k.statistic,p_raw=k.pvalue))
 for g1,g2 in itertools.combinations(v,2):
  x=mannwhitneyu(v[g1],v[g2],alternative='two-sided',method='asymptotic',use_continuity=True);pair.append(dict(metric=metric,group1=g1,group2=g2,U=x.statistic,p_raw=x.pvalue))
pair=pd.DataFrame(pair);pair['p_holm']=multipletests(pair.p_raw,method='holm')[1];ref=pd.read_csv(DATA/'figure_source/SDI_boxplot_pairwise_tests.csv');j=pair.merge(ref,on=['metric','group1','group2'],suffixes=('_new','_saved'),validate='one_to_one')
np.testing.assert_allclose(j.p_holm_new,j.p_holm_saved,rtol=1e-7,atol=1e-14)
omni=pd.DataFrame(omni);omni['p_holm']=multipletests(omni.p_raw,method='holm')[1];pair.to_csv(OUT/'pairwise_tests.csv',index=False);omni.to_csv(OUT/'omnibus_tests.csv',index=False)
print('Historical, natural-forcing, SSP and exploratory test summaries reproduced.')
