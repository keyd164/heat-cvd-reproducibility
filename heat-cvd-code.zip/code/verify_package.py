from pathlib import Path
import hashlib,json,ast
ROOT=Path(__file__).resolve().parents[1]
manifest=json.loads((ROOT/'FILE_MANIFEST.json').read_text('utf-8'))
for entry in manifest['files']:
 p=ROOT/entry['path'];assert p.is_file(),p
 assert hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256'],p
for p in (ROOT/'code').rglob('*.py'):ast.parse(p.read_text('utf-8-sig'),filename=str(p))
print(f"Verified {len(manifest['files'])} files and Python syntax.")
