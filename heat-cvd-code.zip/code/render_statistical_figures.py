"""Render adjusted associations and saved historical/natural contrast intervals."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'data/figure_source';O=ROOT/'results/figures';O.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
def save(fig,name):
 fig.tight_layout()
 for ext in ['png','pdf','svg']:fig.savefig(O/f'{name}.{ext}',dpi=300)
 plt.close(fig)
r=pd.read_csv(D/'F1_three_outcome_residuals.csv');c=pd.read_csv(D/'F1_three_outcome_models.csv').set_index('metric')
fig=plt.figure(figsize=(7.2,5));gs=fig.add_gridspec(2,2,width_ratios=[1.7,1]);axes=[fig.add_subplot(gs[:,0]),fig.add_subplot(gs[0,1]),fig.add_subplot(gs[1,1])]
for ax,metric,tag in zip(axes,['ASDR','ASIR','ASMR'],'abc'):
 z=r[r.metric.eq(metric)];v=c.loc[metric];ax.scatter(z.ACH_residual,z.rate_residual,s=2,alpha=.12,rasterized=True)
 x=np.linspace(z.ACH_residual.min(),z.ACH_residual.max(),200);bounds=np.sort(np.stack([x*v.ci_low,x*v.ci_high]),axis=0);ax.plot(x,x*v.beta);ax.fill_between(x,*bounds,alpha=.15)
 ax.set(xlabel='ACH residual (°C-days)',ylabel=f'{metric} residual (per 100,000)',title=f'{tag}  {metric}');ax.text(.04,.96,f'β = {v.beta:.3f}\nP = {v.p_value:.3g}',transform=ax.transAxes,va='top')
save(fig,'F2')
z=pd.read_csv(D/'S2_lower_minus_higher_SDI.csv');fig,axs=plt.subplots(1,2,figsize=(7.2,3.4))
for ax,panel in zip(axs,['a','b']):
 q=z[z.panel.eq(panel)].reset_index(drop=True)
 for i,v in q.iterrows():
  for dy,col,marker,low,high in [(-.07,'#326F87','o',v.coefficient_ci_low,v.coefficient_ci_high),(.07,'#A4ACB1','s',v.bootstrap_ci_low,v.bootstrap_ci_high)]:ax.errorbar(v.rate_difference,i+dy,xerr=[[v.rate_difference-low],[high-v.rate_difference]],fmt=marker,color=col,capsize=2)
 ax.set(yticks=range(len(q)),yticklabels=q.group.str.replace('_',' '),xlabel='Conditional DALYs rate contrast (per 100,000)');ax.invert_yaxis();ax.axvline(0,color='grey',lw=.6)
save(fig,'S2')
n=pd.read_csv(ROOT/'data/reference/natural_ach__main_result_table.csv');v=n[n.summary.eq('overall_1990_2020')&n.specification.eq('primary_TWFE')].iloc[0]
fig,ax=plt.subplots(figsize=(6,2))
for y,col,marker,low,high in [(0,'#326F87','o',v.coefficient_ci_low,v.coefficient_ci_high),(.2,'#A4ACB1','s',v.bootstrap_rate_low,v.bootstrap_rate_high)]:ax.errorbar(v.rate_difference,y,xerr=[[v.rate_difference-low],[high-v.rate_difference]],fmt=marker,color=col,capsize=3)
ax.set(yticks=[],xlabel='Conditional DALYs rate contrast (per 100,000)',ylim=(-.5,.7));ax.axvline(0,color='grey',lw=.6);save(fig,'S3')
print('F2, S2 and S3 rendered. Intervals retain their distinct coefficient/bootstrap meanings.')
