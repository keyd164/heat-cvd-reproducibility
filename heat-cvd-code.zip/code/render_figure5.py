from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
import xml.etree.ElementTree as ET

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.lines import Line2D
from matplotlib.ticker import FuncFormatter, MultipleLocator
import numpy as np
import pandas as pd
from PIL import Image
import tifffile


PROJECT = Path(__file__).resolve().parents[1]
OUT = PROJECT / 'results/figures'
OUT.mkdir(parents=True,exist_ok=True)
FIG_DATA = PROJECT / 'data/figure_source'
ANNUAL_DIR = PROJECT / 'data/input'
ANNUAL_SUMMARY = ANNUAL_DIR / "ssp_ensemble_annual.csv.gz"
ANNUAL_MODELS = ANNUAL_DIR / "ssp_models_annual.csv.gz"
D_GAP_QA = PROJECT / 'data/reference/figure5_gap_definition.json'
SOURCE_FILES = {
    "overall": FIG_DATA / "F5_overall.csv",
    "groups": FIG_DATA / "F5_groups.csv",
    "gaps": FIG_DATA / "F5_gaps.csv",
    "model_ranges": FIG_DATA / "F5_model_ranges.csv",
    "annual_summary": ANNUAL_SUMMARY,
    "annual_models": ANNUAL_MODELS,
}

SCENARIOS = ["ssp126", "ssp245", "ssp370", "ssp585"]
SCENARIO_LABELS = {
    "ssp126": "SSP1-2.6",
    "ssp245": "SSP2-4.5",
    "ssp370": "SSP3-7.0",
    "ssp585": "SSP5-8.5",
}
PERIODS = ["2041-2060", "2081-2100"]
SDI_GROUPS = ["Low", "Middle", "High"]
PERIOD_LABELS = ["2041–2060", "2081–2100"]
COLORS = {
    "scenarios": {
    "ssp126": "#6F9D98",
    "ssp245": "#527F9B",
    "ssp370": "#B18A55",
    "ssp585": "#B86B52",
    },
    "ink": "#243A43",
    "muted": "#66777D",
    "axis": "#AAB7B9",
    "grid": "#E1E7E8",
    "period_mid": "#EDF3F1",
    "period_late": "#F5EEE8",
    "ci": "#30454D",
    "heatmap_low": "#F3F5F3",
    "heatmap_mid": "#D5DFD7",
    "heatmap_high": "#527F7B",
}
TYPOGRAPHY = {"title": 9.2, "panel": 8.0, "axis": 7.3, "tick": 6.8, "value": 7.5, "note": 6.3}
SPACING = {"left": 0.075, "right": 0.975, "bottom": 0.18, "top": 0.94, "hspace": 0.58, "wspace": 0.28}
LINEWIDTHS = {"trend": 1.6, "ci": 1.2, "zero": 0.95, "grid": 0.5}
MARKERS = {"trend_end": 2.6, "estimate": 3.1, "ci_cap": 2.8}
LINESTYLES = {"ssp126": "-", "ssp245": (0, (4.0, 1.6)), "ssp370": (0, (1.4, 1.4)), "ssp585": (0, (5.0, 1.5, 1.2, 1.5))}
EXPORT = {"width_in": 7.0, "height_in": 5.18, "preview_dpi": 220, "tiff_dpi": 600}
HEALTH_CMAP = LinearSegmentedColormap.from_list(
    "conditional_rate", ["#F3F5F3", "#E2E9E5", "#AABFBB", "#527F7B"]
)
ACH_CMAP = LinearSegmentedColormap.from_list(
    "ach_increment", [COLORS["heatmap_low"], COLORS["heatmap_mid"], "#AEBB96", COLORS["heatmap_high"]]
)
SCENARIO_COLORS = COLORS["scenarios"]
INK, MUTED, GRID = COLORS["ink"], COLORS["muted"], COLORS["grid"]

plt.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
        "font.size": TYPOGRAPHY["tick"],
        "axes.labelsize": TYPOGRAPHY["axis"],
        "axes.titlesize": TYPOGRAPHY["panel"],
        "xtick.labelsize": TYPOGRAPHY["tick"],
        "ytick.labelsize": TYPOGRAPHY["tick"],
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.linewidth": 0.65,
        "legend.frameon": False,
        "figure.facecolor": "white",
        "axes.facecolor": "white",
        "savefig.facecolor": "white",
    }
)

checks: list[dict] = []
input_hashes: dict[str, str] = {}


def check(name: str, passed: bool, detail: str | None = None) -> None:
    checks.append({"check": name, "passed": bool(passed), "detail": detail})
    if not passed:
        raise AssertionError(f"{name}: {detail or 'failed'}")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_csv(key: str) -> pd.DataFrame:
    path = SOURCE_FILES[key]
    check(f"input exists: {key}", path.is_file(), str(path))
    input_hashes[str(path)] = sha256(path)
    return pd.read_csv(path)


def check_unique_grid(frame: pd.DataFrame, keys: list[str], expected: int, name: str) -> None:
    check(f"{name} row count", len(frame) == expected, f"observed={len(frame)}, expected={expected}")
    check(f"{name} unique keys", not frame.duplicated(keys).any(), ",".join(keys))


def panel_letter(ax, letter: str) -> None:
    return ax.text(
        -0.09,
        1.035,
        letter,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=11,
        fontweight="bold",
        color=INK,
        clip_on=False,
    )


def panel_title(ax, title: str) -> None:
    ax.set_title(title, loc="left", fontsize=TYPOGRAPHY["panel"], fontweight="semibold",
                 color=INK, pad=8)


def clean_axis(ax) -> None:
    ax.tick_params(length=2.5, width=0.6, colors=INK, pad=3)
    ax.spines["left"].set_color("#8D9A9E")
    ax.spines["bottom"].set_color("#8D9A9E")
    ax.grid(axis="x", color=GRID, linewidth=0.55, zorder=0)


def matrix_cell(ax, x: float, y: float, estimate: float, low: float, high: float,
                norm: Normalize, cell_width: float, value_color: str) -> None:
    # Each miniature CI uses the same 0–1800 scale across panels b and d.
    x0, x1 = 0.08, 0.92
    left = x + cell_width * x0
    width = cell_width * (x1 - x0)
    ax.plot(
        [left, left + width], [y + 0.19, y + 0.19],
        color="#AAB7B9", linewidth=0.65, zorder=3,
    )
    lo_x = left + width * norm(low)
    hi_x = left + width * norm(high)
    est_x = left + width * norm(estimate)
    ax.plot([lo_x, hi_x], [y + 0.19, y + 0.19], color=INK, linewidth=1.35,
            solid_capstyle="round", zorder=4)
    ax.plot([lo_x, lo_x], [y + 0.145, y + 0.235], color=INK, linewidth=0.8, zorder=4)
    ax.plot([hi_x, hi_x], [y + 0.145, y + 0.235], color=INK, linewidth=0.8, zorder=4)
    ax.plot(est_x, y + 0.19, marker="o", markersize=3.1, color=INK, zorder=5)
    ax.text(x + cell_width / 2, y - 0.14, f"{estimate:,.0f}", ha="center", va="center",
            fontsize=8.5, fontweight="bold", color=value_color, zorder=6)


def validate_inputs(overall, groups, gaps, model_ranges, annual, annual_models):
    # Four scenarios and the two author-registered windows.
    check("four SSP scenarios", set(overall.ssp.unique()) == set(SCENARIOS))
    check("overall includes both registered display periods",
          set(PERIODS).issubset(set(overall.period.unique())))
    check_unique_grid(overall, ["ssp", "period"], len(overall), "overall source")
    check("group grid", set(groups.ssp.unique()) == set(SCENARIOS)
          and set(groups.period.unique()) == set(PERIODS)
          and set(groups.SDI_group_2015_2020.unique()) == set(SDI_GROUPS),
          f"rows={len(groups)}")
    check_unique_grid(groups, ["ssp", "period", "SDI_group_2015_2020"], 24, "groups")
    check("gap grid", set(gaps.ssp.unique()) == set(SCENARIOS)
          and set(gaps.period.unique()) == set(PERIODS)
          and "Low_minus_High" in set(gaps.contrast.unique()),
          f"contrasts={sorted(gaps.contrast.unique())}")
    check_unique_grid(gaps, ["ssp", "period", "contrast"], len(gaps), "gaps source")
    gaps_display = gaps[gaps.contrast.eq("Low_minus_High")]
    check_unique_grid(gaps_display, ["ssp", "period"], 8, "low-high displayed subset")
    check("three-model ranges", len(model_ranges) == 8
          and set(model_ranges.ssp.unique()) == set(SCENARIOS)
          and set(model_ranges.period.unique()) == set(PERIODS),
          f"rows={len(model_ranges)}")
    check("ACH units are degC_days", set(annual.unit.dropna().unique()) == {"degC_days"})
    check("annual years 2021–2100", annual.year.min() == 2021 and annual.year.max() == 2100
          and annual.year.nunique() == 80)
    check("annual scenario grid", set(annual.ssp.unique()) == set(SCENARIOS))
    check_unique_grid(annual, ["fid", "year", "ssp"], 64_960, "annual summary")
    check("203 countries in annual source", annual.fid.nunique() == 203)
    check("three model identities", set(annual_models.model.unique())
          == {"BCC-CSM2-MR", "CanESM5", "KACE-1-0-G"})
    check("single registered member", set(annual_models.member.unique()) == {"r1i1p1f1"})
    check_unique_grid(annual_models, ["fid", "year", "ssp", "model", "member"],
                      194_880, "annual model source")
    check("annual SSP period reference", set(annual.reference_period.unique()) == {"2016-2020"}
          and set(annual.reference_scenario.unique()) == {"ssp245"})
    check("period definitions are the registered 20-year windows",
          set(PERIODS) == {"2041-2060", "2081-2100"})
    check("group counts remain fixed", set(groups.n_countries.unique()) == {67, 68})
    check("group intervals are coefficient-only",
          set(groups.interval_scope.unique()) == {"coefficient_only_not_country_sampling_or_total_uncertainty"})
    check("gap intervals are coefficient-only",
          set(gaps.interval_scope.unique()) == {"coefficient_only_not_country_sampling_or_total_uncertainty"})
    numeric_columns = {
        "overall": (overall, ["delta_ACH_vs_reference", "DALYs_rate_difference_primary",
                              "DALYs_primary_ci_low", "DALYs_primary_ci_high"]),
        "groups": (groups, ["delta_ACH_vs_reference", "DALYs_rate_difference_primary",
                            "DALYs_primary_ci_low", "DALYs_primary_ci_high"]),
        "gaps": (gaps, ["delta_ACH_vs_reference", "DALYs_rate_difference_primary",
                        "DALYs_primary_ci_low", "DALYs_primary_ci_high"]),
        "annual": (annual, ["delta_ACH_vs_reference"]),
    }
    for name, (frame, columns) in numeric_columns.items():
        check(f"{name} finite numeric inputs", np.isfinite(frame[columns].to_numpy()).all())
    for name, frame in [("overall", overall), ("groups", groups), ("gaps", gaps)]:
        check(f"{name} CI bounds contain estimate",
              (frame.DALYs_primary_ci_low <= frame.DALYs_rate_difference_primary).all()
              and (frame.DALYs_primary_ci_high >= frame.DALYs_rate_difference_primary).all())
    check("all displayed health contrasts are positive",
          (overall.DALYs_rate_difference_primary > 0).all()
          and (gaps.DALYs_rate_difference_primary > 0).all())
    # Validate the stored country-year ensemble against the registered model-level table.
    model_yearly = (annual_models.groupby(["year", "ssp"], as_index=False)
                    .agg(model_mean=("delta_ACH_vs_reference", "mean")))
    summary_yearly = (annual.groupby(["year", "ssp"], as_index=False)
                      .agg(summary_mean=("delta_ACH_vs_reference", "mean")))
    compare = summary_yearly.merge(model_yearly, on=["year", "ssp"], validate="one_to_one")
    check("annual ensemble matches model-level source",
          np.allclose(compare.summary_mean, compare.model_mean, rtol=0, atol=1e-9),
          f"max_abs_diff={float(np.max(np.abs(compare.summary_mean-compare.model_mean))):.3g}")
    expected_ranges = []
    for ssp in SCENARIOS:
        for period in PERIODS:
            start, end = [int(x) for x in period.split("-")]
            q = annual_models[annual_models.ssp.eq(ssp)
                              & annual_models.year.between(start, end)]
            model_means = q.groupby("model").delta_ACH_vs_reference.mean()
            expected_ranges.append({
                "ssp": ssp,
                "period": period,
                "model_min": float(model_means.min()),
                "model_max": float(model_means.max()),
            })
    expected_ranges = pd.DataFrame(expected_ranges)
    range_check = model_ranges.merge(expected_ranges, on=["ssp", "period"],
                                     suffixes=("_registered", "_annual"),
                                     validate="one_to_one")
    check("registered three-model period ranges match annual model source",
          np.allclose(range_check.model_min_registered, range_check.model_min_annual, atol=1e-9)
          and np.allclose(range_check.model_max_registered, range_check.model_max_annual, atol=1e-9))
    return compare


def main():
    overall = read_csv("overall")
    groups = read_csv("groups")
    gaps = read_csv("gaps")
    model_ranges = read_csv("model_ranges")
    annual = read_csv("annual_summary")
    annual_models = read_csv("annual_models")
    check("Panel D candidate QA exists", D_GAP_QA.is_file(), str(D_GAP_QA))
    input_hashes[str(D_GAP_QA)] = sha256(D_GAP_QA)
    d_qa = json.loads(D_GAP_QA.read_text(encoding="utf-8"))
    check("Panel D author-requested period convention", d_qa.get("status") == "author_requested_uniform_windows")
    check("Panel D low-minus-high direction", d_qa.get("contrast_direction", "").startswith("Low_minus_High"))
    check("Panel D expected SSP set", {r.get("ssp") for r in d_qa.get("scenario_estimates", [])} == set(SCENARIOS))
    check("Panel D requested inclusive windows",
          d_qa.get("periods", {}).get("mid", {}).get("start") == 2041
          and d_qa.get("periods", {}).get("mid", {}).get("end") == 2060
          and d_qa.get("periods", {}).get("late", {}).get("start") == 2081
          and d_qa.get("periods", {}).get("late", {}).get("end") == 2100)
    annual_check = validate_inputs(overall, groups, gaps, model_ranges, annual, annual_models)
    overall_display = overall[overall.period.isin(PERIODS)].copy()
    check_unique_grid(overall_display, ["ssp", "period"], 8, "overall displayed subset")

    yearly = (annual.groupby(["year", "ssp"], as_index=False)
              .agg(ACH_mean=("delta_ACH_vs_reference", "mean")))

    fig = plt.figure(figsize=(EXPORT["width_in"], EXPORT["height_in"]), constrained_layout=False)
    gs = fig.add_gridspec(
        2, 2, left=SPACING["left"], right=SPACING["right"], bottom=SPACING["bottom"], top=SPACING["top"],
        width_ratios=[1.10, 1.0], height_ratios=[1.0, 1.08],
        hspace=SPACING["hspace"], wspace=SPACING["wspace"],
    )

    # a: actual annual country-mean ACH increments, equally weighted over 203 countries.
    ax_a = fig.add_subplot(gs[0, 0])
    panel_letter(ax_a, "a")
    ax_a.axvspan(2041, 2060, color=COLORS["period_mid"], zorder=0)
    ax_a.axvspan(2081, 2100, color=COLORS["period_late"], zorder=0)
    for scenario in SCENARIOS:
        q = yearly[yearly.ssp.eq(scenario)].sort_values("year")
        color = SCENARIO_COLORS[scenario]
        ax_a.plot(q.year, q.ACH_mean, color=color, linewidth=LINEWIDTHS["trend"],
                  linestyle=LINESTYLES[scenario], solid_capstyle="round")
        ax_a.plot(q.year.iloc[-1], q.ACH_mean.iloc[-1], marker="o", color=color, markersize=MARKERS["trend_end"])
        ax_a.annotate(SCENARIO_LABELS[scenario],
                      (q.year.iloc[-1], q.ACH_mean.iloc[-1]),
                      xytext=(5, 0), textcoords="offset points", va="center",
                      fontsize=TYPOGRAPHY["tick"], color=color, fontweight="semibold", clip_on=False)
    ax_a.set_xlim(2021, 2118)
    ax_a.set_ylim(bottom=0)
    ax_a.set_xlabel("Year")
    ax_a.set_ylabel("ACH increment (°C-days)")
    ax_a.xaxis.set_major_locator(MultipleLocator(20))
    ax_a.yaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{x:,.0f}"))
    clean_axis(ax_a)
    ax_a.grid(axis="y", color=GRID, linewidth=0.55, zorder=0)

    # Common health scale: zero to 1,800 DALYs-rate units per 100,000.
    health_norm = Normalize(vmin=0, vmax=1800, clip=True)

    # b and d share row/column order and a common micro-CI scale.
    def draw_health_matrix(ax, source, value_column, low_column, high_column, letter):
        panel_letter(ax, letter)
        ax.set_xlim(-0.28, 2)
        ax.set_ylim(4, 0)
        ax.set_xticks([0.5, 1.5], PERIOD_LABELS)
        ax.set_yticks([0.5, 1.5, 2.5, 3.5], [SCENARIO_LABELS[s] for s in SCENARIOS])
        ax.tick_params(axis="both", length=0, colors=INK, pad=4, labelsize=6.4)
        ax.set_xticks(np.arange(3), minor=True)
        ax.set_yticks(np.arange(5), minor=True)
        ax.grid(which="minor", color="white", linewidth=1.5)
        ax.tick_params(which="minor", bottom=False, left=False)
        ax.set_xlabel("Period", labelpad=8)
        ax.set_frame_on(False)
        ax.set_axisbelow(False)
        for row, scenario in enumerate(SCENARIOS):
            for col, period in enumerate(PERIODS):
                rec = source[source.ssp.eq(scenario) & source.period.eq(period)]
                if "contrast" in rec.columns:
                    rec = rec[rec.contrast.eq("Low_minus_High")]
                if len(rec) != 1:
                    raise ValueError(f"Expected one record: {scenario} {period} {letter}")
                r = rec.iloc[0]
                value = float(r[value_column])
                ax.add_patch(plt.Rectangle((col, row), 1, 1, facecolor="#F3F6F5",
                                           edgecolor="white", linewidth=1.4, zorder=0))
                matrix_cell(ax, col, row + 0.36, value, float(r[low_column]),
                            float(r[high_column]), health_norm, 1.0, INK)

    ax_b = fig.add_subplot(gs[0, 1])
    draw_health_matrix(ax_b, overall_display, "DALYs_rate_difference_primary",
                       "DALYs_primary_ci_low", "DALYs_primary_ci_high", "b")

    # c: two period-specific SDI × SSP ACH matrices, one shared scale.
    subgs = gs[1, 0].subgridspec(1, 2, wspace=0.40)
    axes_c = [fig.add_subplot(subgs[0, i]) for i in range(2)]
    ach_values = groups.delta_ACH_vs_reference.to_numpy(dtype=float)
    ach_max = float(np.nanmax(ach_values))
    for ax, period, period_label in zip(axes_c, PERIODS, PERIOD_LABELS):
        sub = groups[groups.period.eq(period)]
        mat = np.array([
            [float(sub[sub.ssp.eq(s) & sub.SDI_group_2015_2020.eq(g)]
                   .delta_ACH_vs_reference.iloc[0]) for s in SCENARIOS]
            for g in SDI_GROUPS
        ])
        ax.imshow(mat, cmap=ACH_CMAP, vmin=0, vmax=ach_max, aspect="auto", zorder=0)
        for i in range(len(SDI_GROUPS)):
            for j in range(len(SCENARIOS)):
                value = mat[i, j]
                ax.text(j, i, f"{value:,.0f}", ha="center", va="center", fontsize=7.2,
                        color="white" if value > ach_max * 0.62 else INK,
                        fontweight="bold" if value > ach_max * 0.62 else "normal")
        ax.set_xticks(range(4), ["1–2.6", "2–4.5", "3–7.0", "5–8.5"])
        ax.set_yticks(range(3), SDI_GROUPS if ax is axes_c[0] else ["", "", ""])
        ax.text(0.5, 0.99, period_label, transform=ax.transAxes, ha="center", va="bottom",
                fontsize=TYPOGRAPHY["tick"], color=INK, fontweight="medium")
        ax.tick_params(length=0, colors=INK, pad=3)
        ax.set_xlabel("SSP")
        for spine in ax.spines.values():
            spine.set_visible(False)

    ax_c0 = axes_c[0]
    ax_c0.set_ylabel("Fixed SDI group")
    # One compact colorbar below both matrices.
    cbar = fig.colorbar(
        plt.cm.ScalarMappable(norm=Normalize(0, ach_max), cmap=ACH_CMAP),
        ax=axes_c, orientation="horizontal", fraction=0.08, pad=0.25, aspect=38,
    )
    cbar.set_label("ACH increment (°C-days)", fontsize=7, color=INK, labelpad=3)
    cbar.ax.tick_params(labelsize=6.5, length=2, colors=MUTED)
    cbar.outline.set_visible(False)
    fig.canvas.draw()
    cpos = axes_c[0].get_position()
    c_letter = fig.text(cpos.x0 - 0.035, cpos.y1 + 0.035, "c", ha="left", va="bottom",
                        fontsize=11, fontweight="bold", color=INK)

    ax_d = fig.add_subplot(gs[1, 1])
    d_letter = panel_letter(ax_d, "d")
    d_rows = sorted(d_qa["scenario_estimates"], key=lambda r: SCENARIOS.index(r["ssp"]))
    d_labels = [SCENARIO_LABELS[r["ssp"]] for r in d_rows]
    d_est = np.asarray([r["rate_gap_change"] for r in d_rows], dtype=float)
    d_low = np.asarray([r["ci_low"] for r in d_rows], dtype=float)
    d_high = np.asarray([r["ci_high"] for r in d_rows], dtype=float)
    check("Panel D estimates and intervals finite", np.isfinite(np.c_[d_est, d_low, d_high]).all())
    check("Panel D intervals contain estimates", bool(np.all(d_low <= d_est) and np.all(d_est <= d_high)))
    check("Panel D source order and labels", [r["ssp"] for r in d_rows] == SCENARIOS)
    y_d = np.arange(len(d_rows))
    for i, rec in enumerate(d_rows):
        est, lo, hi = float(rec["rate_gap_change"]), float(rec["ci_low"]), float(rec["ci_high"])
        color = SCENARIO_COLORS[rec["ssp"]]
        ax_d.barh(i, est, height=0.42, color=color, edgecolor="none", zorder=2)
        ax_d.errorbar(est, i, xerr=[[est - lo], [hi - est]], fmt="none",
                      ecolor=COLORS["ci"], elinewidth=LINEWIDTHS["ci"],
                      capsize=MARKERS["ci_cap"], capthick=0.9, zorder=3)
        ax_d.annotate(f"{est:+.1f}", (est, i), xytext=(7, 7), textcoords="offset points",
                      ha="left", va="bottom", fontsize=TYPOGRAPHY["value"],
                      fontweight="semibold", color=INK)
    ax_d.axvline(0, color=INK, linewidth=LINEWIDTHS["zero"], zorder=1)
    ax_d.set_yticks(y_d, d_labels)
    ax_d.invert_yaxis()
    ax_d.set_ylim(3.55, -0.58)
    ax_d.set_xlabel("Conditional DALYs-rate gap change (per 100,000)", labelpad=7)
    ax_d.grid(axis="x", color=GRID, linewidth=LINEWIDTHS["grid"], zorder=0)
    ax_d.set_axisbelow(True)
    ax_d.tick_params(axis="y", length=0, pad=5, colors=INK)
    ax_d.tick_params(axis="x", length=2.5, width=0.6, colors=MUTED)
    ax_d.spines["left"].set_visible(False)
    ax_d.spines["bottom"].set_color(COLORS["axis"])
    d_xlim_low = min(0.0, float(d_low.min()))
    d_xlim_high = max(0.0, float(d_high.max()))
    d_span = d_xlim_high - d_xlim_low
    ax_d.set_xlim(d_xlim_low - 0.05 * d_span, d_xlim_high + 0.13 * d_span)
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    c_letter.set_y(d_letter.get_window_extent(renderer).transformed(fig.transFigure.inverted()).y0)

    outputs = {
        "preview": OUT / "F5_aesthetic_preview.png",
        "svg": OUT / "F5_aesthetic.svg",
        "pdf": OUT / "F5_aesthetic.pdf",
        "tiff": OUT / "F5_aesthetic_600dpi.tif",
    }
    crops = {
        "a": OUT / "F5_aesthetic_panel_a_preview.png",
        "b": OUT / "F5_aesthetic_panel_b_preview.png",
        "c": OUT / "F5_aesthetic_panel_c_preview.png",
        "d": OUT / "F5_aesthetic_panel_d_preview.png",
    }
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    crop_axes = {"a": [ax_a], "b": [ax_b], "c": [*axes_c, cbar.ax], "d": [ax_d]}
    from matplotlib.transforms import Bbox
    for key, axes in crop_axes.items():
        boxes = [ax.get_tightbbox(renderer).transformed(fig.dpi_scale_trans.inverted()) for ax in axes]
        bbox = Bbox.union(boxes).expanded(1.06, 1.06)
        if key == "c":
            letter_box = c_letter.get_window_extent(renderer).transformed(fig.dpi_scale_trans.inverted())
            bbox = Bbox.union([bbox, letter_box]).expanded(1.025, 1.025)
        fig.savefig(crops[key], dpi=EXPORT["preview_dpi"], bbox_inches=bbox, facecolor="white")
    fig.savefig(outputs["preview"], dpi=EXPORT["preview_dpi"], facecolor="white")
    fig.savefig(outputs["svg"], facecolor="white")
    fig.savefig(outputs["pdf"], facecolor="white")
    # Render at 600 dpi through the selected Python backend, then encode with Pillow.
    # This avoids a known Windows Matplotlib TIFF-writer crash in this runtime.
    tiff_raster = OUT / "F5_aesthetic_600dpi_working.png"
    fig.savefig(tiff_raster, format="png", dpi=EXPORT["tiff_dpi"], facecolor="white")
    plt.close(fig)
    with Image.open(tiff_raster) as source_image:
        tifffile.imwrite(
            outputs["tiff"], np.asarray(source_image.convert("RGB")),
            compression="deflate", resolution=(EXPORT["tiff_dpi"], EXPORT["tiff_dpi"]), resolutionunit="INCH",
        )
    tiff_raster.unlink(missing_ok=True)

    print("Figure 5 exported with the uniform 2041–2060 and 2081–2100 windows.")

if __name__ == "__main__":
    main()
