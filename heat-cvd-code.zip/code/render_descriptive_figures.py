from pathlib import Path
import hashlib,json,shutil,sys,importlib.util
import numpy as np,pandas as pd,yaml
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Polygon,Wedge,Circle






P=Path(__file__).resolve().parents[1];O=P/'results/figures';O.mkdir(parents=True,exist_ok=True);D=P/'data/figure_source';A=O
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
protected={str(p):sha(p) for folder in ['figures','manuscript'] for p in (P/folder).rglob('*') if p.is_file()}
plt.rcParams.update({'font.family':'Arial','font.size':7,'axes.labelsize':7,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'legend.frameon':False,'axes.linewidth':.6})
ink='#243A43';blue='#326F87';grey='#A4ACB1';natural='#8AB5B2';human='#C67148';colors=['#B66A47','#A69457','#347C87']
checks=[];inputs={};outputs={}
def ck(name,value):
    checks.append({'check':name,'passed':bool(value)})
    assert value,name
def read(p):inputs[str(p)]=sha(p);return pd.read_csv(p)
def forest(ax,x,lo,hi,y,color,marker='o',ms=4,lw=1):
    ax.errorbar(x,y,xerr=[[x-lo],[hi-x]],fmt=marker,color=color,ecolor=color,capsize=2,ms=ms,lw=lw,zorder=3)
def save(fig,name):
    fig.canvas.draw()
    for ext in ['png','svg','pdf','tiff']:
        f=O/f'{name}.{ext}';fig.savefig(f,dpi=600 if ext=='tiff' else 220,bbox_inches='tight',pad_inches=.05,facecolor='white',**({'pil_kwargs':{'compression':'raw'}} if ext=='tiff' else {}));outputs[f.name]=sha(f)
    plt.close(fig)
def style(ax,tag):
    ax.text(-.13,1.04,tag,transform=ax.transAxes,weight='bold',fontsize=10)
    ax.tick_params(labelsize=6.5,length=2.5);ax.grid(axis='y',color='#E0E6E8',lw=.4,zorder=0)

# F3 and SF1 reuse the registered medians, country means and box statistics.
means=read(D/'F2_SF1_country_means.csv');bins=read(D/'F2_SF1_SDI_bin_medians.csv');boxes=read(D/'F2_SF1_box_statistics.csv')
def descriptive(name,metrics,source_id):
    fig,axs=plt.subplots(2,2,figsize=(7.2,5.5));fig.subplots_adjust(left=.13,right=.98,bottom=.16,top=.94,hspace=.44,wspace=.40)
    for j,metric in enumerate(metrics):
        obs=read(D/f'{source_id}_{metric}_observations.csv');ax=axs[0,j]
        for group,c in zip(['Low','Middle','High'],colors):
            q=obs[obs.group.eq(group)];ax.scatter(q.SDI,q.value,s=3,color=c,alpha=.18,lw=0,rasterized=True,zorder=2)
        bn=bins[bins.metric.eq(metric)&bins.figure.eq(source_id)]
        ax.scatter(bn.SDI,bn.value,s=13,marker='D',facecolor='white',edgecolor=ink,lw=.65,zorder=4)
        unit='ACH (°C-days)' if metric=='ACH' else metric+' (per 100,000)'
        ax.set(xlabel='SDI',ylabel=unit,xlim=(0,1));style(ax,'ab'[j])
        ck(name+' '+metric+' annual point count',sum(len(c.get_offsets()) for c in ax.collections[:3])==6293)
        ax=axs[1,j];mm=means[means.metric.eq(metric)&means.figure.eq(source_id)]
        for k,(group,c) in enumerate(zip(['Low','Middle','High'],colors)):
            r=boxes[boxes.metric.eq(metric)&boxes.figure.eq(source_id)&boxes.group.eq(group)].iloc[0]
            stat={'med':r['median'],'q1':r.q1,'q3':r.q3,'whislo':r.whisker_low,'whishi':r.whisker_high,'fliers':[]}
            ax.bxp([stat],positions=[k],widths=.49,showfliers=False,patch_artist=True,boxprops={'facecolor':c+'1A','edgecolor':c,'linewidth':1.1},medianprops={'color':c,'linewidth':1.7},whiskerprops={'color':c},capprops={'color':c},zorder=3)
            vals=mm[mm.group.eq(group)].sort_values('fid').value.to_numpy();offsets=((np.arange(len(vals))*.61803398875)%1-.5)*.30
            dots=ax.scatter(k+offsets,vals,s=7,color=c,alpha=.6,lw=0,zorder=4)
            ck(name+' '+metric+' '+group+' country coordinates',np.array_equal(np.asarray(dots.get_offsets())[:,1],vals))
        pair=pd.read_csv(D/'SDI_boxplot_pairwise_tests.csv');pair=pair[pair.metric.eq(metric)]
        bottom,top=ax.get_ylim();span=top-bottom
        for level,(i,j) in enumerate([(0,1),(1,2),(0,2)]):
            p=pair[pair.group1.eq(['Low','Middle','High'][i])&pair.group2.eq(['Low','Middle','High'][j])].iloc[0].p_holm
            y=top+span*(.04+.16*level);h=.025*span
            ax.plot([i,i,j,j],[y,y+h,y+h,y],color=ink,lw=.65)
            lab='P < 0.001' if p<.001 else f'P = {p:.3f}'
            ax.text((i+j)/2,y+h+.01*span,lab,ha='center',va='bottom',fontsize=6)
        ax.set_ylim(bottom,top+.48*span)
        ck(name+' '+metric+' countries',len(mm)==203)
        ax.set(xticks=[0,1,2],xticklabels=['Low','Middle','High'],xlabel='Baseline SDI group',ylabel=unit);style(ax,'cd'[metrics.index(metric)])
    handles=[Line2D([0],[0],marker='o',lw=0,color=c,label=g,markersize=4) for c,g in zip(colors,['Low','Middle','High'])]+[Line2D([0],[0],marker='D',lw=0,mec=ink,mfc='white',label='Bin median',markersize=4)]
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.55,.015),ncol=4,fontsize=6.5)
    save(fig,name)
descriptive('F3',['ACH','ASDR'],'F2')
descriptive('S1',['ASIR','ASMR'],'SF1')



