"""Calculate six P90-based cumulative heat indicators and annual Tmean.

The program expects daily NetCDF files produced by ``Tmax、Tmean、Tmin.py``
and the calendar-day P90 threshold file produced by ``Tmax、Tmin（90th）.py``.
It creates one annual value for every grid cell and indicator.  A day only
contributes when it belongs to a heat event lasting at least two consecutive
valid calendar days (``--min-duration 2``).  Events crossing 31 December are
kept as one event; their daily intensities are assigned to their own years.
It also writes GeoTIFF maps of the 1990--2020 mean annual values.

The six output variables are:

* ``absolute_cumulative_heat``: sum(max(Tmax - 30, 0)) for Tmax > 30 C;
* ``relative_cumulative_heat``: sum(max(Tmax - P90_Tmax, 0));
* ``mixed_cumulative_heat``: sum(max(Tmax - max(30, P90_Tmax), 0));
* ``daytime_cumulative_heat``: Tmax > P90_Tmax and Tmin < P90_Tmin;
* ``nighttime_cumulative_heat``: Tmax < P90_Tmax and Tmin > P90_Tmin;
* ``compound_day_night_cumulative_heat``: Tmax > P90_Tmax and Tmin >
  P90_Tmin, with the two exceedances added on each qualifying day.

Here P90 refers to the calendar-day, grid-cell-specific threshold.  February
29 is excluded because the supplied threshold uses a 365-day calendar; it also
interrupts an event, avoiding an implicit and undocumented threshold choice.
"""
from __future__ import annotations
import os
import argparse
from contextlib import ExitStack
from datetime import date
from pathlib import Path
from uuid import uuid4
import numpy as np
try:
    from netCDF4 import Dataset, num2date
except ImportError as exc:
    raise SystemExit("This program requires the 'netCDF4' package.") from exc
DEFAULT_ROOT = Path(os.environ.get('HEAT_CVD_DATA_PROCESS', 'external_inputs/Data_process'))
DEFAULT_START_YEAR = 1990
DEFAULT_END_YEAR = 2020
DEFAULT_MIN_DURATION = 2
FILL_VALUE = np.float32(-9999.0)
LATITUDE_NAME = 'latitude'
LONGITUDE_NAME = 'longitude'
TIME_CANDIDATES = ('time', 'valid_time', 'date')
TMAX_VARIABLE = 'daily_max_t2m'
TMIN_VARIABLE = 'daily_min_t2m'
P90_TMAX_VARIABLE = 'tmax_p90'
P90_TMIN_VARIABLE = 'tmin_p90'
TMEAN_VARIABLE = 'daily_mean_t2m'
INDICATORS = (('absolute_cumulative_heat', 'Absolute cumulative heat', 'sum(max(Tmax - 30 degC, 0)) for qualifying events'), ('relative_cumulative_heat', 'Relative cumulative heat', 'sum(max(Tmax - calendar-day Tmax P90, 0)) for qualifying events'), ('mixed_cumulative_heat', 'Mixed cumulative heat', 'sum(max(Tmax - max(30 degC, calendar-day Tmax P90), 0)) for qualifying events'), ('daytime_cumulative_heat', 'Daytime cumulative heat', 'sum(Tmax - Tmax P90) where Tmax > Tmax P90 and Tmin < Tmin P90, for qualifying events'), ('nighttime_cumulative_heat', 'Nighttime cumulative heat', 'sum(Tmin - Tmin P90) where Tmax < Tmax P90 and Tmin > Tmin P90, for qualifying events'), ('compound_day_night_cumulative_heat', 'Compound day-night cumulative heat', 'sum((Tmax - Tmax P90) + (Tmin - Tmin P90)) where both exceed P90, for qualifying events'))
TIF_OUTPUTS = (('absolute_cumulative_heat', 'mean_absolute_cumulative_heat'), ('relative_cumulative_heat', 'mean_relative_cumulative_heat'), ('mixed_cumulative_heat', 'mean_mixed_cumulative_heat'), ('daytime_cumulative_heat', 'mean_daytime_cumulative_heat'), ('nighttime_cumulative_heat', 'mean_nighttime_cumulative_heat'), ('compound_day_night_cumulative_heat', 'mean_compound_day_night_cumulative_heat'), ('annual_mean_tmean', 'mean_tmean'))

def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--tmax-dir', type=Path, default=DEFAULT_ROOT / 'Tmax')
    parser.add_argument('--tmin-dir', type=Path, default=DEFAULT_ROOT / 'Tmin')
    parser.add_argument('--tmean-dir', type=Path, default=DEFAULT_ROOT / 'Tmean')
    parser.add_argument('--p90-file', type=Path, default=DEFAULT_ROOT / 'Threshold_90th' / 'Tmax_Tmin_P90_1990-2020.nc')
    parser.add_argument('--output-file', type=Path, default=DEFAULT_ROOT / 'Heat_indicators' / 'heat_indicators_1990-2020.nc')
    parser.add_argument('--start-year', type=int, default=DEFAULT_START_YEAR)
    parser.add_argument('--end-year', type=int, default=DEFAULT_END_YEAR)
    parser.add_argument('--min-duration', type=int, default=DEFAULT_MIN_DURATION, help='Minimum consecutive event length in days (default: 2).')
    parser.add_argument('--lat-chunk', type=int, default=16)
    parser.add_argument('--lon-chunk', type=int, default=32)
    parser.add_argument('--tif-dir', type=Path, default=DEFAULT_ROOT / 'Heat_indicators' / 'mean_1990-2020_tif', help='Directory for the seven multi-year mean GeoTIFF files.')
    parser.add_argument('--skip-tif', action='store_true', help='Do not generate GeoTIFF maps.')
    parser.add_argument('--overwrite', action='store_true')
    return parser.parse_args()

def find_year_file(directory: Path, label: str, year: int) -> Path:
    path = directory / f'{label}_{year}.nc'
    if not path.is_file():
        raise FileNotFoundError(f'Missing input file: {path}')
    return path

def find_time_name(dataset: Dataset) -> str:
    for name in TIME_CANDIDATES:
        if name in dataset.variables:
            return name
    raise KeyError(f'{dataset.filepath()}: no time coordinate in {TIME_CANDIDATES}.')

def as_float_array(variable, index) -> np.ndarray:
    """Read a NetCDF slice as float32, replacing masked/fill values with NaN."""
    values = variable[index]
    if np.ma.isMaskedArray(values):
        values = values.filled(np.nan)
    return np.asarray(values, dtype=np.float32)

def common_calendar_index(timestamp) -> int | None:
    """Return a zero-based 365-day calendar index, or None for 29 February."""
    if timestamp.month == 2 and timestamp.day == 29:
        return None
    return (date(2001, timestamp.month, timestamp.day) - date(2001, 1, 1)).days

def year_records(dataset: Dataset, expected_year: int) -> tuple[np.ndarray, list[date], np.ndarray]:
    """Return source positions, dates and P90-calendar indices for one year."""
    time_name = find_time_name(dataset)
    time_variable = dataset.variables[time_name]
    if not getattr(time_variable, 'units', None):
        raise ValueError(f'{dataset.filepath()}: time coordinate has no units attribute.')
    decoded = num2date(time_variable[:], units=time_variable.units, calendar=getattr(time_variable, 'calendar', 'standard'), only_use_cftime_datetimes=False, only_use_python_datetimes=False)
    records: list[tuple[int, date, int]] = []
    for source_index, timestamp in enumerate(decoded):
        if timestamp.year != expected_year:
            continue
        day_index = common_calendar_index(timestamp)
        if day_index is not None:
            records.append((source_index, date(timestamp.year, timestamp.month, timestamp.day), day_index))
    records.sort(key=lambda item: item[1])
    if not records:
        raise ValueError(f'{dataset.filepath()}: no usable records for {expected_year}.')
    if len({item[1] for item in records}) != len(records):
        raise ValueError(f'{dataset.filepath()}: duplicate daily records in {expected_year}.')
    return (np.asarray([item[0] for item in records], dtype=np.intp), [item[1] for item in records], np.asarray([item[2] for item in records], dtype=np.intp))

def all_year_indices(dataset: Dataset, expected_year: int) -> np.ndarray:
    """Return all unique daily source positions for an annual Tmean average.

    Unlike P90-event processing, this intentionally retains 29 February.
    """
    time_name = find_time_name(dataset)
    time_variable = dataset.variables[time_name]
    if not getattr(time_variable, 'units', None):
        raise ValueError(f'{dataset.filepath()}: time coordinate has no units attribute.')
    decoded = num2date(time_variable[:], units=time_variable.units, calendar=getattr(time_variable, 'calendar', 'standard'), only_use_cftime_datetimes=False, only_use_python_datetimes=False)
    records = [(source_index, date(timestamp.year, timestamp.month, timestamp.day)) for source_index, timestamp in enumerate(decoded) if timestamp.year == expected_year]
    records.sort(key=lambda item: item[1])
    if not records:
        raise ValueError(f'{dataset.filepath()}: no daily records for {expected_year}.')
    if len({item[1] for item in records}) != len(records):
        raise ValueError(f'{dataset.filepath()}: duplicate daily records in {expected_year}.')
    return np.asarray([item[0] for item in records], dtype=np.intp)

def validate_daily_dataset(dataset: Dataset, variable_name: str, reference: Dataset) -> None:
    if variable_name not in dataset.variables:
        raise KeyError(f'{dataset.filepath()}: missing variable {variable_name!r}.')
    time_name = find_time_name(dataset)
    expected_dimensions = (time_name, LATITUDE_NAME, LONGITUDE_NAME)
    if dataset.variables[variable_name].dimensions != expected_dimensions:
        raise ValueError(f'{dataset.filepath()}: {variable_name!r} dimensions must be {expected_dimensions}.')
    for coordinate in (LATITUDE_NAME, LONGITUDE_NAME):
        if coordinate not in dataset.variables:
            raise KeyError(f'{dataset.filepath()}: missing coordinate {coordinate!r}.')
        if not np.array_equal(reference.variables[coordinate][:], dataset.variables[coordinate][:]):
            raise ValueError(f'Grid mismatch for {coordinate}: {dataset.filepath()}.')

def copy_coordinate(output: Dataset, source: Dataset, name: str) -> None:
    source_variable = source.variables[name]
    variable = output.createVariable(name, source_variable.dtype, (name,))
    variable[:] = source_variable[:]
    variable.setncatts({attribute: source_variable.getncattr(attribute) for attribute in source_variable.ncattrs() if attribute != '_FillValue'})

def create_output(path: Path, reference: Dataset, years: list[int], min_duration: int, lat_chunk: int, lon_chunk: int, p90_file: Path) -> Dataset:
    path.parent.mkdir(parents=True, exist_ok=True)
    output = Dataset(path, 'w', format='NETCDF4')
    latitude_size = reference.variables[LATITUDE_NAME].size
    longitude_size = reference.variables[LONGITUDE_NAME].size
    output.createDimension('year', len(years))
    output.createDimension(LATITUDE_NAME, latitude_size)
    output.createDimension(LONGITUDE_NAME, longitude_size)
    year_variable = output.createVariable('year', 'i2', ('year',))
    year_variable[:] = np.asarray(years, dtype=np.int16)
    year_variable.long_name = 'calendar year of accumulated heat intensity'
    copy_coordinate(output, reference, LATITUDE_NAME)
    copy_coordinate(output, reference, LONGITUDE_NAME)
    chunks = (1, min(lat_chunk, latitude_size), min(lon_chunk, longitude_size))
    units = getattr(reference.variables[TMAX_VARIABLE], 'units', 'degree_Celsius')
    for name, long_name, definition in INDICATORS:
        variable = output.createVariable(name, 'f4', ('year', LATITUDE_NAME, LONGITUDE_NAME), zlib=True, complevel=1, shuffle=True, chunksizes=chunks, fill_value=FILL_VALUE)
        variable.long_name = long_name
        variable.units = units + ' days'
        variable.cell_methods = 'time: sum within qualifying heat events'
        variable.definition = definition
        variable.minimum_event_duration_days = np.int16(min_duration)
        variable.event_rule = 'All consecutive days in an event must meet the stated condition.'
    annual_tmean = output.createVariable('annual_mean_tmean', 'f4', ('year', LATITUDE_NAME, LONGITUDE_NAME), zlib=True, complevel=1, shuffle=True, chunksizes=chunks, fill_value=FILL_VALUE)
    annual_tmean.long_name = 'Annual mean daily 2-m air temperature'
    annual_tmean.units = units
    annual_tmean.cell_methods = 'time: mean'
    annual_tmean.definition = 'Mean of all valid daily Tmean values in the calendar year.'
    output.title = 'Annual P90-based cumulative heat indicators'
    output.Conventions = 'CF-1.8'
    output.p90_threshold_file = str(p90_file)
    output.event_duration_rule = f'Only events lasting at least {min_duration} consecutive valid calendar days contribute.'
    output.leap_day_handling = 'February 29 is omitted and breaks event continuity.'
    output.compound_indicator_note = 'Compound day-night intensity is the sum of Tmax and Tmin P90 exceedances.'
    return output

def event_days(condition: np.ndarray, dates: list[date], min_duration: int) -> np.ndarray:
    """Keep True cells that occur in runs of >= min_duration consecutive dates."""
    count, _, _ = condition.shape
    forward = np.zeros(condition.shape, dtype=np.uint16)
    running = np.zeros(condition.shape[1:], dtype=np.uint16)
    previous_date: date | None = None
    for index in range(count):
        if previous_date is None or (dates[index] - previous_date).days != 1:
            running.fill(0)
        running = np.where(condition[index], running + 1, 0).astype(np.uint16, copy=False)
        forward[index] = running
        previous_date = dates[index]
    eligible = np.zeros_like(condition, dtype=bool)
    running.fill(0)
    next_date: date | None = None
    for index in range(count - 1, -1, -1):
        if next_date is None or (next_date - dates[index]).days != 1:
            running.fill(0)
        running = np.where(condition[index], running + 1, 0).astype(np.uint16, copy=False)
        eligible[index] = condition[index] & (forward[index] + running - 1 >= min_duration)
        next_date = dates[index]
    return eligible

def yearly_totals(values: np.ndarray, condition: np.ndarray, dates: list[date], years: list[int], min_duration: int) -> np.ndarray:
    eligible = event_days(condition, dates, min_duration)
    totals = np.empty((len(years), *values.shape[1:]), dtype=np.float32)
    for index, year in enumerate(years):
        time_indices = np.fromiter((position for position, timestamp in enumerate(dates) if timestamp.year == year), dtype=np.intp)
        if time_indices.size:
            totals[index] = np.where(eligible[time_indices], values[time_indices], 0.0).sum(axis=0, dtype=np.float32)
        else:
            totals[index].fill(np.nan)
    return totals

def mean_without_nan(values: np.ndarray) -> np.ndarray:
    """Mean along time while returning NaN where every annual value is missing."""
    valid = np.isfinite(values)
    counts = valid.sum(axis=0)
    totals = np.where(valid, values, 0.0).sum(axis=0, dtype=np.float64)
    mean = np.full(values.shape[1:], np.nan, dtype=np.float32)
    np.divide(totals, counts, out=mean, where=counts > 0, casting='unsafe')
    return mean

def geo_tiff_grid(data: np.ndarray, latitudes: np.ndarray, longitudes: np.ndarray) -> tuple[np.ndarray, object]:
    """Orient a regular latitude/longitude grid north-up for a GeoTIFF."""
    try:
        from rasterio.transform import from_origin
    except ImportError as exc:
        raise SystemExit("GeoTIFF output requires the 'rasterio' package.") from exc
    if latitudes.size < 2 or longitudes.size < 2:
        raise ValueError('GeoTIFF output requires at least two latitude and longitude grid cells.')
    latitude_delta = np.diff(latitudes)
    longitude_delta = np.diff(longitudes)
    if not np.allclose(np.abs(latitude_delta), abs(latitude_delta[0])):
        raise ValueError('Latitude coordinate is not regularly spaced; cannot create GeoTIFF.')
    if not np.allclose(np.abs(longitude_delta), abs(longitude_delta[0])):
        raise ValueError('Longitude coordinate is not regularly spaced; cannot create GeoTIFF.')
    if latitude_delta[0] > 0 and np.all(latitude_delta > 0):
        data = data[::-1, :]
        north = float(latitudes[-1])
    elif latitude_delta[0] < 0 and np.all(latitude_delta < 0):
        north = float(latitudes[0])
    else:
        raise ValueError('Latitude coordinate must be strictly monotonic.')
    if longitude_delta[0] < 0 and np.all(longitude_delta < 0):
        data = data[:, ::-1]
        west = float(longitudes[-1])
    elif longitude_delta[0] > 0 and np.all(longitude_delta > 0):
        west = float(longitudes[0])
    else:
        raise ValueError('Longitude coordinate must be strictly monotonic.')
    x_resolution = float(abs(longitude_delta[0]))
    y_resolution = float(abs(latitude_delta[0]))
    return (data, from_origin(west - x_resolution / 2, north + y_resolution / 2, x_resolution, y_resolution))

def check_tif_targets(tif_dir: Path, start_year: int, end_year: int, overwrite: bool) -> None:
    if overwrite:
        return
    existing = [tif_dir / f'{tif_name}_{start_year}-{end_year}.tif' for _, tif_name in TIF_OUTPUTS if (tif_dir / f'{tif_name}_{start_year}-{end_year}.tif').exists()]
    if existing:
        raise FileExistsError(f'GeoTIFF already exists: {existing[0]}. Use --overwrite to replace it.')

def write_multiyear_mean_geotiffs(netcdf_file: Path, tif_dir: Path, start_year: int, end_year: int, overwrite: bool) -> None:
    """Write one north-up EPSG:4326 GeoTIFF for each mean annual variable."""
    try:
        import rasterio
    except ImportError as exc:
        raise SystemExit("GeoTIFF output requires the 'rasterio' package.") from exc
    tif_dir.mkdir(parents=True, exist_ok=True)
    with Dataset(netcdf_file) as source:
        latitudes = as_float_array(source.variables[LATITUDE_NAME], slice(None))
        longitudes = as_float_array(source.variables[LONGITUDE_NAME], slice(None))
        for variable_name, tif_name in TIF_OUTPUTS:
            variable = source.variables[variable_name]
            mean = mean_without_nan(as_float_array(variable, slice(None)))
            mean, transform = geo_tiff_grid(mean, latitudes, longitudes)
            output_path = tif_dir / f'{tif_name}_{start_year}-{end_year}.tif'
            if output_path.exists() and (not overwrite):
                raise FileExistsError(f'GeoTIFF already exists: {output_path}. Use --overwrite.')
            raster = np.where(np.isfinite(mean), mean, FILL_VALUE).astype(np.float32)
            with rasterio.open(output_path, 'w', driver='GTiff', height=raster.shape[0], width=raster.shape[1], count=1, dtype='float32', crs='EPSG:4326', transform=transform, nodata=float(FILL_VALUE), compress='deflate', predictor=3) as destination:
                destination.write(raster, 1)
                destination.update_tags(variable=variable_name, long_name=getattr(variable, 'long_name', variable_name), units=getattr(variable, 'units', 'unknown'), aggregation=f'mean of annual values, {start_year}-{end_year}')

def main() -> None:
    args = parse_arguments()
    if args.start_year > args.end_year:
        raise ValueError('--start-year must be no greater than --end-year.')
    if args.min_duration < 1:
        raise ValueError('--min-duration must be at least 1.')
    if args.lat_chunk < 1 or args.lon_chunk < 1:
        raise ValueError('--lat-chunk and --lon-chunk must be positive.')
    if not args.p90_file.is_file():
        raise FileNotFoundError(f'P90 threshold file not found: {args.p90_file}')
    if args.output_file.exists() and (not args.overwrite):
        raise FileExistsError(f'Output already exists: {args.output_file}. Use --overwrite.')
    if not args.skip_tif:
        check_tif_targets(args.tif_dir, args.start_year, args.end_year, args.overwrite)
    years = list(range(args.start_year, args.end_year + 1))
    temporary_path = args.output_file.with_name(f'{args.output_file.name}.{uuid4().hex}.part')
    if temporary_path.exists():
        raise FileExistsError(f'Temporary output already exists: {temporary_path}')
    with ExitStack() as stack:
        tmax_sets = [stack.enter_context(Dataset(find_year_file(args.tmax_dir, 'Tmax', year))) for year in years]
        tmin_sets = [stack.enter_context(Dataset(find_year_file(args.tmin_dir, 'Tmin', year))) for year in years]
        tmean_sets = [stack.enter_context(Dataset(find_year_file(args.tmean_dir, 'Tmean', year))) for year in years]
        thresholds = stack.enter_context(Dataset(args.p90_file))
        reference = tmax_sets[0]
        for dataset in tmax_sets:
            validate_daily_dataset(dataset, TMAX_VARIABLE, reference)
        for dataset in tmin_sets:
            validate_daily_dataset(dataset, TMIN_VARIABLE, reference)
        for dataset in tmean_sets:
            validate_daily_dataset(dataset, TMEAN_VARIABLE, reference)
        for variable_name in (P90_TMAX_VARIABLE, P90_TMIN_VARIABLE):
            if variable_name not in thresholds.variables:
                raise KeyError(f'{args.p90_file}: missing P90 variable {variable_name!r}.')
            if thresholds.variables[variable_name].dimensions != ('day_of_year', LATITUDE_NAME, LONGITUDE_NAME):
                raise ValueError(f'{args.p90_file}: unexpected dimensions for {variable_name!r}.')
        for coordinate in (LATITUDE_NAME, LONGITUDE_NAME):
            if not np.array_equal(reference.variables[coordinate][:], thresholds.variables[coordinate][:]):
                raise ValueError(f'Grid mismatch between input and P90 file for {coordinate}.')
        record_info = [year_records(dataset, year) for dataset, year in zip(tmax_sets, years, strict=True)]
        tmean_indices = [all_year_indices(dataset, year) for dataset, year in zip(tmean_sets, years, strict=True)]
        for dataset, year, (_, max_dates, _) in zip(tmin_sets, years, record_info, strict=True):
            _, min_dates, _ = year_records(dataset, year)
            if max_dates != min_dates:
                raise ValueError(f'Tmax/Tmin dates differ in {year}.')
        dates = [timestamp for info in record_info for timestamp in info[1]]
        p90_days = np.concatenate([info[2] for info in record_info])
        output = stack.enter_context(create_output(temporary_path, reference, years, args.min_duration, args.lat_chunk, args.lon_chunk, args.p90_file))
        latitude_size = reference.variables[LATITUDE_NAME].size
        longitude_size = reference.variables[LONGITUDE_NAME].size
        total_tiles = (latitude_size + args.lat_chunk - 1) // args.lat_chunk * ((longitude_size + args.lon_chunk - 1) // args.lon_chunk)
        tile_number = 0
        print(f'Calculating six indicators for {args.start_year}-{args.end_year}; minimum event duration = {args.min_duration} days.', flush=True)
        for latitude_start in range(0, latitude_size, args.lat_chunk):
            latitude_slice = slice(latitude_start, min(latitude_start + args.lat_chunk, latitude_size))
            for longitude_start in range(0, longitude_size, args.lon_chunk):
                longitude_slice = slice(longitude_start, min(longitude_start + args.lon_chunk, longitude_size))
                tile_number += 1
                print(f'  Tile {tile_number}/{total_tiles}', flush=True)
                max_parts = [as_float_array(dataset.variables[TMAX_VARIABLE], (info[0], latitude_slice, longitude_slice)) for dataset, info in zip(tmax_sets, record_info, strict=True)]
                min_parts = [as_float_array(dataset.variables[TMIN_VARIABLE], (info[0], latitude_slice, longitude_slice)) for dataset, info in zip(tmin_sets, record_info, strict=True)]
                tmax = np.concatenate(max_parts, axis=0)
                tmin = np.concatenate(min_parts, axis=0)
                p90_max = as_float_array(thresholds.variables[P90_TMAX_VARIABLE], (slice(None), latitude_slice, longitude_slice))[p90_days]
                p90_min = as_float_array(thresholds.variables[P90_TMIN_VARIABLE], (slice(None), latitude_slice, longitude_slice))[p90_days]
                valid_tmax = np.isfinite(tmax)
                valid_tmin = np.isfinite(tmin)
                valid_p90_max = np.isfinite(p90_max)
                valid_p90_min = np.isfinite(p90_min)
                valid_p90_tmax = valid_tmax & valid_p90_max
                valid_p90_both = valid_p90_tmax & valid_tmin & valid_p90_min
                event_conditions = (valid_tmax & (tmax > 30.0), valid_p90_tmax & (tmax > p90_max), valid_p90_tmax & (tmax > np.maximum(30.0, p90_max)), valid_p90_both & (tmax > p90_max) & (tmin < p90_min), valid_p90_both & (tmax < p90_max) & (tmin > p90_min), valid_p90_both & (tmax > p90_max) & (tmin > p90_min))
                intensities = (np.maximum(tmax - 30.0, 0.0), np.maximum(tmax - p90_max, 0.0), np.maximum(tmax - np.maximum(30.0, p90_max), 0.0), np.maximum(tmax - p90_max, 0.0), np.maximum(tmin - p90_min, 0.0), np.maximum(tmax - p90_max, 0.0) + np.maximum(tmin - p90_min, 0.0))
                for (name, _, _), condition, intensity in zip(INDICATORS, event_conditions, intensities, strict=True):
                    totals = yearly_totals(intensity, condition, dates, years, args.min_duration)
                    output.variables[name][:, latitude_slice, longitude_slice] = totals
                for year_index, (dataset, source_indices) in enumerate(zip(tmean_sets, tmean_indices, strict=True)):
                    tmean = as_float_array(dataset.variables[TMEAN_VARIABLE], (source_indices, latitude_slice, longitude_slice))
                    tmean_valid = np.isfinite(tmean)
                    tmean_count = tmean_valid.sum(axis=0)
                    annual_tmean = np.full(tmean.shape[1:], np.nan, dtype=np.float32)
                    np.divide(np.where(tmean_valid, tmean, 0.0).sum(axis=0, dtype=np.float64), tmean_count, out=annual_tmean, where=tmean_count > 0, casting='unsafe')
                    output.variables['annual_mean_tmean'][year_index, latitude_slice, longitude_slice] = annual_tmean
                del tmax, tmin, p90_max, p90_min, valid_tmax, valid_tmin
                del valid_p90_max, valid_p90_min, valid_p90_tmax, valid_p90_both
                del event_conditions, intensities
    if args.output_file.exists():
        args.output_file.unlink()
    temporary_path.replace(args.output_file)
    if not args.skip_tif:
        write_multiyear_mean_geotiffs(args.output_file, args.tif_dir, args.start_year, args.end_year, args.overwrite)
    print(f'Finished: {args.output_file}', flush=True)
    if not args.skip_tif:
        print(f'Finished GeoTIFF files: {args.tif_dir}', flush=True)
if __name__ == '__main__':
    main()
