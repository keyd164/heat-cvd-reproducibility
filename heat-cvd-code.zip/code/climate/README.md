# 上游气候代码

这些文件包含原分析使用的核心科学实现；此次移植主要将机器绝对路径改为环境变量与外部输入占位。`external_inputs.example.json`列出需配置的路径变量。按键名设置环境变量，值为本机实际文件/目录；JSON文件本身不会自动加载。

- `calculate_heat_indicators.py`：日历、热事件与年度累计规则。
- `natural_forcing.py`：BCC配对月信号、年度缩放、插值、扣除ERA5日温、事件重算及国家聚合。阶段signal/compute/aggregate；几何准备见同目录脚本。
- `scripts/02_build_threshold.py`、`03_heat_event_detection.py`、`04_country_aggregation.py`：模型格点阈值、跨年事件与国家聚合。
- `scripts/05_align_era5_ach.py`：模型特定SSP245 2016–2020共同参照的年度ACH变化与ERA5锚定。
- `scripts/07_build_kace_ach.py`：KACE 360→365日日历处理。
- `scripts/prepare_native_country_samplers.py`：原生模式网格国家采样。

安装 `requirements-climate.txt`。完整上游重算还需要原始日温NetCDF、国家多边形、模式文件清单、几何采样配置和先行阶段输出；这些大文件未收入Git。逐阶段脚本保留原来衔接约定，这部分不等同于“下载仓库后无外部资料即可端到端运行”。本次只做语法检查，未重跑全球日尺度流程。

可直接复现的年度健康统计与图表入口在仓库README中列出，使用已打包年度数据。
