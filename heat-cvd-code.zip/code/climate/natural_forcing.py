"""BCC paired natural-forcing experiment. No modification of source data.

Preserves the existing monthly climatology + smoothed annual scaling method,
uses periodic bilinear longitude interpolation and nearest polar-edge values,
then applies the exact upstream two-day ACH/RCH/MCH event rules in spatial tiles.
Outputs a constructed counterfactual, not raw model hist-nat exposure.
"""
import os
from pathlib import Path
from contextlib import ExitStack
from datetime import date
import argparse, importlib.util, sys, json, hashlib, time
import numpy as np
import pandas as pd
from netCDF4 import Dataset, num2date
from scipy.interpolate import RegularGridInterpolator
YEARS = list(range(1990, 2021))
FIELDS = {'ACH': 'absolute_cumulative_heat', 'RCH': 'relative_cumulative_heat', 'MCH': 'mixed_cumulative_heat'}
CLIMATE = Path(os.environ.get('HEAT_CVD_CLIMATE_PROCESS', 'external_inputs/Climate_process'))
P90 = CLIMATE / 'Threshold_90th/Tmax_Tmin_P90_1990-2020.nc'
HIST = CLIMATE / 'outputs/country_heat_panel_1990_2020_v2/country_heat_region_year_panel_1990_2020.csv'
MODEL = Path(os.environ.get('HEAT_CVD_CIMP', 'external_inputs/CIMP'))
SOURCE_FILES = {'nat_early': MODEL / 'Hist-nat/tasmax_day_BCC-CSM2-MR_hist-nat_r1i1p1f1_gn_19750101-19991231.nc', 'nat_late': MODEL / 'Hist-nat/tasmax_day_BCC-CSM2-MR_hist-nat_r1i1p1f1_gn_20000101-20201231.nc', 'factual_early': MODEL / 'historical/tasmax_day_BCC-CSM2-MR_historical_r1i1p1f1_gn_19750101-19991231.nc', 'factual_late': MODEL / 'historical/tasmax_day_BCC-CSM2-MR_historical_r1i1p1f1_gn_20000101-20141231.nc', 'ssp245': MODEL / 'historical/tasmax_day_BCC-CSM2-MR_ssp245_r1i1p1f1_gn_20150101-20391231.nc'}

def upstream_rules():
    spec = importlib.util.spec_from_file_location('climate_rules', Path(__file__).with_name('calculate_heat_indicators.py'))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod

def read_float(v, idx):
    return np.asarray(np.ma.filled(v[idx], np.nan), dtype=np.float32)

def decoded(ds):
    t = ds.variables['time']
    dt = num2date(t[:], t.units, calendar=getattr(t, 'calendar', 'standard'))
    keys = [(x.year, x.month, x.day) for x in dt]
    if len(set(keys)) != len(keys):
        raise ValueError('Duplicate source dates')
    return dt

def signal(out):
    cache = out / 'paired_monthly_signal.npz'
    if cache.exists():
        return
    with ExitStack() as stack:
        sets = {k: stack.enter_context(Dataset(p)) for k, p in SOURCE_FILES.items()}
        dates = {k: decoded(d) for k, d in sets.items()}
        ref = sets['nat_early']
        lat = np.asarray(ref.variables['lat'][:], dtype=np.float64)
        lon = np.asarray(ref.variables['lon'][:], dtype=np.float64)
        inventory = []
        for key, ds in sets.items():
            assert ds.source_id == 'BCC-CSM2-MR' and ds.variant_label == 'r1i1p1f1' and (ds.grid_label == 'gn')
            assert ds.variables['tasmax'].units == 'K'
            assert getattr(ds.variables['time'], 'calendar', 'standard') in ['365_day', 'noleap']
            assert np.array_equal(lat, ds.variables['lat'][:]) and np.array_equal(lon, ds.variables['lon'][:])
            inventory.append(dict(role=key, path=str(SOURCE_FILES[key]), source_id=ds.source_id, variant_label=ds.variant_label, experiment_id=ds.experiment_id, grid_label=ds.grid_label, calendar=ds.variables['time'].calendar, units=ds.variables['tasmax'].units, first=str(dates[key][0]), last=str(dates[key][-1])))
        assert np.all(np.diff(lat) > 0) and np.all(np.diff(lon) > 0)
        sums = np.zeros((12, len(lat), len(lon)), dtype=np.float64)
        counts = np.zeros(12, int)
        annual = []
        pair_qc = []
        w = np.cos(np.deg2rad(lat.astype(np.float64)))[:, None]
        for y in YEARS:
            nk = 'nat_early' if y < 2000 else 'nat_late'
            fk = 'factual_early' if y < 2000 else 'factual_late' if y < 2015 else 'ssp245'
            ni = np.array([i for i, d in enumerate(dates[nk]) if d.year == y])
            fi = np.array([i for i, d in enumerate(dates[fk]) if d.year == y])
            nd = [(dates[nk][i].month, dates[nk][i].day) for i in ni]
            fd = [(dates[fk][i].month, dates[fk][i].day) for i in fi]
            if len(ni) != 365 or nd != fd:
                raise ValueError(f'Pair/calendar mismatch {y}')
            delta = read_float(sets[fk].variables['tasmax'], (fi, slice(None), slice(None))) - read_float(sets[nk].variables['tasmax'], (ni, slice(None), slice(None)))
            if not np.isfinite(delta).all():
                raise ValueError(f'Missing paired values {y}')
            for m in range(1, 13):
                ix = [i for i, (month, _) in enumerate(nd) if month == m]
                sums[m - 1] += np.sum(delta[ix], axis=0, dtype=np.float64)
                counts[m - 1] += len(ix)
            gm = float(np.sum(np.mean(delta, axis=0, dtype=np.float64) * w) / (w.sum() * len(lon)))
            annual.append(gm)
            pair_qc.append(dict(year=y, days=365, factual_experiment='historical' if y < 2015 else 'ssp245', global_area_weighted_delta_C=gm, delta_min_C=float(delta.min()), delta_max_C=float(delta.max())))
            print(f'paired source {y}: global delta {gm:.4f} C', flush=True)
        clim = sums / counts[:, None, None]
        smooth = pd.Series(annual, index=YEARS).rolling(5, center=True, min_periods=2).mean().to_numpy()
        if not np.isfinite(smooth).all() or abs(smooth.mean()) < 1e-06:
            raise ValueError('Invalid/near-zero scaling denominator')
        scale = smooth / smooth.mean()
        for r, a, s in zip(pair_qc, smooth, scale):
            r.update(smoothed_global_delta_C=float(a), annual_scale=float(s))
        pd.DataFrame(pair_qc).to_csv(out / 'paired_temperature_qc.csv', index=False)
        pd.DataFrame(inventory).to_csv(out / 'paired_source_inventory.csv', index=False)
        np.savez_compressed(cache, latitude=lat, longitude=lon, monthly_climatology=clim.astype(np.float32), annual_scale=scale, years=np.array(YEARS))

def interpolated_signal(cache, lat, lon):
    slat = cache['latitude']
    slon = cache['longitude']
    clim = cache['monthly_climatology']
    plon = np.concatenate([slon[-1:] - 360, slon, slon[:1] + 360])
    padded = np.concatenate([clim[:, :, -1:], clim, clim[:, :, :1]], axis=2)
    mesh = np.meshgrid(np.clip(lat, slat[0], slat[-1]), lon % 360, indexing='ij')
    pts = np.stack([mesh[0].ravel(), mesh[1].ravel()], axis=-1)
    return np.stack([RegularGridInterpolator((slat, plon), padded[m], bounds_error=True)(pts).reshape(len(lat), len(lon)) for m in range(12)]).astype(np.float32)

def compute(out, geometry, tile_lat=52, tile_lon=103):
    rules = upstream_rules()
    cache = np.load(out / 'paired_monthly_signal.npz')
    masks = np.load(geometry / 'country_samplers.npz')
    with Dataset(CLIMATE / 'Tmax/Tmax_1990.nc') as ref:
        lat = read_float(ref.variables['latitude'], slice(None))
        lon = read_float(ref.variables['longitude'], slice(None))
    order = np.argsort((lon + 180) % 360 - 180)
    assert np.array_equal(lat, masks['latitude']) and np.array_equal(((lon + 180) % 360 - 180)[order], masks['longitude'])
    nlat, nlon = (len(lat), len(lon))
    occupied = np.zeros(nlat * nlon, bool)
    occupied[masks['indices']] = True
    occupied = occupied.reshape(nlat, nlon)[:, np.argsort(order)]
    monthly = interpolated_signal(cache, lat, lon)
    if not np.isfinite(monthly).all():
        raise ValueError('Interpolation missing values')
    np.savez_compressed(out / 'era5_monthly_signal.npz', monthly_signal_C=monthly, latitude=lat, longitude=lon)
    tiles = [(i, min(i + tile_lat, nlat), j, min(j + tile_lon, nlon)) for i in range(0, nlat, tile_lat) for j in range(0, nlon, tile_lon) if occupied[i:min(i + tile_lat, nlat), j:min(j + tile_lon, nlon)].any()]
    target = out / 'natural_forcing_annual_grids.nc'
    if target.exists():
        raise FileExistsError('Existing annual output; resume via a fresh output directory to avoid stale results')
    started = time.time()
    qc = []
    with ExitStack() as stack:
        tsets = [stack.enter_context(Dataset(CLIMATE / f'Tmax/Tmax_{y}.nc')) for y in YEARS]
        pset = stack.enter_context(Dataset(P90))
        rec = [rules.year_records(ds, y) for ds, y in zip(tsets, YEARS)]
        dates = [d for info in rec for d in info[1]]
        day_index = np.concatenate([r[2] for r in rec])
        yr = np.array([d.year for d in dates])
        month = np.array([d.month - 1 for d in dates])
        yindex = yr - 1990
        assert len(dates) == 31 * 365
        ds = stack.enter_context(Dataset(target, 'w'))
        for name, length in [('year', 31), ('latitude', nlat), ('longitude', nlon)]:
            ds.createDimension(name, length)
        for name, data in [('year', YEARS), ('latitude', lat), ('longitude', lon)]:
            ds.createVariable(name, 'f4' if name != 'year' else 'i4', (name,))[:] = data
        for metric in FIELDS:
            v = ds.createVariable(metric, 'f4', ('year', 'latitude', 'longitude'), fill_value=-9999, zlib=True, complevel=1, chunksizes=(1, tile_lat, tile_lon))
            v.units = 'degree_Celsius days'
            v.minimum_event_duration_days = 2
        ds.title = 'ERA5-based constructed natural-forcing counterfactual: BCC-CSM2-MR r1i1p1f1'
        ds.signal_method = '1990-2020 monthly historical-minus-histnat climatology times normalized 5-year smoothed global annual delta; SSP245 extension 2015-2020'
        ds.p90_reference_period = '1990-2020'
        ds.leap_day_handling = 'February29 excluded and interrupts events'
        ds.spatial_coverage = 'Only tiles containing country sample cells calculated; unused ocean tiles are fill values'
        for k, (i, ie, j, je) in enumerate(tiles):
            v = np.concatenate([read_float(s.variables['daily_max_t2m'], (r[0], slice(i, ie), slice(j, je))) for s, r in zip(tsets, rec)])
            if not np.isfinite(v).all():
                raise ValueError(f'ERA5 missing in tile {k}')
            cf = v - monthly[month, i:ie, j:je] * cache['annual_scale'].astype(np.float32)[yindex, None, None]
            p90 = read_float(pset.variables['tmax_p90'], (slice(None), slice(i, ie), slice(j, je)))[day_index]
            if not np.isfinite(p90).all():
                raise ValueError(f'P90 missing in tile {k}')
            for metric, b in [('ACH', 30.0), ('RCH', p90), ('MCH', np.maximum(30.0, p90))]:
                totals = rules.yearly_totals(np.maximum(cf - b, 0), np.isfinite(cf) & (cf > b), dates, YEARS, 2)
                if not np.isfinite(totals).all() or np.any(totals < 0):
                    raise ValueError('Invalid annual totals')
                ds.variables[metric][:, i:ie, j:je] = totals
            qc.append(dict(tile=k + 1, row=i, row_end=ie, col=j, col_end=je, days=len(dates), temperature_min_C=float(cf.min()), temperature_max_C=float(cf.max()), elapsed_seconds=round(time.time() - started, 1)))
            ds.sync()
            pd.DataFrame(qc).to_csv(out / 'tile_processing_qc.csv', index=False)
            print(f'country tile {k + 1}/{len(tiles)}; elapsed {time.time() - started:.0f}s', flush=True)

def aggregate(out, geometry):
    masks = np.load(geometry / 'country_samplers.npz')
    idx = masks['indices']
    w = masks['weights']
    offsets = masks['offsets']
    qc = pd.read_csv(geometry / 'country_sampling_qc.csv')
    hist = pd.read_csv(HIST)
    result = []
    identity = []
    with Dataset(out / 'natural_forcing_annual_grids.nc') as cf, Dataset(CLIMATE / 'Heat_indicators/heat_indicators_1990-2020.nc') as obs:
        lon = obs.variables['longitude'][:]
        order = np.argsort((lon + 180) % 360 - 180)
        assert np.array_equal(obs.variables['latitude'][:], masks['latitude'])
        for yi, y in enumerate(YEARS):
            arrays = {m: read_float(cf.variables[m], (yi, slice(None), slice(None)))[:, order].ravel() for m in FIELDS}
            original = {m: read_float(obs.variables[f], (yi, slice(None), slice(None)))[:, order].ravel() for m, f in FIELDS.items()}
            for c, row in qc.iterrows():
                sel = idx[offsets[c]:offsets[c + 1]]
                weights = w[offsets[c]:offsets[c + 1]]
                r = dict(row)
                r.update(year=y, model='BCC-CSM2-MR', member='r1i1p1f1', scenario='constructed_natural_forcing')
                for m in FIELDS:
                    v = arrays[m][sel]
                    a = original[m][sel]
                    if not np.isfinite(v).all() or not np.isfinite(a).all():
                        raise ValueError('Missing sampled cells')
                    r[m] = float(np.average(v, weights=weights))
                    r[m + '_observed_reaggregated'] = float(np.average(a, weights=weights))
                result.append(r)
    panel = pd.DataFrame(result).merge(hist[['fid', 'year', *FIELDS.values()]], on=['fid', 'year'], validate='one_to_one')
    for m, f in FIELDS.items():
        panel[m + '_observed'] = panel[f]
        panel[m + '_observed_minus_natural'] = panel[m + '_observed'] - panel[m]
        identity.append(dict(metric=m, max_abs_difference=float(np.max(np.abs(panel[m + '_observed_reaggregated'] - panel[f])))))
    panel = panel.drop(columns=list(FIELDS.values()))
    assert len(panel) == 7998 and (not panel.duplicated(['fid', 'year']).any())
    assert np.isfinite(panel[list(FIELDS)]).all().all()
    if max((r['max_abs_difference'] for r in identity)) > 1e-05:
        raise ValueError('Observed historical aggregation does not reproduce reference')
    panel.to_csv(out / 'BCC_constructed_natural_forcing_panel_1990_2020.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(identity).to_csv(out / 'observed_historical_reaggregation_check.csv', index=False)
    new = pd.read_csv(os.environ.get('HEAT_CVD_IHME_GBD_2021_DATA_403150E6_1_AGE_STANDARDIZED_PANEL_CSV', 'external_inputs/IHME-GBD_2021_DATA-403150e6-1_age_standardized_panel.csv'), usecols=['fid'])
    analytic = panel[panel.fid.isin(new.fid.dropna().unique())]
    analytic.to_csv(out / 'BCC_natural_forcing_203country_matched_panel.csv', index=False, encoding='utf-8-sig')
    summaries = []
    for label, p in [('258_regions', panel), ('203_analytic_countries', analytic)]:
        for m in FIELDS:
            summaries.append(dict(sample=label, metric=m, rows=len(p), countries=p.fid.nunique(), mean_observed=float(p[m + '_observed'].mean()), mean_natural=float(p[m].mean()), mean_contrast=float(p[m + '_observed_minus_natural'].mean()), negative_contrast_rows=int((p[m + '_observed_minus_natural'] < 0).sum()), missing_rows=int(p[m].isna().sum()), negative_exposure_rows=int((p[m] < 0).sum())))
    pd.DataFrame(summaries).to_csv(out / 'exposure_contrast_summary.csv', index=False)
    print(json.dumps({'panel_rows': len(panel), 'analytic_rows': len(analytic), 'aggregation_identity': identity, 'summaries': summaries}, indent=2), flush=True)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('output')
    ap.add_argument('--geometry', required=True)
    ap.add_argument('--stage', choices=['signal', 'compute', 'aggregate', 'all'], default='all')
    args = ap.parse_args()
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    geom = Path(args.geometry)
    if args.stage in ['all', 'signal']:
        signal(out)
    if args.stage in ['all', 'compute']:
        compute(out, geom)
    if args.stage in ['all', 'aggregate']:
        aggregate(out, geom)
    (out / f'{args.stage}_completed.json').write_text(json.dumps({'stage': args.stage, 'completed': True, 'timestamp_utc': pd.Timestamp.now(tz='UTC').isoformat()}, indent=2), encoding='utf-8')
if __name__ == '__main__':
    main()
