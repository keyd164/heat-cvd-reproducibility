"""Prepare exact upstream-compatible country samplers; run with Python 3.12 geo runtime."""
import os
from pathlib import Path
import argparse, hashlib, json
import numpy as np
import pandas as pd
import geopandas as gpd
from rasterio.features import geometry_mask
from rasterio.transform import from_origin
from shapely.geometry import mapping

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('output')
    args = ap.parse_args()
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    shp = Path(os.environ.get('HEAT_CVD_NE_10M_ADMIN_0_COUNTRIES_SHP', 'external_inputs/ne_10m_admin_0_countries.shp'))
    countries = gpd.read_file(shp).to_crs('EPSG:4326')
    invalid = ~countries.geometry.is_valid
    countries.loc[invalid, 'geometry'] = countries.loc[invalid, 'geometry'].map(lambda x: x.buffer(0))
    assert countries.geometry.is_valid.all() and (not countries.geometry.is_empty.any())
    assert not countries.fid1.duplicated().any() and (not countries.ADM0_A3.duplicated().any())
    lat = np.arange(90, -90.001, -0.25)
    lon = np.arange(-180, 180, 0.25)
    row_weights = np.sin(np.deg2rad(np.minimum(lat + 0.125, 90))) - np.sin(np.deg2rad(np.maximum(lat - 0.125, -90)))
    transform = from_origin(-180.125, 90.125, 0.25, 0.25)
    indices = []
    weights = []
    offsets = [0]
    rows = []
    for row in countries.itertuples(index=False):
        mask = geometry_mask([mapping(row.geometry)], out_shape=(721, 1440), transform=transform, invert=True, all_touched=False)
        idx = np.flatnonzero(mask)
        method = 'cell_center_area_weighted'
        if not len(idx):
            p = row.geometry.representative_point()
            i = int(np.argmin(np.abs(lat - p.y)))
            j = int(np.argmin(np.abs((lon - p.x + 180) % 360 - 180)))
            idx = np.array([i * 1440 + j])
            method = 'representative_point_nearest'
        indices.append(idx)
        weights.append(row_weights[idx // 1440])
        offsets.append(offsets[-1] + len(idx))
        rows.append(dict(fid=int(row.fid1), region_id=row.ADM0_A3, admin=row.ADMIN, sampling_method=method, sample_grid_cell_count=len(idx)))
    qc = pd.DataFrame(rows)
    ref = pd.read_csv(os.environ.get('HEAT_CVD_SAMPLING_QC_BY_REGION_CSV', 'external_inputs/sampling_qc_by_region.csv'))
    check = qc.merge(ref[['fid', 'sampling_method', 'sample_grid_cell_count']], on='fid', suffixes=('_recreated', '_historical'), validate='one_to_one')
    assert len(check) == 258
    check['matches'] = (check.sampling_method_recreated == check.sampling_method_historical) & (check.sample_grid_cell_count_recreated == check.sample_grid_cell_count_historical)
    check.to_csv(out / 'geometry_vs_historical_qc.csv', index=False, encoding='utf-8-sig')
    if not check.matches.all():
        raise ValueError('Country sampling differs from historical contract')
    qc.to_csv(out / 'country_sampling_qc.csv', index=False, encoding='utf-8-sig')
    np.savez_compressed(out / 'country_samplers.npz', indices=np.concatenate(indices), weights=np.concatenate(weights), offsets=np.asarray(offsets), latitude=lat, longitude=lon)
    hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in shp.parent.glob(shp.stem + '.*') if p.is_file()}
    (out / 'geometry_metadata.json').write_text(json.dumps({'shp_hashes': hashes, 'features': len(qc), 'matches_historical': int(check.matches.sum()), 'fallback_count': int((qc.sampling_method == 'representative_point_nearest').sum()), 'geometry_repair_count': int(invalid.sum())}, indent=2), encoding='utf-8')
    print('Country samplers verified:', len(qc), 'fallbacks:', int((qc.sampling_method == 'representative_point_nearest').sum()))
if __name__ == '__main__':
    main()
