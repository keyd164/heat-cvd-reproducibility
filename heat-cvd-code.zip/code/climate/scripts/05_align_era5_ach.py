"""ERA5-referenced annual ACH change-factor panel; no daily bias-correction claim.

Run with Python and the documented external climate inputs.
Only future scenario exposure outputs are written. Existing analyses stay intact.
"""
import os
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys
from datetime import date, timedelta
if Path(os.environ.get('HEAT_CVD_NETCDF4', 'external_inputs/netCDF4')).exists():
    sys.path.insert(0, os.environ.get('HEAT_CVD_SITE_PACKAGES', 'external_inputs/site-packages'))
import numpy as np
import pandas as pd
from netCDF4 import Dataset, num2date
PROJECT = Path(__file__).resolve().parents[1]
ERA5 = Path(os.environ.get('HEAT_CVD_COUNTRY_HEAT_REGION_YEAR_PANEL_1990_2020_CSV', 'external_inputs/country_heat_region_year_panel_1990_2020.csv'))
MODELS = ['BCC-CSM2-MR', 'CanESM5']
SSPS = ['ssp126', 'ssp245', 'ssp370', 'ssp585']
REFERENCE = list(range(2016, 2021))

def load_module(filename, name):
    spec = importlib.util.spec_from_file_location(name, PROJECT / 'scripts' / filename)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def require(condition, message):
    if not bool(condition):
        raise ValueError(message)

def align(frame, anchors):
    """One model-specific SSP245 offset for all scenarios; no clipping."""
    d = frame.merge(anchors, on=['fid', 'model', 'member'], how='left', validate='many_to_one')
    require(d.ERA5_reference_ACH.notna().all() and d.model_reference_ACH.notna().all(), 'Unmatched anchor')
    d['delta_ACH_vs_reference'] = d.ACH_raw - d.model_reference_ACH
    d['ACH_era5_anchored_linear'] = d.ERA5_reference_ACH + d.delta_ACH_vs_reference
    d['anchored_level_below_zero'] = d.ACH_era5_anchored_linear < 0
    d['absolute_level_supported'] = ~d.anchored_level_below_zero
    d['reference_period'] = '2016-2020'
    d['reference_scenario'] = 'ssp245'
    d['alignment_method'] = 'annual_ACH_additive_change_factor'
    d['unit'] = 'degC_days'
    return d

def reference_panel(model, inventory, out):
    events = load_module('03_heat_event_detection.py', 'future_events')
    aggregation = load_module('04_country_aggregation.py', 'future_aggregation')
    geo = PROJECT / 'data_processed/native_geometry'
    sampler = geo / f'{model}_country_samplers.npz'
    z = np.load(sampler)
    indices = np.unique(z['indices'])
    qc = pd.read_csv(geo / f'{model}_country_sampling_qc.csv')
    grid = json.loads((geo / f'{model}_grid.json').read_text())
    w = aggregation.country_weights(z, indices)
    engine = events.TwoDayEvents(range(2015, 2022), len(indices), metrics=1)
    rows = inventory[(inventory.source_id == model) & (inventory.experiment_id == 'ssp245') & (inventory.variant_label == 'r1i1p1f1') & (inventory.variable_id == 'tasmax') & (inventory.first_year <= 2022) & (inventory.last_year >= 2015)].sort_values('first')
    seen = set()
    dates_saved, samples, sources = ([], [], [])
    picked = np.linspace(0, len(indices) - 1, 8, dtype=int)
    threshold = np.full((1, len(indices)), 30.0, np.float32)
    last = None
    for r in rows.itertuples():
        with Dataset(r.path) as ds:
            require(ds.source_id == model and ds.variant_label == 'r1i1p1f1' and (ds.experiment_id == 'ssp245'), 'Source identity')
            require(np.array_equal(ds['lat'][:], grid['latitude']) and np.array_equal(ds['lon'][:], grid['longitude']), 'Grid mismatch')
            t = ds['time']
            require(t.calendar in ('365_day', 'noleap'), 'Unsupported calendar')
            dates = num2date(t[:], t.units, calendar=t.calendar)
            use = [i for i, d in enumerate(dates) if (2015, 1, 1) <= (d.year, d.month, d.day) <= (2022, 1, 1)]
            if not use:
                continue
            require(use == list(range(use[0], use[-1] + 1)), 'Non-contiguous input')
            require(ds['tasmax'].units == 'K', 'Temperature unit')
            for start in range(use[0], use[-1] + 1, 60):
                stop = min(start + 60, use[-1] + 1)
                a = np.asarray(np.ma.filled(ds['tasmax'][start:stop], np.nan), np.float32).reshape(stop - start, -1)[:, indices] - np.float32(273.15)
                require(np.isfinite(a).all(), 'Non-finite native temperatures')
                for j, item in enumerate(dates[start:stop]):
                    day = date(item.year, item.month, item.day)
                    require(day not in seen and (last is None or day > last), 'Duplicate or unsorted date')
                    seen.add(day)
                    last = day
                    engine.push(day, a[j], threshold)
                    dates_saved.append(day)
                    samples.append(a[j, picked])
            p = Path(r.path)
            sources.append(dict(path=str(p), bytes=p.stat().st_size, mtime_ns=p.stat().st_mtime_ns, provenance='full time coordinate and selected native temperature values read; no full-file hash'))
            print(f'{model}: reference ACH through {dates_saved[-1]}', flush=True)
    expected = set()
    d = date(2015, 1, 1)
    while d <= date(2022, 1, 1):
        if (d.month, d.day) != (2, 29):
            expected.add(d)
        d += timedelta(days=1)
    require(seen == expected, 'Reference daily coverage')
    totals = engine.finish()[0]
    annual = w.dot(totals.T).T
    result = pd.DataFrame({'fid': np.tile(qc.fid.to_numpy(), 7), 'region_id': np.tile(qc.region_id.to_numpy(), 7), 'country': np.tile(qc.country.to_numpy(), 7), 'year': np.repeat(range(2015, 2022), 203), 'ACH_raw': annual.reshape(-1), 'model': model, 'member': 'r1i1p1f1', 'ssp': 'ssp245'})
    upstream = events.upstream_module()
    temp = np.stack(samples)
    independent = upstream.yearly_totals(np.maximum(temp - 30.0, 0)[:, :, None], (temp > 30.0)[:, :, None], dates_saved, list(range(2015, 2022)), 2)[:, :, 0]
    np.testing.assert_allclose(totals[:, picked], independent, rtol=2e-06, atol=0.0001)
    existing = pd.read_csv(PROJECT / f'outputs/annual_panel/model_level/{model}_ssp245_country_year_2021_2100.csv')
    comparison = result[result.year == 2021].merge(existing[existing.year == 2021][['fid', 'ACH']], on='fid', validate='one_to_one')
    error = float(abs(comparison.ACH_raw - comparison.ACH).max())
    require(error < 1e-08, 'Reference pipeline differs from future pipeline')
    result.to_csv(out / f'{model}_ssp245_reference_country_year_2015_2021.csv', index=False)
    return (result, dict(model=model, source_files=sources, sampler_sha256=sha(sampler), full_reference_days=len(seen), countries=203, independent_event_cells=8, independent_event_max_difference=float(abs(totals[:, picked] - independent).max()), future_2021_identity_max_difference=error))

def main(out, era5_path, kace_root=None):
    out.mkdir(parents=True, exist_ok=True)
    models = MODELS + (['KACE-1-0-G'] if kace_root is not None else [])
    protocol = dict(method='annual_ACH_additive_change_factor', reference_years=REFERENCE, models=models, KACE_calendar_policy=json.loads((kace_root / 'calendar_policy.json').read_text()) if kace_root else None, model_reference='SSP245, common to all four SSPs within each model/member', formula='ERA5_country_reference_mean + model_SSP_country_year_ACH - model_SSP245_country_reference_mean', reference_choice='2016-2020 excludes 2015 left boundary without December 2014 context; chosen before results', signed_changes=True, clip_negative_levels=False, estimand='ERA5-referenced scenario ACH change; linear anchored level is an index, not validated physical exposure', daily_bias_correction=False, health_model_changed=False, limitations=['short five-year common reference', 'raw model ACH change transfer assumed; threshold bias not repaired', 'native model and ERA5 country samplers differ', 'no health transferability validation', 'negative anchored levels flagged, never used as physical absolute exposure', 'small model ensemble is not a probabilistic uncertainty ensemble'])
    path = out / 'protocol.json'
    encoded = json.dumps(protocol, ensure_ascii=False, indent=2)
    if path.exists():
        require(path.read_text(encoding='utf-8') == encoded, 'Changed protocol: use fresh output')
    path.write_text(encoded, encoding='utf-8')
    invpath = PROJECT / 'outputs/qc/file_inventory.csv'
    inventory = pd.read_csv(invpath)
    obs = pd.read_csv(era5_path)
    source_paths = [era5_path, invpath, PROJECT / 'outputs/qc/country_year_panel_acceptance.json', PROJECT / 'outputs/qc/qc_2100_end_boundary_country.csv']
    for model in models:
        geometry_root = kace_root if model == 'KACE-1-0-G' else PROJECT
        for suffix in ['_country_samplers.npz', '_country_sampling_qc.csv', '_grid.json']:
            source_paths.append(geometry_root / 'data_processed/native_geometry' / f'{model}{suffix}')
    if kace_root:
        source_paths.extend([kace_root / 'kace_acceptance.json', kace_root / 'calendar_policy.json'])
    frames, refs, checks, anchor_rows = ([], [], [], [])
    for model in models:
        if model == 'KACE-1-0-G':
            kace_check = json.loads((kace_root / 'kace_acceptance.json').read_text())
            require(kace_check['completed'], 'KACE computation not complete')
            p = kace_root / 'raw_model_panels/KACE-1-0-G_ssp245_country_year_2015_2100.csv'
            source_paths.append(p)
            ref = pd.read_csv(p).query('2015 <= year <= 2021').rename(columns={'ACH': 'ACH_raw'})
            ref.to_csv(out / f'{model}_ssp245_reference_country_year_2015_2021.csv', index=False)
            check = dict(model=model, full_time_independent_event_check=kace_check, reference_reuses_full_future_run=True, separate_2021_rerun=False)
        else:
            ref, check = reference_panel(model, inventory, out)
        refs.append(ref)
        checks.append(check)
        ids = set(ref.fid)
        require(len(ids) == 203, 'Country sample')
        o = obs[obs.fid.isin(ids) & obs.year.isin(REFERENCE)].copy()
        require(len(o) == 1015 and (not o.duplicated(['fid', 'year']).any()), 'ERA5 reference keys')
        require(np.isfinite(o.absolute_cumulative_heat).all() and (o.absolute_cumulative_heat >= 0).all(), 'ERA5 values')
        mapping = ref[['fid', 'region_id']].drop_duplicates().merge(o[['fid', 'region_id']].drop_duplicates(), on='fid', validate='one_to_one')
        require(mapping.region_id_x.eq(mapping.region_id_y).all(), 'Country identity mismatch')
        a = ref[ref.year.isin(REFERENCE)].groupby(['fid', 'model', 'member'], as_index=False).ACH_raw.mean().rename(columns={'ACH_raw': 'model_reference_ACH'})
        a = a.merge(o.groupby('fid', as_index=False).absolute_cumulative_heat.mean().rename(columns={'absolute_cumulative_heat': 'ERA5_reference_ACH'}), on='fid', validate='one_to_one')
        a['offset_ACH'] = a.ERA5_reference_ACH - a.model_reference_ACH
        anchor_rows.append(a)
        for ssp in SSPS:
            p = kace_root / f'raw_model_panels/{model}_{ssp}_country_year_2015_2100.csv' if model == 'KACE-1-0-G' else PROJECT / f'outputs/annual_panel/model_level/{model}_{ssp}_country_year_2021_2100.csv'
            source_paths.append(p)
            d = pd.read_csv(p)
            d = d[d.year.between(2021, 2100)].copy()
            require(len(d) == 16240 and set(d.fid) == ids and (set(d.year) == set(range(2021, 2101))) and (not d.duplicated(['fid', 'year']).any()), 'Future sample/keys')
            require(d.model.eq(model).all() and d.ssp.eq(ssp).all() and d.member.eq('r1i1p1f1').all(), 'Future identity')
            require(np.isfinite(d.ACH).all() and (d.ACH >= 0).all(), 'Future values')
            aligned = align(d[['fid', 'region_id', 'country', 'year', 'model', 'member', 'ssp', 'ACH']].rename(columns={'ACH': 'ACH_raw'}), a)
            aligned['source_calendar'] = '360_day' if model == 'KACE-1-0-G' else '365_day'
            aligned['calendar_policy'] = 'fractional_year_linear_to_365_then_Gregorian_gaps' if model == 'KACE-1-0-G' else 'existing_365_Gregorian_gaps'
            frames.append(aligned)
    anchors = pd.concat(anchor_rows, ignore_index=True)
    anchors.to_csv(out / 'country_model_calibration_anchors.csv', index=False)
    model_panel = pd.concat(frames, ignore_index=True).sort_values(['ssp', 'model', 'fid', 'year'])
    require(len(model_panel) == 64960 * len(models) and (not model_panel.duplicated(['fid', 'year', 'model', 'member', 'ssp']).any()), 'Model panel keys')
    model_panel.to_csv(out / 'SSP_ERA5_ACH_model_country_year_2021_2100.csv', index=False)
    ref_all = pd.concat(refs, ignore_index=True)
    fit = align(ref_all[ref_all.year.isin(REFERENCE)], anchors)
    mean = fit.groupby(['fid', 'model', 'member'], as_index=False).ACH_era5_anchored_linear.mean().merge(anchors, on=['fid', 'model', 'member'])
    anchor_error = float(abs(mean.ACH_era5_anchored_linear - mean.ERA5_reference_ACH).max())
    require(anchor_error < 1e-08, 'Anchor mean identity')
    np.testing.assert_allclose(model_panel.ACH_era5_anchored_linear - model_panel.ERA5_reference_ACH, model_panel.delta_ACH_vs_reference, atol=1e-10)
    pairs = model_panel.pivot(index=['fid', 'year', 'model', 'member'], columns='ssp', values=['ACH_raw', 'ACH_era5_anchored_linear'])
    pair_error = 0.0
    for ssp in SSPS[1:]:
        err = abs(pairs['ACH_raw'][ssp] - pairs['ACH_raw']['ssp126'] - (pairs['ACH_era5_anchored_linear'][ssp] - pairs['ACH_era5_anchored_linear']['ssp126'])).max()
        pair_error = max(pair_error, float(err))
    require(pair_error < 1e-08, 'Scenario contrast preservation')
    ensemble = model_panel.groupby(['fid', 'region_id', 'country', 'year', 'ssp'], as_index=False).agg(ACH_raw=('ACH_raw', 'mean'), ERA5_reference_ACH=('ERA5_reference_ACH', 'mean'), delta_ACH_vs_reference=('delta_ACH_vs_reference', 'mean'), ACH_era5_anchored_linear=('ACH_era5_anchored_linear', 'mean'), delta_ACH_model_min=('delta_ACH_vs_reference', 'min'), delta_ACH_model_max=('delta_ACH_vs_reference', 'max'), n_models=('model', 'nunique'), any_model_level_below_zero=('anchored_level_below_zero', 'any'))
    require(len(ensemble) == 64960 and ensemble.n_models.eq(len(models)).all(), 'Ensemble coverage')
    ensemble['anchored_level_below_zero'] = ensemble.ACH_era5_anchored_linear < 0
    ensemble['absolute_level_supported'] = ~ensemble.anchored_level_below_zero
    ensemble['reference_period'] = '2016-2020'
    ensemble['reference_scenario'] = 'ssp245'
    ensemble['unit'] = 'degC_days'
    ensemble.to_csv(out / 'SSP_ERA5_ACH_country_year_2021_2100.csv', index=False)
    for ssp in SSPS:
        ensemble[ensemble.ssp == ssp].to_csv(out / f'SSP_ERA5_ACH_{ssp}_2021_2100.csv', index=False)
    periods = ensemble.copy()
    periods['period'] = pd.cut(periods.year, [2020, 2040, 2060, 2080, 2100], labels=['2021-2040', '2041-2060', '2061-2080', '2081-2100'])
    summary = periods.groupby(['ssp', 'period'], observed=True, as_index=False)[['ERA5_reference_ACH', 'delta_ACH_vs_reference', 'ACH_era5_anchored_linear']].mean()
    summary.to_csv(out / 'SSP_ERA5_ACH_period_equal_country_summary.csv', index=False)
    negatives = model_panel[model_panel.anchored_level_below_zero]
    negatives.to_csv(out / 'QC_negative_anchored_levels.csv', index=False)
    model_panel.groupby(['model', 'ssp'], as_index=False).agg(rows=('fid', 'size'), negative_levels=('anchored_level_below_zero', 'sum'), min_anchored_level=('ACH_era5_anchored_linear', 'min')).to_csv(out / 'QC_alignment_summary.csv', index=False)
    obs[obs.fid.isin(set(ensemble.fid)) & obs.year.isin(REFERENCE)][['fid', 'region_id', 'year', 'absolute_cumulative_heat']].to_csv(out / 'ERA5_reference_country_year_2016_2020.csv', index=False)
    required = ['ACH_raw', 'ERA5_reference_ACH', 'delta_ACH_vs_reference', 'ACH_era5_anchored_linear']
    require(np.isfinite(model_panel[required]).all().all() and np.isfinite(ensemble[required]).all().all(), 'Non-finite result')
    for p in out.glob('SSP_ERA5_ACH*2021_2100.csv'):
        loaded = pd.read_csv(p)
        require(len(loaded) > 0 and np.isfinite(loaded[required]).all().all(), 'CSV reread failed')
    manifest = dict(completed=True, status='ERA5_referenced_annual_change_factor_panel', countries=203, models=models, SSPs=SSPS, years=[2021, 2100], ensemble_rows=64960, model_rows=len(model_panel), anchor_mean_max_error=anchor_error, scenario_contrast_max_error=pair_error, model_negative_levels=len(negatives), ensemble_negative_levels=int(ensemble.anchored_level_below_zero.sum()), full_country_reference_checks=checks, independent_daily_bias_correction_validated=False, health_translation_executed=False, protocol=protocol, checks=['203-country identity and complete years', 'independent native-cell event algorithm', '2021 reproduction against existing future run', 'reference mean identity', 'scenario contrast preservation', 'finite signed changes', 'equal model means', 'delivered CSV reread'], inputs_sha256={str(p.resolve()): sha(p) for p in source_paths}, script_sha256=sha(Path(__file__)), dependency_sha256={str(p): sha(p) for p in [PROJECT / 'scripts/03_heat_event_detection.py', PROJECT / 'scripts/04_country_aggregation.py', PROJECT / 'scripts/05_align_era5_ach.py', PROJECT / 'scripts/07_build_kace_ach.py', PROJECT / 'config.json', Path(os.environ.get('HEAT_CVD_CALCULATE_HEAT_INDICATORS_PY', 'external_inputs/calculate_heat_indicators.py'))]}, outputs_sha256={p.name: sha(p) for p in out.glob('*.csv')})
    (out / 'acceptance.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k: manifest[k] for k in ['status', 'ensemble_rows', 'model_rows', 'model_negative_levels', 'ensemble_negative_levels', 'anchor_mean_max_error', 'scenario_contrast_max_error']}, ensure_ascii=False), flush=True)
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--era5', type=Path, default=ERA5)
    parser.add_argument('--kace-root', type=Path, help='Include verified KACE four-SSP ACH and its calendar policy')
    args = parser.parse_args()
    main(args.output, args.era5, args.kace_root)
