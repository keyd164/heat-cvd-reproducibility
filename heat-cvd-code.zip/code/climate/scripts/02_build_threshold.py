"""Stage 1: full native-grid Tasmax value QC and scenario-specific fixed P90.

Country means are never calculated before events. This stage only prepares
native-grid samplers and calendar-day thresholds. Source netCDF IO occurs in
isolated processes; Dask threads operate only on in-memory reference arrays.
"""
import os
from pathlib import Path
import sys
PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / '.deps'))
if Path(os.environ.get('HEAT_CVD_NETCDF4', 'external_inputs/netCDF4')).exists():
    sys.path.insert(0, os.environ.get('HEAT_CVD_SITE_PACKAGES', 'external_inputs/site-packages'))
import argparse, json, hashlib, time
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np
import pandas as pd
from netCDF4 import Dataset, num2date
import dask
VERSION = 'native-values-p90-v1'
PERIODS = {'2015_2034': (2015, 2034), '2021_2040': (2021, 2040)}
SSPS = ['ssp126', 'ssp245', 'ssp370', 'ssp585']

def file_signature(p):
    p = Path(p)
    s = p.stat()
    return dict(path=str(p.resolve()), bytes=s.st_size, mtime_ns=s.st_mtime_ns)

def selected_models(project):
    c = pd.read_csv(project / 'outputs/qc/models_common.csv')
    return c[c.eligible_for_next_stage == True]

def export_grids(project):
    inventory = pd.read_csv(project / 'outputs/qc/file_inventory.csv')
    out = project / 'data_processed/native_geometry'
    out.mkdir(parents=True, exist_ok=True)
    for r in selected_models(project).itertuples():
        selected = inventory[(inventory.source_id == r.model) & (inventory.variant_label == r.member)]
        if selected.coordinate_sha256.nunique() != 1:
            raise ValueError('Cross-scenario native grids differ: ' + r.model)
        with Dataset(selected.iloc[0].path) as ds:
            lat = np.asarray(ds.variables['lat'][:], dtype=float)
            lon = np.asarray(ds.variables['lon'][:], dtype=float)
            lb = np.asarray(ds.variables[ds.variables['lat'].bounds][:], dtype=float)
            ob = np.asarray(ds.variables[ds.variables['lon'].bounds][:], dtype=float)
            info = dict(model=r.model, member=r.member, grid=r.grid, calendar=r.calendar, latitude=lat.tolist(), longitude=lon.tolist(), latitude_bounds=lb.tolist(), longitude_bounds=ob.tolist(), coordinate_sha256=selected.iloc[0].coordinate_sha256)
        (out / f'{r.model}_grid.json').write_text(json.dumps(info, indent=2), encoding='utf-8')
        print(f'Grid exported {r.model}: {len(lat)} x {len(lon)}', flush=True)

def day_percentile(reference, doy, window=7):
    ix = (np.arange(doy - window, doy + window + 1) % 365).astype(int)
    sample = reference[:, ix, :].reshape(-1, reference.shape[-1])
    contiguous = np.ascontiguousarray(sample.T)
    if np.isfinite(contiguous).all():
        p = np.percentile(contiguous, 90, axis=1, method='linear', overwrite_input=True)
    else:
        p = np.nanpercentile(contiguous, 90, axis=1, method='linear', overwrite_input=True)
    return np.asarray(p, dtype=np.float32)

def calculate_p90(reference, threads, callback=None):
    delayed_ref = dask.delayed(reference, pure=False)
    out = np.empty((365, reference.shape[-1]), np.float32)
    for start in range(0, 365, 20):
        ds = list(range(start, min(start + 20, 365)))
        tasks = [dask.delayed(day_percentile, pure=False)(delayed_ref, d) for d in ds]
        values = dask.compute(*tasks, scheduler='threads', num_workers=threads)
        out[ds] = np.stack(values)
        if callback:
            callback(ds[-1] + 1)
    return out

def write_threshold(path, data, grid, meta):
    temp = path.with_suffix('.partial.nc')
    nlat, nlon = (len(grid['latitude']), len(grid['longitude']))
    with Dataset(temp, 'w', format='NETCDF4') as ds:
        for name, size in [('dayofyear', 365), ('lat', nlat), ('lon', nlon), ('bounds', 2)]:
            ds.createDimension(name, size)
        ds.createVariable('dayofyear', 'i2', ('dayofyear',))[:] = np.arange(1, 366)
        ds.createVariable('lat', 'f8', ('lat',))[:] = grid['latitude']
        ds.variables['lat'].units = 'degrees_north'
        ds.variables['lat'].bounds = 'lat_bnds'
        ds.createVariable('lon', 'f8', ('lon',))[:] = grid['longitude']
        ds.variables['lon'].units = 'degrees_east'
        ds.variables['lon'].bounds = 'lon_bnds'
        ds.createVariable('lat_bnds', 'f8', ('lat', 'bounds'))[:] = grid['latitude_bounds']
        ds.createVariable('lon_bnds', 'f8', ('lon', 'bounds'))[:] = grid['longitude_bounds']
        v = ds.createVariable('tasmax_p90', 'f4', ('dayofyear', 'lat', 'lon'), zlib=True, complevel=2, fill_value=-9999.0, chunksizes=(1, min(40, nlat), min(80, nlon)))
        values = np.ma.masked_invalid(data.reshape(365, nlat, nlon))
        v[:] = values
        v.units = 'degree_Celsius'
        v.percentile = 90.0
        v.window_radius_days = 7
        v.potential_samples = 300
        v.quantile_method = 'numpy linear'
        for key, value in meta.items():
            ds.setncattr(key, value)
        ds.threshold_group = 'model x member x scenario'
        ds.reference_calendar = '365_day'
        ds.threshold_fixed_in_future = 'true'
        ds.leap_day_policy = 'February 29 excluded and breaks event continuity at the subsequent event stage'
        ds.scientific_scope = 'Raw CMIP6 scenario-relative exposure preparation; no ERA5 bias adjustment or health attribution'
    temp.replace(path)

def compute_one(project, model, member, ssp, threads):
    project = Path(project)
    started = time.time()
    inventory = pd.read_csv(project / 'outputs/qc/file_inventory.csv')
    selected = inventory[(inventory.source_id == model) & (inventory.variant_label == member) & (inventory.experiment_id == ssp)].sort_values('first')
    geo = project / 'data_processed/native_geometry'
    grid = json.loads((geo / f'{model}_grid.json').read_text(encoding='utf-8'))
    sampler = np.load(geo / f'{model}_country_samplers.npz')
    country_idx = np.unique(sampler['indices'])
    out = project / 'data_processed/thresholds' / model / ssp
    out.mkdir(parents=True, exist_ok=True)
    qcout = project / 'outputs/qc/temperature_values'
    qcout.mkdir(parents=True, exist_ok=True)
    completion = out / 'completed.json'
    signature = dict(version=VERSION, script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), sources=[file_signature(p) for p in selected.path], sampler_sha256=hashlib.sha256((geo / f'{model}_country_samplers.npz').read_bytes()).hexdigest(), config_sha256=hashlib.sha256((project / 'config.json').read_bytes()).hexdigest())
    if completion.exists():
        previous = json.loads(completion.read_text(encoding='utf-8'))
        if previous['signature'] == signature and all(((out / f'tasmax_p90_{p}.nc').exists() for p in PERIODS)):
            return previous
        raise ValueError('Existing outputs have a changed input/configuration; use a fresh output directory')
    nlat, nlon = (len(grid['latitude']), len(grid['longitude']))
    cells = nlat * nlon
    reference = np.full((26 * 365, cells), np.nan, np.float32)
    reference_seen = np.zeros(26 * 365, bool)
    qc = {y: dict(model=model, member=member, ssp=ssp, year=y, days_read=0, global_values=0, global_missing_values=0, country_values=0, country_missing_values=0, min_C=np.inf, max_C=-np.inf) for y in range(2015, 2101)}
    day_codes = set()
    for row in selected.itertuples():
        with Dataset(row.path) as ds:
            assert ds.source_id == model and ds.variant_label == member and (ds.experiment_id == ssp)
            assert getattr(ds.variables['time'], 'calendar', 'standard') in ('365_day', 'noleap')
            assert np.array_equal(np.asarray(ds.variables['lat'][:]), grid['latitude']) and np.array_equal(np.asarray(ds.variables['lon'][:]), grid['longitude'])
            t = ds.variables['time']
            dates = num2date(t[:], t.units, calendar=t.calendar)
            positions = [i for i, d in enumerate(dates) if 2015 <= d.year <= 2100]
            if not positions:
                continue
            assert positions == list(range(positions[0], positions[-1] + 1))
            v = ds.variables['tasmax']
            assert v.dimensions == ('time', 'lat', 'lon')
            assert v.units == 'K'
            for start in range(positions[0], positions[-1] + 1, 60):
                stop = min(start + 60, positions[-1] + 1)
                data = np.asarray(np.ma.filled(v[start:stop, :, :], np.nan), dtype=np.float32).reshape(stop - start, cells) - np.float32(273.15)
                finite = np.isfinite(data)
                finite &= np.abs(data) < 10000000000.0
                data[~finite] = np.nan
                year = np.array([d.year for d in dates[start:stop]])
                for y in np.unique(year):
                    mask = year == y
                    z = data[mask]
                    valid = finite[mask]
                    cvalid = valid[:, country_idx]
                    r = qc[int(y)]
                    r['days_read'] += int(mask.sum())
                    r['global_values'] += z.size
                    r['global_missing_values'] += int((~valid).sum())
                    r['country_values'] += cvalid.size
                    r['country_missing_values'] += int((~cvalid).sum())
                    if valid.any():
                        r['min_C'] = min(r['min_C'], float(np.nanmin(z)))
                        r['max_C'] = max(r['max_C'], float(np.nanmax(z)))
                for j, d in enumerate(dates[start:stop]):
                    key = (d.year, d.month, d.day)
                    if key in day_codes:
                        raise ValueError('Duplicate read date')
                    day_codes.add(key)
                    if d.year <= 2040:
                        slot = (d.year - 2015) * 365 + int(d.dayofyr) - 1
                        assert not reference_seen[slot]
                        reference[slot] = data[j]
                        reference_seen[slot] = True
            print(f'{model}/{ssp}: full values checked {row.first_year}-{row.last_year}', flush=True)
    frame = pd.DataFrame(qc.values())
    frame.to_csv(qcout / f'{model}_{ssp}_yearly.csv', index=False)
    assert (frame.days_read == 365).all() and len(day_codes) == 86 * 365 and reference_seen.all()
    if frame.country_missing_values.sum() > 0:
        raise ValueError(f'Missing target country cells in {model}/{ssp}; thresholds blocked, see yearly QC')
    thresholds = []
    yearly = reference.reshape(26, 365, cells)
    for label, (a, b) in PERIODS.items():
        ref = yearly[a - 2015:b - 2015 + 1]

        def progress(done):
            if done % 100 == 0 or done == 365:
                print(f'{model}/{ssp} P90 {label}: {done}/365 calendar days', flush=True)
        threshold = calculate_p90(ref, threads, progress)
        assert np.isfinite(threshold[:, country_idx]).all()
        target = out / f'tasmax_p90_{label}.nc'
        meta = dict(model=model, member=member, scenario=ssp, grid=grid['grid'], reference_period=f'{a}-01-01 to {b}-12-31', source_coordinate_sha256=grid['coordinate_sha256'])
        write_threshold(target, threshold, grid, meta)
        spot = []
        picked = country_idx[np.linspace(0, len(country_idx) - 1, min(12, len(country_idx)), dtype=int)]
        for doy in (0, 58, 181, 364):
            ix = (np.arange(doy - 7, doy + 8) % 365).astype(int)
            raw = ref[:, ix, :][:, :, picked].reshape(300, len(picked))
            expected = np.percentile(raw, 90, axis=0, method='linear').astype(np.float32)
            np.testing.assert_array_equal(threshold[doy, picked], expected)
            spot.append(dict(model=model, ssp=ssp, reference=label, dayofyear=doy + 1, cells=len(picked), max_abs_difference_C=float(np.max(abs(threshold[doy, picked] - expected)))))
        pd.DataFrame(spot).to_csv(out / f'p90_spot_check_{label}.csv', index=False)
        thresholds.append(dict(reference=label, path=str(target), global_finite_cells_days=int(np.isfinite(threshold).sum()), global_missing_cells_days=int((~np.isfinite(threshold)).sum()), country_missing_cells_days=int((~np.isfinite(threshold[:, country_idx])).sum()), min_C=float(np.nanmin(threshold)), max_C=float(np.nanmax(threshold)), sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
    result = dict(model=model, member=member, ssp=ssp, completed=True, signature=signature, days_checked=86 * 365, global_values_checked=int(frame.global_values.sum()), global_missing_values=int(frame.global_missing_values.sum()), country_missing_values=int(frame.country_missing_values.sum()), min_C=float(frame.min_C.min()), max_C=float(frame.max_C.max()), thresholds=thresholds, elapsed_seconds=round(time.time() - started, 1), dask_version=dask.__version__, dask_threads=threads)
    completion.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding='utf-8')
    print(f'{model}/{ssp}: values + both P90 periods complete', flush=True)
    return result

def compute_all(project, workers, threads):
    jobs = [(r.model, r.member, s) for r in selected_models(project).itertuples() for s in SSPS]
    results = []
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(compute_one, str(project), m, v, s, threads) for m, v, s in jobs]
        for f in as_completed(futures):
            results.append(f.result())
            (project / 'outputs/qc/stage1_progress.json').write_text(json.dumps({'completed_scenarios': len(results), 'total_scenarios': len(jobs)}, indent=2), encoding='utf-8')
    (project / 'outputs/qc/stage1_completed.json').write_text(json.dumps({'completed': True, 'models': sorted({r['model'] for r in results}), 'scenarios_per_model': 4, 'threshold_files': sum((len(r['thresholds']) for r in results)), 'temperature_qc': results, 'annual_panel_generated': False}, indent=2, ensure_ascii=False), encoding='utf-8')
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--project', type=Path, default=PROJECT)
    ap.add_argument('--stage', choices=['export-grids', 'compute'], required=True)
    ap.add_argument('--workers', type=int, default=2)
    ap.add_argument('--threads', type=int, default=2)
    args = ap.parse_args()
    export_grids(args.project) if args.stage == 'export-grids' else compute_all(args.project, args.workers, args.threads)
