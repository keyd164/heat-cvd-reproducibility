"""Area-weight annual native-cell heat metrics into country-year panels.

Main deliverable: one 203-country x 80-year panel for each SSP. Model-level
results and threshold-reference sensitivity remain separate traceable tables.
"""
import os
from pathlib import Path
import sys
PROJECT = Path(__file__).resolve().parents[1]
if Path(os.environ.get('HEAT_CVD_NETCDF4', 'external_inputs/netCDF4')).exists():
    sys.path.insert(0, os.environ.get('HEAT_CVD_SITE_PACKAGES', 'external_inputs/site-packages'))
import argparse, json, hashlib
import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix
from netCDF4 import Dataset
YEARS = np.arange(2021, 2101)
METRICS = ['ACH', 'RCH', 'MCH']
SSPS = ['ssp126', 'ssp245', 'ssp370', 'ssp585']

def country_weights(z, indices):
    lookup = {int(v): i for i, v in enumerate(indices)}
    rows = np.repeat(np.arange(203), np.diff(z['offsets']))
    cols = np.array([lookup[int(i)] for i in z['indices']], dtype=int)
    sums = np.add.reduceat(z['weights'], z['offsets'][:-1])
    w = z['weights'] / sums[rows]
    matrix = csr_matrix((w, (rows, cols)), shape=(203, len(indices)))
    np.testing.assert_allclose(np.asarray(matrix.sum(1)).ravel(), 1.0, atol=1e-12)
    return matrix

def add_changes(frame):
    out = frame.copy()
    for m in METRICS:
        baseline = out[out.year.between(2021, 2040)].groupby('fid')[m].mean()
        out['d' + m] = out[m] - out.fid.map(baseline)
    return out

def model_panel(qc, model, member, ssp, country_values, reference):
    frame = pd.DataFrame({'fid': np.tile(qc.fid.to_numpy(), 80), 'region_id': np.tile(qc.region_id.to_numpy(), 80), 'country': np.tile(qc.country.to_numpy(), 80), 'year': np.repeat(YEARS, 203)})
    frame['ssp'] = ssp
    frame['model'] = model
    frame['member'] = member
    frame['P90_reference_period'] = reference
    for m, a in country_values.items():
        frame[m] = a.reshape(-1)
    return add_changes(frame)

def ensemble(frame):
    keys = ['fid', 'region_id', 'country', 'year', 'ssp']
    sizes = frame.groupby(keys).model.nunique()
    assert (sizes == 2).all()
    metrics = [*METRICS, 'dACH', 'dRCH', 'dMCH']
    wide = frame.set_index(keys + ['model'])[metrics].unstack('model').sort_index()
    values = wide.to_numpy().reshape(len(wide), len(metrics), 2)
    assert np.isfinite(values).all()
    result = wide.index.to_frame(index=False)
    result['n_models'] = 2
    assert frame.P90_reference_period.nunique() == 1
    result['P90_reference_period'] = frame.P90_reference_period.iloc[0]
    means = values.mean(2)
    medians = np.median(values, axis=2)
    q05 = np.quantile(values, 0.05, axis=2, method='linear')
    q95 = np.quantile(values, 0.95, axis=2, method='linear')
    for j, m in enumerate(metrics):
        result[m] = means[:, j]
        result[m + '_median'] = medians[:, j]
        result[m + '_p05'] = q05[:, j]
        result[m + '_p95'] = q95[:, j]
    assert len(result) == 64960 and (not result.duplicated(['fid', 'year', 'ssp']).any())
    return result

def main(project):
    qcout = project / 'outputs/qc'
    status = json.loads((qcout / 'native_events_completed.json').read_text())
    assert status['completed'] and len(status['results']) == 8
    out = project / 'outputs/annual_panel'
    modelout = out / 'model_level'
    sensout = out / 'sensitivity_P90_2021_2040'
    modelout.mkdir(parents=True, exist_ok=True)
    sensout.mkdir(parents=True, exist_ok=True)
    primary = []
    sensitivity = []
    boundary = []
    aggregation_checks = []
    for r in sorted(status['results'], key=lambda r: (r['model'], r['ssp'])):
        model, ssp = (r['model'], r['ssp'])
        path = Path(r['path'])
        assert hashlib.sha256(path.read_bytes()).hexdigest() == r['sha256']
        geo = project / 'data_processed/native_geometry'
        z = np.load(geo / f'{model}_country_samplers.npz')
        qc = pd.read_csv(geo / f'{model}_country_sampling_qc.csv')
        with Dataset(path) as ds:
            assert ds.model == model and ds.scenario == ssp and np.array_equal(ds.variables['year'][:], YEARS)
            indices = np.asarray(ds.variables['native_cell_index'][:], dtype=int)
            w = country_weights(z, indices)
            values = {m: np.asarray(ds.variables[m][:], np.float64) for m in [*METRICS, 'RCH_sensitivity', 'MCH_sensitivity']}
        aggregated = {m: w.dot(a.T).T for m, a in values.items()}
        for m in METRICS:
            lookup = {int(i): j for j, i in enumerate(indices)}
            for j in [0, 20, 100, 202]:
                sel = z['indices'][z['offsets'][j]:z['offsets'][j + 1]]
                weights = z['weights'][z['offsets'][j]:z['offsets'][j + 1]]
                cols = [lookup[int(i)] for i in sel]
                for yi in [0, 19, 79]:
                    direct = np.average(values[m][yi, cols], weights=weights)
                    diff = abs(direct - aggregated[m][yi, j])
                    assert diff < 1e-08
                    aggregation_checks.append(dict(model=model, ssp=ssp, fid=int(qc.fid.iloc[j]), year=int(YEARS[yi]), metric=m, max_abs_difference_Cdays=float(diff)))
        p = model_panel(qc, model, r['member'], ssp, {m: aggregated[m] for m in METRICS}, '2015-2034')
        s = model_panel(qc, model, r['member'], ssp, {'ACH': aggregated['ACH'], 'RCH': aggregated['RCH_sensitivity'], 'MCH': aggregated['MCH_sensitivity']}, '2021-2040')
        assert len(p) == 16240 and (not p.duplicated(['fid', 'year']).any())
        p.to_csv(modelout / f'{model}_{ssp}_country_year_2021_2100.csv', index=False, encoding='utf-8-sig')
        s.to_csv(sensout / f'{model}_{ssp}_country_year_2021_2100.csv', index=False, encoding='utf-8-sig')
        primary.append(p)
        sensitivity.append(s)
        end = pd.read_csv(qcout / 'events' / f'{model}_{ssp}_end_boundary.csv')
        assert np.array_equal(end.native_cell_index.to_numpy(), indices)
        for m in METRICS:
            potential = w.dot(end[m + '_potential_end_contribution'].to_numpy())
            for j, row in qc.iterrows():
                boundary.append(dict(model=model, ssp=ssp, fid=int(row.fid), region_id=row.region_id, country=row.country, year=2100, metric=m, lookahead_available=r['lookahead_2101_Jan01_available'], potential_additional_end_Cdays=float(potential[j])))
    model_frame = pd.concat(primary, ignore_index=True)
    sensitivity_frame = pd.concat(sensitivity, ignore_index=True)
    assert len(model_frame) == 129920 and (not model_frame.duplicated(['fid', 'year', 'ssp', 'model', 'member']).any())
    model_frame.to_csv(modelout / 'all_models_country_year_ssp_2021_2100.csv', index=False, encoding='utf-8-sig')
    sensitivity_frame.to_csv(sensout / 'all_models_country_year_ssp_2021_2100.csv', index=False, encoding='utf-8-sig')
    main = ensemble(model_frame)
    alternate = ensemble(sensitivity_frame)
    for label, frame, target in [('primary', main, out), ('sensitivity', alternate, sensout)]:
        for ssp in SSPS:
            panel = frame[frame.ssp == ssp].sort_values(['fid', 'year'])
            assert len(panel) == 16240 and panel.fid.nunique() == 203 and (panel.year.nunique() == 80) and (not panel.duplicated(['fid', 'year']).any())
            panel.to_csv(target / f'country_year_{ssp}_2021_2100.csv', index=False, encoding='utf-8-sig')
        frame.to_csv(target / 'country_year_ssp_2021_2100.csv', index=False, encoding='utf-8-sig')
    checks = []
    for name, frame in [('model_primary', model_frame), ('model_sensitivity', sensitivity_frame), ('ensemble_primary', main), ('ensemble_sensitivity', alternate)]:
        assert np.isfinite(frame[[*METRICS, 'dACH', 'dRCH', 'dMCH']]).all().all()
        assert (frame[METRICS] >= 0).all().all()
        assert (frame.MCH <= frame.ACH + 1e-08).all() and (frame.MCH <= frame.RCH + 1e-08).all()
        for m in METRICS:
            checks.append(dict(table=name, metric=m, rows=len(frame), missing=int(frame[m].isna().sum()), negative=int((frame[m] < 0).sum()), minimum=float(frame[m].min()), maximum=float(frame[m].max())))
    pd.DataFrame(checks).to_csv(qcout / 'qc_country_year_panel.csv', index=False)
    pd.DataFrame(aggregation_checks).to_csv(qcout / 'qc_country_aggregation_spot_checks.csv', index=False)
    pd.DataFrame(boundary).to_csv(qcout / 'qc_2100_end_boundary_country.csv', index=False, encoding='utf-8-sig')
    baseline = model_frame[model_frame.year.between(2021, 2040)].groupby(['fid', 'model', 'member', 'ssp'])[['dACH', 'dRCH', 'dMCH']].mean()
    assert np.max(abs(baseline.to_numpy())) < 1e-08
    fingerprints = []
    for path in out.rglob('*.csv'):
        fingerprints.append(dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    pd.DataFrame(fingerprints).to_csv(qcout / 'country_panel_output_sha256.csv', index=False)
    result = dict(completed=True, models=2, SSPs=4, countries=203, years=[2021, 2100], rows_per_SSP_country_year_panel=16240, pooled_country_year_SSP_rows=64960, model_level_rows=129920, primary_panel_unit='country x natural calendar year, stratified by SSP', primary_values='Equal-model means of area-weighted native-cell heat indicators', model_spread='median,p05,p95 across the two models; not confidence intervals', change_baseline='within each model and SSP: 2021-2040 mean', main_panel=str((out / 'country_year_ssp_2021_2100.csv').resolve()), missing_indicator_values=0, negative_indicator_values=0, MCH_subset_checks_passed=True, aggregation_max_spot_difference_Cdays=max((r['max_abs_difference_Cdays'] for r in aggregation_checks)), native_events_max_upstream_difference_Cdays=max((r['upstream_max_abs_difference_Cdays'] for r in status['results'])), threshold_sensitivity_panels_generated=True, annual_country_panel_generated=True, health_attribution=False)
    (qcout / 'country_year_panel_completed.json').write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False))
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--project', type=Path, default=PROJECT)
    main(ap.parse_args().project)
