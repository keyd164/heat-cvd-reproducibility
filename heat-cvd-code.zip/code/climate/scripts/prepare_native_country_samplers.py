"""Build center-in-polygon country samplers on each original CMIP6 grid.

Run with bundled Python 3.12 and the existing cp312 geometry dependencies.
Spherical weights use source latitude/longitude cell bounds, not ERA5 indices.
"""
import os
from pathlib import Path
import sys
sys.path.insert(0, os.environ.get('HEAT_CVD_CODEX_PYDEPS_GEO', 'external_inputs/.codex_pydeps_geo'))
import argparse, json, hashlib
import numpy as np
import pandas as pd
import geopandas as gpd
import shapely
SHAPEFILE = Path(os.environ.get('HEAT_CVD_NE_10M_ADMIN_0_COUNTRIES_SHP', 'external_inputs/ne_10m_admin_0_countries.shp'))
HIST_QC = Path(os.environ.get('HEAT_CVD_SAMPLING_QC_BY_REGION_CSV', 'external_inputs/sampling_qc_by_region.csv'))
GBD = Path(os.environ.get('HEAT_CVD_IHME_GBD_2021_DATA_403150E6_1_AGE_STANDARDIZED_PANEL_CSV', 'external_inputs/IHME-GBD_2021_DATA-403150e6-1_age_standardized_panel.csv'))

def cell_areas(latitude_bounds, longitude_bounds):
    lb = np.asarray(latitude_bounds, dtype=float)
    ob = np.asarray(longitude_bounds, dtype=float)
    row = np.abs(np.sin(np.deg2rad(np.clip(lb[:, 1], -90, 90))) - np.sin(np.deg2rad(np.clip(lb[:, 0], -90, 90))))
    width = (ob[:, 1] - ob[:, 0]) % 360
    if np.any(width <= 0) or np.any(width > 180):
        raise ValueError('Invalid longitude cell widths')
    area = row[:, None] * np.deg2rad(width)[None, :]
    assert np.all(area > 0) and abs(area.sum() - 4 * np.pi) < 1e-06
    return area

def main(project):
    out = project / 'data_processed/native_geometry'
    out.mkdir(parents=True, exist_ok=True)
    countries = gpd.read_file(SHAPEFILE).to_crs('EPSG:4326')
    invalid = ~countries.geometry.is_valid
    countries.loc[invalid, 'geometry'] = countries.loc[invalid, 'geometry'].map(lambda g: g.buffer(0))
    assert countries.geometry.is_valid.all() and (not countries.geometry.is_empty.any())
    fids = set(pd.read_csv(GBD, usecols=['fid']).fid.dropna().astype(int))
    countries = countries[countries.fid1.isin(fids)].sort_values('fid1')
    assert len(countries) == 203 and (not countries.fid1.duplicated().any())
    hist = pd.read_csv(HIST_QC).set_index('fid')
    shapefile_hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in SHAPEFILE.parent.glob(SHAPEFILE.stem + '.*') if p.is_file()}
    for path in sorted(out.glob('*_grid.json')):
        grid = json.loads(path.read_text(encoding='utf-8'))
        model = grid['model']
        lat = np.asarray(grid['latitude'])
        lon = np.asarray(grid['longitude'])
        wrapped = (lon + 180) % 360 - 180
        yy, xx = np.meshgrid(lat, wrapped, indexing='ij')
        x = xx.ravel()
        y = yy.ravel()
        areas = cell_areas(grid['latitude_bounds'], grid['longitude_bounds']).ravel()
        indices = []
        weights = []
        offsets = [0]
        rows = []
        for row in countries.itertuples(index=False):
            fid = int(row.fid1)
            region = row.ADM0_A3
            assert str(hist.loc[fid, 'region_id']) == str(region), 'Country encoding differs from historical scope'
            geom = row.geometry
            west, south, east, north = geom.bounds
            possible = np.flatnonzero((x >= west) & (x <= east) & (y >= south) & (y <= north))
            shapely.prepare(geom)
            selected = possible[shapely.intersects_xy(geom, x[possible], y[possible])]
            method = 'native_grid_center_spherical_area_weighted'
            fallback_distance = None
            if not len(selected):
                point = geom.representative_point()
                i = int(np.argmin(abs(lat - point.y)))
                j = int(np.argmin(abs((wrapped - point.x + 180) % 360 - 180)))
                selected = np.array([i * len(lon) + j])
                method = 'representative_point_nearest_native_center'
                rlon, rlat = np.deg2rad([x[selected[0]] - point.x, y[selected[0]] - point.y])
                a = np.sin(rlat / 2) ** 2 + np.cos(np.deg2rad(point.y)) * np.cos(np.deg2rad(y[selected[0]])) * np.sin(rlon / 2) ** 2
                fallback_distance = float(6371 * 2 * np.arcsin(np.sqrt(np.clip(a, 0, 1))))
            assert len(selected) > 0 and np.all(areas[selected] > 0)
            indices.append(selected)
            weights.append(areas[selected])
            offsets.append(offsets[-1] + len(selected))
            rows.append(dict(model=model, fid=fid, region_id=region, country=row.ADMIN, sampling_method=method, sample_grid_cell_count=len(selected), sampled_area_steradians=float(areas[selected].sum()), fallback_distance_km=fallback_distance, historical_grid_cell_count=int(hist.loc[fid, 'sample_grid_cell_count']), historical_sampling_method=str(hist.loc[fid, 'sampling_method'])))
        qc = pd.DataFrame(rows)
        allidx = np.concatenate(indices)
        allw = np.concatenate(weights)
        np.savez_compressed(out / f'{model}_country_samplers.npz', indices=allidx, weights=allw, offsets=np.array(offsets), fid=qc.fid.to_numpy(), region_id=qc.region_id.to_numpy(dtype=str), latitude=lat, longitude=lon, cell_area_steradians=areas.reshape(len(lat), len(lon)))
        qc.to_csv(out / f'{model}_country_sampling_qc.csv', index=False, encoding='utf-8-sig')
        meta = dict(model=model, countries=len(qc), unique_sample_cells=len(np.unique(allidx)), membership_records=len(allidx), fallback_countries=int((qc.sampling_method == 'representative_point_nearest_native_center').sum()), geometry_repair_count=int(invalid.sum()), global_area_steradians=float(areas.sum()), shapefile_sha256=shapefile_hashes, grid_json_sha256=hashlib.sha256(path.read_bytes()).hexdigest(), coordinate_sha256=grid['coordinate_sha256'], center_boundary_policy='Polygon covers cell center; exact boundary included; overlaps retained by country', weight_method='source-cell spherical area using latitude and longitude bounds; area normalization occurs within country', country_scope='Historical fid/ADM0_A3 matched to the existing 203-country GBD analysis scope')
        (out / f'{model}_geometry_metadata.json').write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding='utf-8')
        print(f"{model}: 203 countries; {len(np.unique(allidx))} unique cells; {meta['fallback_countries']} fallbacks", flush=True)
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--project', type=Path, default=Path(__file__).resolve().parents[1])
    main(ap.parse_args().project)
