"""Two-day native-cell events, streamed across chunks/files/year boundaries.

Events remain continuous across December/January, but each day's contribution
belongs to its actual calendar year. Date gaps, including a removed Feb29 in
the mapped Gregorian calendar, break continuity. Never average temperatures.
"""
import os
from pathlib import Path
import sys
PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / '.deps'))
if Path(os.environ.get('HEAT_CVD_NETCDF4', 'external_inputs/netCDF4')).exists():
    sys.path.insert(0, os.environ.get('HEAT_CVD_SITE_PACKAGES', 'external_inputs/site-packages'))
import argparse, json, hashlib, time, importlib.util
from datetime import date
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np
import pandas as pd
from netCDF4 import Dataset, num2date
FIELDS = ['ACH', 'RCH', 'MCH', 'RCH_sensitivity', 'MCH_sensitivity']
YEARS = list(range(2021, 2101))
CLIMATE_RULES = Path(__file__).resolve().parents[1] / 'calculate_heat_indicators.py'

class TwoDayEvents:

    def __init__(self, years, cells, metrics=5):
        self.years = list(years)
        self.year_slot = {y: i for i, y in enumerate(years)}
        self.totals = np.zeros((metrics, len(years), cells), np.float64)
        self.pending = None
        self.end_uncertain = np.zeros((metrics, cells), np.float64)

    def deposit(self, day, intensity, eligible):
        if day.year in self.year_slot:
            self.totals[:, self.year_slot[day.year]] += np.where(eligible, intensity, 0.0)

    def push(self, day, temperature, thresholds):
        condition = np.isfinite(temperature)[None, :] & (temperature[None, :] > thresholds)
        intensity = np.maximum(temperature[None, :] - thresholds, 0.0)
        left = np.zeros_like(condition)
        if self.pending is not None:
            previous, pi, pc, pl = self.pending
            consecutive = (day - previous).days == 1
            right = condition if consecutive else np.zeros_like(condition)
            self.deposit(previous, pi, pc & (pl | right))
            if consecutive:
                left = pc
        self.pending = (day, intensity, condition, left)

    def finish(self):
        if self.pending is not None:
            day, intensity, condition, left = self.pending
            self.deposit(day, intensity, condition & left)
            if day.year in self.year_slot:
                self.end_uncertain = np.where(condition & ~left, intensity, 0.0)
            self.pending = None
        return self.totals

def upstream_module():
    spec = importlib.util.spec_from_file_location('native_event_upstream', CLIMATE_RULES)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def signature(p):
    p = Path(p)
    s = p.stat()
    return dict(path=str(p.resolve()), bytes=s.st_size, mtime_ns=s.st_mtime_ns)

def write_native(path, totals, indices, grid, metadata):
    temp = path.with_suffix('.partial.nc')
    with Dataset(temp, 'w') as ds:
        ds.createDimension('year', 80)
        ds.createDimension('cell', len(indices))
        ds.createVariable('year', 'i4', ('year',))[:] = YEARS
        ds.createVariable('native_cell_index', 'i4', ('cell',))[:] = indices
        ds.createVariable('latitude', 'f8', ('cell',))[:] = np.asarray(grid['latitude'])[indices // len(grid['longitude'])]
        ds.createVariable('longitude', 'f8', ('cell',))[:] = np.asarray(grid['longitude'])[indices % len(grid['longitude'])]
        for i, name in enumerate(FIELDS):
            v = ds.createVariable(name, 'f8', ('year', 'cell'), zlib=True, complevel=2, chunksizes=(1, min(2048, len(indices))))
            v[:] = totals[i]
            v.units = 'degree_Celsius days'
            v.minimum_event_duration_days = 2
        for k, v in metadata.items():
            ds.setncattr(k, v)
        ds.spatial_scope = 'Unique native cells sampled by the 203-country samplers, not unused ocean/global cells'
        ds.annual_allocation = 'Daily contributions assigned to their actual calendar years; events continuous across years'
        ds.leap_policy = 'Mapped Gregorian Feb29 omitted and date gap breaks continuity, including noleap sources in Gregorian leap years'
        ds.reference_primary = '2015-2034'
        ds.reference_sensitivity = '2021-2040'
        ds.threshold_group = 'model x member x SSP'
    temp.replace(path)

def compute_one(project, model, member, ssp):
    project = Path(project)
    started = time.time()
    inventory = pd.read_csv(project / 'outputs/qc/file_inventory.csv')
    inputs = inventory[(inventory.source_id == model) & (inventory.variant_label == member) & (inventory.experiment_id == ssp)].sort_values('first')
    geo = project / 'data_processed/native_geometry'
    z = np.load(geo / f'{model}_country_samplers.npz')
    indices = np.unique(z['indices'])
    grid = json.loads((geo / f'{model}_grid.json').read_text())
    root = project / 'data_processed/thresholds' / model / ssp
    paths = [root / 'tasmax_p90_2015_2034.nc', root / 'tasmax_p90_2021_2040.nc']
    stage1 = json.loads((root / 'completed.json').read_text())
    assert stage1['completed'] and stage1['country_missing_values'] == 0
    for t in stage1['thresholds']:
        assert hashlib.sha256(Path(t['path']).read_bytes()).hexdigest() == t['sha256']
    p90 = []
    for p in paths:
        with Dataset(p) as ds:
            assert ds.model == model and ds.member == member and (ds.scenario == ssp)
            p90.append(np.asarray(ds.variables['tasmax_p90'][:], np.float32).reshape(365, -1)[:, indices])
    assert all((np.isfinite(a).all() for a in p90))
    out = project / 'data_processed/annual_native_cells' / model / ssp
    out.mkdir(parents=True, exist_ok=True)
    qcdir = project / 'outputs/qc/events'
    qcdir.mkdir(parents=True, exist_ok=True)
    done = out / 'completed.json'
    fingerprint = dict(script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), config_sha256=hashlib.sha256((project / 'config.json').read_bytes()).hexdigest(), sources=[signature(p) for p in inputs.path], threshold_sha256=[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths], sampler_sha256=hashlib.sha256((geo / f'{model}_country_samplers.npz').read_bytes()).hexdigest())
    if done.exists():
        prior = json.loads(done.read_text())
        if prior['signature'] == fingerprint and (out / 'annual_target_cells_2021_2100.nc').exists():
            return prior
        raise ValueError('Existing native events have different inputs; use a fresh output directory')
    engine = TwoDayEvents(YEARS, len(indices))
    codes = []
    spot_temperatures = []
    picked = np.linspace(0, len(indices) - 1, 8, dtype=int)
    seen = set()
    formal_counts = {y: 0 for y in YEARS}
    lookahead = False
    last = None
    for row in inputs.itertuples():
        if row.first_year > 2101 or row.last_year < 2015:
            continue
        with Dataset(row.path) as ds:
            assert ds.source_id == model and ds.variant_label == member and (ds.experiment_id == ssp)
            assert np.array_equal(ds.variables['lat'][:], grid['latitude']) and np.array_equal(ds.variables['lon'][:], grid['longitude'])
            t = ds.variables['time']
            assert t.calendar in ('365_day', 'noleap')
            dates = num2date(t[:], t.units, calendar=t.calendar)
            positions = [i for i, d in enumerate(dates) if (2015, 1, 1) <= (d.year, d.month, d.day) <= (2101, 1, 1)]
            if not positions:
                continue
            assert positions == list(range(positions[0], positions[-1] + 1))
            v = ds.variables['tasmax']
            assert v.units == 'K'
            for start in range(positions[0], positions[-1] + 1, 60):
                stop = min(start + 60, positions[-1] + 1)
                data = np.asarray(np.ma.filled(v[start:stop], np.nan), np.float32).reshape(stop - start, -1)[:, indices] - np.float32(273.15)
                assert np.isfinite(data).all(), 'Unexpected missing country sample cells'
                for j, d in enumerate(dates[start:stop]):
                    day = date(d.year, d.month, d.day)
                    assert day not in seen and (last is None or day > last)
                    seen.add(day)
                    last = day
                    doy = int(d.dayofyr) - 1
                    thresholds = np.stack([np.full(len(indices), 30.0, np.float32), p90[0][doy], np.maximum(30.0, p90[0][doy]), p90[1][doy], np.maximum(30.0, p90[1][doy])])
                    engine.push(day, data[j], thresholds)
                    codes.append(day.year * 10000 + day.month * 100 + day.day)
                    spot_temperatures.append(data[j, picked])
                    if day.year in formal_counts:
                        formal_counts[day.year] += 1
                    if day == date(2101, 1, 1):
                        lookahead = True
            print(f'{model}/{ssp}: events streamed through {min(row.last_year, 2101)}', flush=True)
    totals = engine.finish()
    assert all((n == 365 for n in formal_counts.values()))
    assert np.isfinite(totals).all() and np.min(totals) >= 0
    assert np.all(totals[2] <= totals[0] + 1e-08) and np.all(totals[2] <= totals[1] + 1e-08)
    assert np.all(totals[4] <= totals[0] + 1e-08) and np.all(totals[4] <= totals[3] + 1e-08)
    native = out / 'annual_target_cells_2021_2100.nc'
    write_native(native, totals, indices, grid, dict(model=model, member=member, scenario=ssp, grid=grid['grid'], lookahead_2101_Jan01_available=str(lookahead)))
    sample = np.stack(spot_temperatures)
    sample_dates = [date(c // 10000, c // 100 % 100, c % 100) for c in codes]
    upstream = upstream_module()
    checks = []
    for y in (2021, 2040, 2100):
        use = [i for i, d in enumerate(sample_dates) if date(y - 1, 12, 31) <= d <= date(y + 1, 1, 1)]
        sd = [sample_dates[i] for i in use]
        temp = sample[use]
        doy = np.array([(date(2001, d.month, d.day) - date(2001, 1, 1)).days for d in sd])
        bs = [30.0, p90[0][doy][:, picked], np.maximum(30.0, p90[0][doy][:, picked]), p90[1][doy][:, picked], np.maximum(30.0, p90[1][doy][:, picked])]
        for k, b in enumerate(bs):
            expected = upstream.yearly_totals(np.maximum(temp - b, 0)[:, :, None], (temp > b)[:, :, None], sd, [y], 2)[0, :, 0]
            actual = totals[k, YEARS.index(y), picked]
            diff = np.max(abs(actual - expected))
            np.testing.assert_allclose(actual, expected, rtol=2e-06, atol=0.0001)
            checks.append(dict(model=model, ssp=ssp, year=y, metric=FIELDS[k], cells=len(picked), max_abs_difference_Cdays=float(diff), comparison='upstream float32 vs streaming float64'))
    pd.DataFrame(checks).to_csv(qcdir / f'{model}_{ssp}_upstream_check.csv', index=False)
    uncertainty = pd.DataFrame({'native_cell_index': indices, **{FIELDS[k] + '_potential_end_contribution': engine.end_uncertain[k] for k in range(5)}})
    uncertainty.to_csv(qcdir / f'{model}_{ssp}_end_boundary.csv', index=False)
    result = dict(model=model, member=member, ssp=ssp, completed=True, signature=fingerprint, path=str(native), sha256=hashlib.sha256(native.read_bytes()).hexdigest(), country_native_cells=len(indices), formal_days=sum(formal_counts.values()), year_count=80, lookahead_2101_Jan01_available=lookahead, potential_end_ambiguous_cells={FIELDS[k]: int((engine.end_uncertain[k] > 0).sum()) for k in range(5)}, upstream_max_abs_difference_Cdays=max((r['max_abs_difference_Cdays'] for r in checks)), elapsed_seconds=round(time.time() - started, 1))
    done.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(f'{model}/{ssp}: annual native-cell events complete', flush=True)
    return result

def main(project, workers):
    assert json.loads((project / 'outputs/qc/stage1_acceptance.json').read_text())['completed']
    c = pd.read_csv(project / 'outputs/qc/models_common.csv')
    c = c[c.eligible_for_next_stage == True]
    results = []
    with ProcessPoolExecutor(max_workers=workers) as pool:
        jobs = [pool.submit(compute_one, str(project), r.model, r.member, s) for r in c.itertuples() for s in ['ssp126', 'ssp245', 'ssp370', 'ssp585']]
        for f in as_completed(jobs):
            results.append(f.result())
    (project / 'outputs/qc/native_events_completed.json').write_text(json.dumps({'completed': True, 'results': results, 'annual_country_panel_generated': False}, indent=2), encoding='utf-8')
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--project', type=Path, default=PROJECT)
    ap.add_argument('--workers', type=int, default=2)
    args = ap.parse_args()
    main(args.project, args.workers)
