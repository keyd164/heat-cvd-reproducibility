"""KACE ACH on an explicit fractional-year 365-day temperature calendar.

No P90 required: ACH only. Native 360-day ACH and 365/360 annual scaling
are sensitivity diagnostics, never substituted for daily event recalculation.
"""
import os
from pathlib import Path
import argparse
import importlib.util
import json
import hashlib
import sys
from datetime import date, timedelta
if Path(os.environ.get('HEAT_CVD_NETCDF4', 'external_inputs/netCDF4')).exists():
    sys.path.insert(0, os.environ.get('HEAT_CVD_SITE_PACKAGES', 'external_inputs/site-packages'))
import numpy as np
import pandas as pd
from netCDF4 import Dataset, num2date
PROJECT = Path(__file__).resolve().parents[1]
MODEL = 'KACE-1-0-G'
SSPS = ['ssp126', 'ssp245', 'ssp370', 'ssp585']
POLICY = dict(source_calendar='360_day', target_calendar='365_day then Gregorian date labels with Feb29 gaps', method='linear interpolation on fractional-year daily centers, before threshold/event detection', source_coordinate='year + (native_day_index + 0.5)/360', target_coordinate='year + (target_day_index + 0.5)/365', internal_year_edges='use real previous Dec30 and next Jan01 values', dataset_edges='nearest endpoint hold only outside 2015-2100 source centers; no 2101 fabricated', event_rule='Tmax>30C, consecutive>=2 mapped Gregorian days; cross-year daily allocation; Feb29 absent and breaks events', sensitivity='native 360-day event calculation, plus annual total times 365/360; not a validated alternative', source='https://docs.xarray.dev/en/v2023.10.1/generated/xarray.DataArray.interp_calendar.html', limitation='daily interpolation may smooth hot tails and alter event duration; no calendar method is assumed impact-neutral')

def module(filename, name):
    spec = importlib.util.spec_from_file_location(name, PROJECT / 'scripts' / filename)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def export_grid(out):
    inv = pd.read_csv(PROJECT / 'outputs/qc/file_inventory.csv')
    selected = inv[inv.source_id.eq(MODEL)]
    assert len(selected) == 4 and selected.coordinate_sha256.nunique() == 1
    geo = out / 'data_processed/native_geometry'
    geo.mkdir(parents=True, exist_ok=True)
    with Dataset(selected.iloc[0].path) as ds:
        info = dict(model=MODEL, member='r1i1p1f1', grid='gr', calendar='360_day', latitude=np.asarray(ds['lat'][:], float).tolist(), longitude=np.asarray(ds['lon'][:], float).tolist(), latitude_bounds=np.asarray(ds[ds['lat'].bounds][:], float).tolist(), longitude_bounds=np.asarray(ds[ds['lon'].bounds][:], float).tolist(), coordinate_sha256=selected.iloc[0].coordinate_sha256)
    (geo / f'{MODEL}_grid.json').write_text(json.dumps(info, indent=2), encoding='utf-8')
    print(f"KACE grid: {len(info['latitude'])} x {len(info['longitude'])}", flush=True)

def interpolate_year(y, values, prev, following):
    """Daily centers; clamp only the unobserved outside dataset endpoints."""
    xp = (np.arange(360) + 0.5) / 360
    data = values
    if prev is not None:
        xp = np.r_[-0.5 / 360, xp]
        data = np.concatenate([prev[None, :], data])
    if following is not None:
        xp = np.r_[xp, 1 + 0.5 / 360]
        data = np.concatenate([data, following[None, :]])
    x = (np.arange(365) + 0.5) / 365
    hi = np.clip(np.searchsorted(xp, x, side='right'), 1, len(xp) - 1)
    lo = hi - 1
    weight = np.clip((x - xp[lo]) / (xp[hi] - xp[lo]), 0, 1)
    return (data[lo] * (1 - weight[:, None]) + data[hi] * weight[:, None]).astype(np.float32)

def direct_totals(temp, days, years):
    """Independent adjacent-pair criterion, no streaming state."""
    hot = temp > 30.0
    eligible = np.zeros_like(hot)
    pair = hot[:-1] & hot[1:] & (np.diff(days)[:, None] == 1)
    eligible[:-1] |= pair
    eligible[1:] |= pair
    daily = np.where(eligible, np.maximum(temp - 30.0, 0), 0)
    return np.stack([daily[years == y].sum(axis=0, dtype=np.float64) for y in range(2015, 2101)])

def compute(out):
    out.mkdir(parents=True, exist_ok=True)
    (out / 'calendar_policy.json').write_text(json.dumps(POLICY, indent=2), encoding='utf-8')
    events = module('03_heat_event_detection.py', 'events')
    aggregation = module('04_country_aggregation.py', 'aggregation')
    geo = out / 'data_processed/native_geometry'
    grid = json.loads((geo / f'{MODEL}_grid.json').read_text())
    sampler = np.load(geo / f'{MODEL}_country_samplers.npz')
    qc = pd.read_csv(geo / f'{MODEL}_country_sampling_qc.csv')
    idx = np.unique(sampler['indices'])
    weights = aggregation.country_weights(sampler, idx)
    picked = np.linspace(0, len(idx) - 1, 8, dtype=int)
    inv = pd.read_csv(PROJECT / 'outputs/qc/file_inventory.csv')
    raw = out / 'raw_model_panels'
    raw.mkdir(exist_ok=True)
    checks = []
    for ssp in SSPS:
        selected = inv[inv.source_id.eq(MODEL) & inv.experiment_id.eq(ssp)]
        assert len(selected) == 1
        source = Path(selected.iloc[0].path)
        engine = events.TwoDayEvents(range(2015, 2101), len(idx), metrics=1)
        native_samples, mapped_samples, mapped_dates = ([], [], [])
        native_totals = np.zeros((86, len(idx)), float)
        native_pending = None

        def native_push(slot, v):
            nonlocal native_pending
            cond = v > 30.0
            excess = np.maximum(v - 30.0, 0)
            left = np.zeros_like(cond)
            if native_pending is not None:
                ps, pi, pc, pl = native_pending
                native_totals[ps // 360] += np.where(pc & (pl | cond), pi, 0)
                left = pc
            native_pending = (slot, excess, cond, left)
        with Dataset(source) as ds:
            assert ds.source_id == MODEL and ds.experiment_id == ssp and (ds.variant_label == 'r1i1p1f1')
            assert ds['time'].calendar == '360_day' and ds['tasmax'].units == 'K'
            assert np.array_equal(ds['lat'][:], grid['latitude']) and np.array_equal(ds['lon'][:], grid['longitude'])
            t = ds['time']
            decoded = num2date(t[:], t.units, calendar=t.calendar)
            keys = [(d.year, d.month, d.day) for d in decoded]
            expected = [(y, m, d) for y in range(2015, 2101) for m in range(1, 13) for d in range(1, 31)]
            assert keys == expected
            v = ds['tasmax']

            def read_year(y):
                a = np.asarray(np.ma.filled(v[(y - 2015) * 360:(y - 2014) * 360], np.nan), np.float32).reshape(360, -1)[:, idx] - np.float32(273.15)
                assert np.isfinite(a).all() and (abs(a) < 10000000000.0).all()
                return a
            previous_last = None
            current = read_year(2015)
            endpoint_clamps = []
            for y in range(2015, 2101):
                following = read_year(y + 1) if y < 2100 else None
                converted = interpolate_year(y, current, previous_last, following[0] if following is not None else None)
                if previous_last is None:
                    endpoint_clamps.append(f'{y}-01-01')
                if following is None:
                    endpoint_clamps.append(f'{y}-12-31')
                for k in range(360):
                    native_push((y - 2015) * 360 + k, current[k])
                native_samples.append(current[:, picked])
                dates = [date(y, 1, 1) + timedelta(days=k) for k in range(366 if __import__('calendar').isleap(y) else 365)]
                dates = [d for d in dates if (d.month, d.day) != (2, 29)]
                assert len(dates) == 365
                for d, temperature in zip(dates, converted):
                    engine.push(d, temperature, np.full((1, len(idx)), 30.0, np.float32))
                mapped_samples.append(converted[:, picked])
                mapped_dates.extend(dates)
                previous_last = current[-1].copy()
                current = following
                if y in (2020, 2040, 2060, 2080, 2100):
                    print(f'KACE/{ssp}: all native country cells checked and daily ACH through {y}', flush=True)
        if native_pending is not None:
            ps, pi, pc, pl = native_pending
            native_totals[ps // 360] += np.where(pc & pl, pi, 0)
        totals = engine.finish()[0]
        mapped = np.concatenate(mapped_samples)
        native = np.concatenate(native_samples)
        years = np.repeat(np.arange(2015, 2101), 365)
        independent = direct_totals(mapped, np.array([d.toordinal() for d in mapped_dates]), years)
        np.testing.assert_allclose(totals[:, picked], independent, atol=1e-08)
        native_ind = direct_totals(native, np.arange(86 * 360), np.repeat(np.arange(2015, 2101), 360))
        np.testing.assert_allclose(native_totals[:, picked], native_ind, atol=1e-08)
        aggregated = weights.dot(totals.T).T
        native_aggregated = weights.dot(native_totals.T).T
        panel = pd.DataFrame(dict(fid=np.tile(qc.fid.to_numpy(), 86), region_id=np.tile(qc.region_id.to_numpy(), 86), country=np.tile(qc.country.to_numpy(), 86), year=np.repeat(range(2015, 2101), 203), model=MODEL, member='r1i1p1f1', ssp=ssp, ACH=aggregated.reshape(-1), ACH_native_360=native_aggregated.reshape(-1), ACH_native_annual_scaled_365=(native_aggregated * 365 / 360).reshape(-1)))
        panel['calendar_conversion_difference'] = panel.ACH - panel.ACH_native_annual_scaled_365
        assert np.isfinite(panel[['ACH', 'ACH_native_360', 'ACH_native_annual_scaled_365']]).all().all() and (panel.ACH >= 0).all()
        panel.to_csv(raw / f'{MODEL}_{ssp}_country_year_2015_2100.csv', index=False)
        potential = weights.dot(engine.end_uncertain[0])
        pd.DataFrame(dict(fid=qc.fid, ssp=ssp, year=2100, potential_additional_last_day_ACH=potential)).to_csv(out / f'{ssp}_2100_end_boundary.csv', index=False)
        checks.append(dict(ssp=ssp, source=dict(path=str(source), bytes=source.stat().st_size, mtime_ns=source.stat().st_mtime_ns), native_dates_verified=86 * 360, mapped_dates=86 * 365, finite_country_native_values=86 * 360 * len(idx), independent_event_max_error=float(abs(totals[:, picked] - independent).max()), native_independent_event_max_error=float(abs(native_totals[:, picked] - native_ind).max()), edge_held_dates=endpoint_clamps, lookahead_2101=False, max_potential_additional_last_day_ACH=float(potential.max()), mean_calendar_conversion_difference=float(panel.calendar_conversion_difference.mean()), max_abs_calendar_conversion_difference=float(abs(panel.calendar_conversion_difference).max())))
    summary = pd.DataFrame([{k: v for k, v in r.items() if not isinstance(v, (dict, list))} for r in checks])
    summary.to_csv(out / 'calendar_conversion_QC.csv', index=False)
    result = dict(completed=True, model=MODEL, countries=203, scenarios=SSPS, years=[2015, 2100], native_country_cells=len(idx), policy=POLICY, checks=checks, script_sha256=sha(__file__), sampler_sha256=sha(geo / f'{MODEL}_country_samplers.npz'), outputs_sha256={p.name: sha(p) for p in raw.glob('*.csv')})
    (out / 'kace_acceptance.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(f'KACE four SSP daily-event and calendar checks complete: {len(idx)} native cells', flush=True)
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--stage', choices=['export-grid', 'compute'], required=True)
    args = parser.parse_args()
    export_grid(args.output) if args.stage == 'export-grid' else compute(args.output)
