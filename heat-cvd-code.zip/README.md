# Heat CVD reproducibility

代码和数据分别位于 `code/` 与 `data/`，另提供独立代码包和数据包。对应2026年10月23日作者修订版本。范围是已采用的历史关联、零ACH条件率差、构造自然强迫对比、三模型SSP情景及探索性SDI分布比较。

## 快速复现

在仓库根目录运行，Python 3.10+、R 4.5+：

```sh
python -m pip install -r requirements.txt
Rscript -e 'install.packages("fixest", repos="https://cloud.r-project.org")'
python code/verify_package.py
Rscript code/fit_models.R
python code/derive_results.py
python code/render_statistical_figures.py
python code/render_descriptive_figures.py
python code/render_figure5.py
```

所有新输出写入 `results/`，该目录不会被Git跟踪。脚本使用相对路径，不依赖原作者电脑的项目目录。运行R时若未配置UTF-8 locale，可按本机可用locale设置；不要修改数值输入。

## 内容

| 位置 | 内容 |
|---|---|
| `code/fit_models.R` | 四模型比较、三个结局主模型、RCH/MCH补充系数及已发表范围内的lead-lag诊断；国家聚类t推断 |
| `code/derive_results.py` | 历史零ACH、自然强迫、SSP汇总及统一窗口的低减高组差变化；Kruskal–Wallis和Mann–Whitney/Holm比较 |
| `code/render_*.py` | 关联/率差图、SDI分布图和当前Figure5；图1示意图及图4地图底图的完整排版不由这些脚本重建 |
| `code/climate/` | 上游热事件、国家聚合、自然强迫构造、SSP变化参照和KACE日历处理的关键实现；外部输入配置单列 |
| `data/input/` | 历史分析面板、观测/自然强迫年度ACH、三模型和等权集合的年度SSP输入（gzip CSV） |
| `data/figure_source/` | 当前图表使用的数据；旧F1/SF1文件名属于来源标识，见数据字典 |
| `data/reference/` | 已报告数值的比较基准，包括保存的bootstrap区间；不是新的拟合输出 |
| `analysis_contract.json` | 分组、参照、窗口、加权和解释口径 |
| `FILE_MANIFEST.json` | 每个发布文件的SHA-256与字节数 |
| `archives/` | `heat-cvd-code.zip` 与 `heat-cvd-data.zip`，便于分别下载 |

## 本地验证范围

已从打包后的输入重跑四模型、三个结局主模型、补充暴露模型及既有lead诊断；检查系数/区间与保存基准一致。已重算条件转换、SSP窗口和12项两两比较的Holm校正，并运行绘图入口。没有在此次打包中重新执行2000次国家bootstrap或从全球每日气候网格端到端重算；保存的bootstrap区间作为明确标记的参考数据提供。B1提出的新增趋势/差分诊断不属于当前包。

## 数据来源与解释

GBD原始导出标签为GBD2021；当前稿件使用GBD2023引用依赖作者报告的数值核对，不能将本包当作新下载的GBD2023导出。ERA5/CMIP6的产品、模式、成员及参照见 `data/DATA_SOURCES.md`。日尺度NetCDF、全球栅格及完整底图未收入Git，需从各数据提供方获取后，按 `code/climate/README.md` 配置。

ACH=0表示无合格超阈值累积事件；自然强迫和SSP使用各自的参照。Figure5所有时期比较统一为2041–2060与2081–2100。条件率差使用主TWFE系数，不代表个体因果风险、归因死亡数或完整未来疾病率。

不包含写作技能、聊天记录、审稿快照、旧稿、临时脚本、运行日志、缓存、拟合对象、渲染预览及未采用的分析结果。上游代码会产生其运行所需的中间文件，这些文件由Git忽略。

第三方数据遵循原提供方条款；本仓库未代替原始数据提供方授予额外权利。
