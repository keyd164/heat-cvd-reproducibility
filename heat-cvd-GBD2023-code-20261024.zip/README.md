# Heat–CVD: GBD2023 rerun
Version: GBD2023 CVD outcomes, downloaded 2026-10-24. Retained SDI 2021 and archived SEV covariates are separately identified in data/DATA_SOURCES.md. This package supersedes the GBD2021 outcome analysis, not its archived provenance.

## Reproduce from packaged annual data
Extract the code and data ZIPs into the same new directory. From that directory:
```sh
python -m pip install -r requirements.txt
python code/verify_package.py
Rscript -e 'install.packages(c("fixest","jsonlite"), repos="https://cloud.r-project.org")'
Rscript code/fit_models.R results/models GBD2023
python code/derive_results.py
Rscript code/run_SDI_historical_ACH_20261015.R results/historical_bootstrap 2000
python code/build_SDI_historical_ACH_20261015.py results/historical_bootstrap
Rscript code/run_natural_ach_health_20261015.R results/natural_bootstrap 2000
python code/build_natural_ach_delivery_20261015.py results/natural_bootstrap
```
Use a fresh output directory for each bootstrap invocation. On Windows use a UTF-8 locale, eg LC_ALL=English_United States.utf8. R 4.5.2 and fixest were used. Python dependencies are listed in requirements.txt.

Existing fit, bootstrap and summary routines were reused with input-path and edition-check adaptations. Four models remain the robustness comparison; only primary country/year TWFE supplies health translations. Fixed SDI groups, six controls, country-clustered t inference, country bootstrap seed 20261015 and 2000 draws are retained. The proposed B1 trend/difference diagnostics were not added. No daily climate reconstruction was repeated.

## Data and results
- data/input/GBD2023_CVD_export_20261024.csv.gz: re-exported CVD outcomes, 204 locations, 1990–2020, rates, age-standardised, both sexes, DALYs/deaths/incidence.
- data/input/historical_panel.csv.gz: processed annual analysis input; original outcome export fields are separately archived above; 203 countries retained for fitting after excluding unmatched Tokelau.
- data/input/natural_forcing_panel.csv.gz and ssp_*_annual.csv.gz: unchanged climate inputs.
- data/GBD2023_results/: key completed numerical results, including new bootstrap intervals and verification tables. These are final analytical summaries, not bootstrap indices, fit objects or process logs.
- GBD2023_RERUN_REPORT.md: edition comparison, main results and affected manuscript elements.
- FILE_MANIFEST.json: per-file SHA-256.

The 18,972 exported outcome values differ from the old GBD2021 export. No equivalence claim is made. Old manuscript Word documents and graphics have not been relabelled as new results; text/figure replacement remains a subsequent scientific revision. This package contains numerical rerun outputs, not revised manuscript figures.

Raw daily climate files, external covariate acquisition files, full spatial data and upstream preprocessing dependencies are not bundled. The existing original panel builder was run locally; relocation and country-name aliases are recorded in the local audit. The packaged workflow starts from the processed annual inputs and does not claim raw-grid end-to-end reproduction. GBD draws and climate structural uncertainty are not propagated by the country bootstrap.
Third-party data remain subject to provider terms. No chat logs, writing skills, temporary files, fit objects, caches or old draft files are included.
