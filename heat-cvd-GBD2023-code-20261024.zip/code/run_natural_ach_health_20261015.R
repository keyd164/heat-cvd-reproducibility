# Natural-counterfactual ACH / DALYs only; no other analysis route is changed.
# Usage: Rscript run_natural_ach_health_20261015.R EXTERNAL_OUTPUT [DRAWS=2000]
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args)>=1)
out <- normalizePath(args[1], winslash='/', mustWork=FALSE)
B <- if(length(args)>1) as.integer(args[2]) else 2000L
stopifnot(B>=2000)
dir.create(out, recursive=TRUE, showWarnings=FALSE)
if(file.exists(file.path(out,'refit_completed.json'))) stop('Use a new output directory')
paper1_new_panel_path <- function() 'data/input/historical_panel.csv.gz'
sources <- c('00_registry.R','02_data_contracts.R','02_data_adapter.R',
 '03_model_helpers.R','fixed_effect_covariate_adjustment.R',
 'fixed_effect_identification.R','fixed_effect_panel_sensitivity.R')
for(n in sources) source(file.path('code/R',n),encoding='UTF-8')
fixest::setFixest_nthreads(1)
raw <- read.csv(gzfile(paper1_new_panel_path()),check.names=FALSE)
controls <- paper1_sensitivity_controls()
d <- prepare_paper1_panel(raw,'DALYs')
d <- paper1_sensitivity_complete(d,c('val','ehi1',controls,'fid','year_id'))
stopifnot(nrow(d)==6293,length(unique(d$fid))==203,
 !anyDuplicated(d[c('fid','year_id')]),identical(sort(unique(d$year_id)),1990:2020))
nat_path <- 'data/input/natural_forcing_panel.csv.gz'
group_path <- 'data/input/country_SDI_groups.csv'
nat <- read.csv(gzfile(nat_path)); nat$ACH <- nat$ACH_natural_calibrated; groups <- read.csv(group_path)
idx <- match(paste(d$fid,d$year_id),paste(nat$fid,nat$year))
stopifnot(!anyNA(idx),!anyDuplicated(nat[c('fid','year')]),
 max(abs(d$ehi1-nat$ACH_observed[idx]))<1e-5)
d$ACH_natural <- nat$ACH[idx]
d$delta_ACH <- d$ehi1-d$ACH_natural
d$group <- groups$group[match(d$fid,groups$fid)]
stopifnot(!anyNA(d$group))
# Independently reconstruct fixed baseline tertiles; never select new cutpoints.
base <- aggregate(mean_value~fid,d[d$year_id %in% 1990:1994,],mean)
cuts <- quantile(base$mean_value,c(0,1/3,2/3,1),type=7)
base$group <- as.character(cut(base$mean_value,cuts,c('Low','Middle','High'),include.lowest=TRUE))
stopifnot(all(base$group==groups$group[match(base$fid,groups$fid)]))
write.csv(groups,file.path(out,'country_SDI_groups.csv'),row.names=FALSE)
write.csv(d[c('fid','year_id','location_name','val','ehi1',controls,'group','ACH_natural','delta_ACH')],
 file.path(out,'DALYs_ACH_estimation_panel.csv'),row.names=FALSE)
specs <- c('primary_TWFE')
fit <- function(z,s,cluster=TRUE) {
 fe <- if(s=='primary_TWFE') 'fid + year_id' else 'fid[year_id] + year_id'
 if(cluster) return(paper1_sensitivity_fit(z,c('ehi1',controls),fe))
 fixest::feols(as.formula(paste('val ~',paste(c('ehi1',controls),collapse='+'),'|',fe)),z,notes=FALSE)
}
coefs <- do.call(rbind,lapply(specs,function(s) {
 m <- fit(d,s); cbind(specification=s,paper1_sensitivity_contrast(m,d,'ehi1'))
}))
write.csv(coefs,file.path(out,'DALYs_ACH_coefficients.csv'),row.names=FALSE)
# Whole-country resampling jointly propagates coefficient and sampled exposure
# variation. It does not propagate climate-model or GBD estimation uncertainty.
ids <- sort(unique(d$fid)); N <- length(ids); blocks <- lapply(ids,function(i) d[d$fid==i,])
set.seed(20261015)
draws <- matrix(sample(seq_len(N),B*N,replace=TRUE),nrow=B)
write.csv(draws,file.path(out,'bootstrap_country_indices.csv'),row.names=FALSE)
summarize_delta <- function(z) {
 values <- c(overall=mean(z$delta_ACH),
  year_1990=mean(z$delta_ACH[z$year_id==1990]),year_2020=mean(z$delta_ACH[z$year_id==2020]),
  period_1990_1999=mean(z$delta_ACH[z$year_id<=1999]),
  period_2011_2020=mean(z$delta_ACH[z$year_id>=2011]))
 gm <- sapply(c('Low','Middle','High'),function(g) mean(z$delta_ACH[z$group==g]))
 c(values,stats::setNames(gm,paste0('SDI_',names(gm))),
  High_minus_Low=unname(gm['High']-gm['Low']),
  Middle_minus_Low=unname(gm['Middle']-gm['Low']),
  High_minus_Middle=unname(gm['High']-gm['Middle']))
}
results <- vector('list',B); beta_draws <- matrix(NA_real_,B,length(specs),dimnames=list(NULL,specs))
make_draw <- function(b) do.call(rbind,lapply(seq_len(N),function(k) {
 z <- blocks[[draws[b,k]]]; z$fid <- k; z
}))
for(b in seq_len(B)) {
 z <- make_draw(b)
 stopifnot(all(c('Low','Middle','High') %in% z$group))
 dx <- summarize_delta(z)
 results[[b]] <- do.call(rbind,lapply(seq_along(specs),function(j) {
  beta <- unname(coef(fit(z,specs[j],FALSE))['ehi1'])
  stopifnot(is.finite(beta)); beta_draws[b,j] <<- beta
  data.frame(draw=b,specification=specs[j],summary=names(dx),
   delta_ACH=unname(dx),beta=beta,rate_difference=beta*unname(dx))
 }))
 if(b%%250==0) {cat('Natural ACH bootstrap',b,'/',B,'\n');flush.console()}
}
write.csv(do.call(rbind,results),file.path(out,'bootstrap_natural_ACH_summaries.csv'),row.names=FALSE)
# Reconstruct three saved draws and refit with clustered inference enabled.
verification <- do.call(rbind,lapply(unique(c(1L,as.integer(B/2),B)),function(b) {
 z <- make_draw(b)
 do.call(rbind,lapply(seq_along(specs),function(j) {
  beta <- unname(coef(fit(z,specs[j]))['ehi1'])
  data.frame(draw=b,specification=specs[j],saved_beta=beta_draws[b,j],
   recomputed_beta=beta,absolute_difference=abs(beta-beta_draws[b,j]))
 }))
}))
stopifnot(max(verification$absolute_difference)<1e-10)
write.csv(verification,file.path(out,'bootstrap_draw_verification.csv'),row.names=FALSE)
jsonlite::write_json(list(completed=TRUE,seed=20261015,draws=B,successful=B,
 input=paper1_new_panel_path(),input_md5=unname(tools::md5sum(paper1_new_panel_path())),
 natural_input=nat_path,fixed_groups_input=group_path,rows=nrow(d),countries=N,
 controls=controls,baseline_SDI_cuts=as.numeric(cuts),R=R.version.string,
 fixest=as.character(packageVersion('fixest')),
 calibration='Existing ERA5-anchored daily temperature counterfactual; no new quantile fit',
 bootstrap='Unstratified country blocks; independent FE IDs for copies; fixed SDI groups; refit both specifications',
 sources_md5=as.list(tools::md5sum(c('code/run_natural_ach_health_20261015.R',file.path('code/R',sources))))),
 file.path(out,'refit_completed.json'),auto_unbox=TRUE,pretty=TRUE)
print(coefs);cat('Natural ACH health refit complete\n')
