"""Revalidate the existing ERA5-anchored natural panel and translate ACH only.

This is not a new quantile calibration and does not modify upstream climate
data, historical models, SSP analyses, or manuscript modules outside hist-nat.
Run after run_natural_ach_health_20261015.R, using the same external directory.
"""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
NAT = Path('data/input')
OLD = Path('data/input')
PRIMARY = 'primary_TWFE'
TREND = 'country_trend_sensitivity'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def check(value, message):
    if not bool(value):
        raise ValueError(message)


def translate(delta, beta, low, high):
    delta = np.asarray(delta, dtype=float)
    a, b = delta * low, delta * high
    return delta * beta, np.minimum(a, b), np.maximum(a, b)


def independent_balanced_panel_beta(estimation, trend=False):
    """Independent FWL computation for this complete balanced panel only."""
    controls = ['mean_value', 'SEV_agestd_diet_fruit', 'SEV_agestd_diet_veg',
                'SEV_agestd_metab_bmi', 'SEV_agestd_metab_fpg', 'SEV_agestd_metab_sbp']
    z = estimation.sort_values(['fid', 'year_id'])
    check(z.groupby('fid').year_id.apply(lambda x: list(x) == list(range(1990, 2021))).all(),
          'Independent projection needs a balanced 1990-2020 panel')
    a = z[['val', 'ehi1', *controls]].to_numpy().reshape(-1, 31, 8)
    a = a - a.mean(axis=1, keepdims=True) - a.mean(axis=0, keepdims=True) + a.mean(axis=(0, 1), keepdims=True)
    if trend:
        t = np.arange(31, dtype=float) - 15
        slopes = np.einsum('ntk,t->nk', a, t) / (t @ t)
        a = a - slopes[:, None, :] * t[None, :, None]
    a = a.reshape(-1, 8)
    return float(np.linalg.lstsq(a[:, 1:], a[:, 0], rcond=None)[0][0])


def align_panel(natural, estimation):
    check(not natural.duplicated(['fid', 'year']).any(), 'Duplicate natural keys')
    check(not estimation.duplicated(['fid', 'year_id']).any(), 'Duplicate estimation keys')
    p = estimation.rename(columns={'year_id': 'year', 'ehi1': 'ACH_observed',
                                    'val': 'DALYs_rate_observed', 'group': 'SDI_group'})
    p = p.merge(natural[['fid', 'year', 'region_id', 'admin', 'sampling_method',
        'sample_grid_cell_count', 'model', 'member', 'ACH', 'ACH_observed',
        'ACH_observed_reaggregated']], on=['fid', 'year'], how='outer',
        validate='one_to_one', suffixes=('', '_climate'), indicator=True)
    check(p['_merge'].eq('both').all(), 'Climate/health membership differs')
    check(np.isfinite(p[['ACH_observed', 'ACH', 'ACH_observed_climate',
        'ACH_observed_reaggregated']]).all().all(), 'Non-finite exposures')
    p['observed_alignment_residual'] = p.ACH_observed - p.ACH_observed_reaggregated
    check(np.max(np.abs(p.ACH_observed - p.ACH_observed_climate)) < 1e-5,
          'Climate historical exposure differs from health input')
    check(p.observed_alignment_residual.abs().max() < 1e-5, 'Factual anchor mismatch')
    # The existing daily ERA5-minus-signal construction is the calibration.
    # Preserve its event-derived ACH: annual residual shifting or QDM would
    # alter the estimand and cannot recover a daily-calibrated counterfactual.
    p['ACH_natural_source'] = p.ACH
    p['ACH_natural_calibrated'] = p.ACH
    p['additional_annual_ACH_adjustment'] = 0.0
    p['delta_ACH_anthropogenic'] = p.ACH_observed - p.ACH_natural_calibrated
    check(np.max(np.abs(p.delta_ACH_anthropogenic - p.delta_ACH)) < 1e-10,
          'R/Python exposure contrasts differ')
    check((p[['ACH_observed', 'ACH_natural_calibrated']] >= 0).all().all(),
          'Negative physical ACH')
    bounds = p.groupby('fid').ACH_observed.agg(['min', 'max'])
    p['observed_country_min_ACH'] = p.fid.map(bounds['min'])
    p['observed_country_max_ACH'] = p.fid.map(bounds['max'])
    p['natural_within_country_observed_range'] = p.ACH_natural_calibrated.between(
        p.observed_country_min_ACH, p.observed_country_max_ACH)
    p['negative_anthropogenic_contrast'] = p.delta_ACH_anthropogenic < 0
    p['calibration_method'] = 'existing_daily_ERA5_minus_BCC_paired_signal'
    p['calibration_status'] = 'ERA5_anchor_revalidated_no_new_quantile_fit'
    return p.drop(columns=['_merge', 'ACH', 'ACH_observed_climate', 'ACH_natural', 'delta_ACH'])


def main(out):
    done = json.loads((out / 'refit_completed.json').read_text(encoding='utf-8'))
    check(done['successful'] >= 2000, 'Bootstrap incomplete')
    estimation = pd.read_csv(out / 'DALYs_ACH_estimation_panel.csv')
    nat = pd.read_csv('data/input/natural_forcing_panel.csv.gz')
    p = nat.merge(estimation[['fid','year_id','val']].rename(columns={'year_id':'year','val':'DALYs_rate_observed'}),on=['fid','year'],validate='one_to_one')
    check(len(p)==6293 and p.fid.nunique()==203,'Analytic sample')
    np.testing.assert_allclose(p.ACH_observed-p.ACH_natural_calibrated,p.delta_ACH_anthropogenic,atol=1e-8)
    coefs = pd.read_csv(out / 'DALYs_ACH_coefficients.csv')
    independent = []
    for c in coefs.itertuples():
        b = independent_balanced_panel_beta(estimation, c.specification == TREND)
        check(abs(b - c.beta) < 1e-8, 'Independent Python coefficient verification failed')
        independent.append(dict(specification=c.specification, R_beta=c.beta,
                                Python_FWL_beta=b, absolute_difference=abs(b-c.beta)))
    pd.DataFrame(independent).to_csv(out/'independent_coefficient_verification.csv', index=False)
    health = []
    for c in coefs.itertuples():
        z = p.copy()
        z['specification'] = c.specification
        z['beta'] = c.beta
        z['rate_difference'], z['coefficient_ci_low'], z['coefficient_ci_high'] = translate(
            z.delta_ACH_anthropogenic, c.beta, c.ci_low, c.ci_high)
        z['rate_unit'] = 'age_standardised_CVD_DALY_rate_per_100000'
        z['interval_scope'] = 'health_coefficient_only'
        health.append(z)
    health = pd.concat(health, ignore_index=True)
    health.to_csv(out / 'anthropogenic_ACH_DALYs_country_year.csv', index=False,
                  encoding='utf-8-sig')
    boot = pd.read_csv(out / 'bootstrap_natural_ACH_summaries.csv')
    check(boot.groupby(['specification', 'summary']).draw.nunique().eq(done['draws']).all(),
          'Incomplete bootstrap summaries')
    check(not boot.duplicated(['draw', 'specification', 'summary']).any(), 'Duplicate draws')
    check(np.isfinite(boot[['delta_ACH', 'beta', 'rate_difference']]).all().all(),
          'Nonfinite bootstrap')
    summaries = []

    def summary(label, z, boot_key=None, subtraction=None, extra=None):
        # Average the signed exposure contrast first, then propagate shared beta.
        dx = z.delta_ACH_anthropogenic.mean()
        obs, natural = z.ACH_observed.mean(), z.ACH_natural_calibrated.mean()
        if subtraction is not None:
            dx -= subtraction.delta_ACH_anthropogenic.mean()
            obs -= subtraction.ACH_observed.mean()
            natural -= subtraction.ACH_natural_calibrated.mean()
        for c in coefs.itertuples():
            point, lo, hi = translate(dx, c.beta, c.ci_low, c.ci_high)
            row = dict(summary=label, specification=c.specification,
                countries=z.fid.nunique(), country_years=len(z),
                ACH_observed_mean=obs, ACH_natural_mean=natural,
                delta_ACH_mean=dx, rate_difference=float(point),
                coefficient_ci_low=float(lo), coefficient_ci_high=float(hi),
                bootstrap_rate_low=np.nan, bootstrap_rate_high=np.nan,
                bootstrap_delta_low=np.nan, bootstrap_delta_high=np.nan)
            if boot_key:
                b = boot[(boot.specification == c.specification) & (boot.summary == boot_key)]
                check(len(b) == done['draws'], 'Bootstrap key missing')
                row['bootstrap_rate_low'], row['bootstrap_rate_high'] = b.rate_difference.quantile([.025, .975])
                row['bootstrap_delta_low'], row['bootstrap_delta_high'] = b.delta_ACH.quantile([.025, .975])
            if extra:
                row.update(extra)
            summaries.append(row)

    summary('overall_1990_2020', p, 'overall')
    for year in range(1990, 2021):
        summary(f'year_{year}', p[p.year == year],
                f'year_{year}' if year in [1990, 2020] else None, extra={'year': year})
    for a, b in [(1990, 1999), (2011, 2020)]:
        summary(f'period_{a}_{b}', p[p.year.between(a, b)], f'period_{a}_{b}')
    for g in ['Low', 'Middle', 'High']:
        summary(f'SDI_{g}', p[p.SDI_group == g], f'SDI_{g}')
    for a, b in [('High', 'Low'), ('Middle', 'Low'), ('High', 'Middle')]:
        summary(f'{a}_minus_{b}', p[p.SDI_group == a], f'{a}_minus_{b}',
                p[p.SDI_group == b], {'comparator_countries': p[p.SDI_group == b].fid.nunique(),
                                     'comparator_country_years': len(p[p.SDI_group == b])})
    for fid, z in p.groupby('fid'):
        summary(f'country_{fid}', z, extra={'fid': fid, 'country': z.location_name.iloc[0],
                                          'SDI_group': z.SDI_group.iloc[0]})
    s = pd.DataFrame(summaries)
    s.to_csv(out / 'all_natural_ACH_DALYs_summaries.csv', index=False, encoding='utf-8-sig')
    s[s.summary.str.startswith('year_')].to_csv(out / 'annual_equal_country.csv', index=False)
    s[s.summary.str.startswith('country_')].to_csv(out / 'country_1990_2020.csv', index=False,
                                                   encoding='utf-8-sig')
    s[s.summary.str.startswith('SDI_') | s.summary.str.contains('_minus_')].to_csv(
        out / 'fixed_SDI_groups_and_gaps.csv', index=False)
    main_s = s[~s.summary.str.startswith(('year_', 'country_'))]
    main_s.to_csv(out / 'main_result_table.csv', index=False)
    print('GBD2023 natural-forcing health summaries and independent coefficient verification complete.')

if __name__ == '__main__':
    import sys
    main(Path(sys.argv[1]))
