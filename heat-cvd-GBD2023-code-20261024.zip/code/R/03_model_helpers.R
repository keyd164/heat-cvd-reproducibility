paper1_extract_fixest_term <- function(model, term) {
  coefficients <- stats::coef(model)

  if (!term %in% names(coefficients)) {
    stop("Coefficient not estimated: ", term, call. = FALSE)
  }

  beta <- unname(coefficients[[term]])
  se <- unname(fixest::se(model)[[term]])

  data.frame(
    term_name = term,
    beta = beta,
    se = se,
    ci_low = beta - 1.96 * se,
    ci_high = beta + 1.96 * se,
    p_value = unname(fixest::pvalue(model)[[term]]),
    stringsAsFactors = FALSE
  )
}

paper1_effect_scale <- function(data,
                                beta,
                                exposure,
                                outcome = "val") {
  exposure_values <- suppressWarnings(as.numeric(data[[exposure]]))
  outcome_values <- suppressWarnings(as.numeric(data[[outcome]]))

  ehi_sd <- stats::sd(exposure_values, na.rm = TRUE)
  outcome_sd <- stats::sd(outcome_values, na.rm = TRUE)

  if (!is.finite(ehi_sd) || ehi_sd == 0) ehi_sd <- NA_real_
  if (!is.finite(outcome_sd) || outcome_sd == 0) outcome_sd <- NA_real_

  beta_per_1sd_ehi <- if (is.finite(ehi_sd)) beta * ehi_sd else NA_real_

  standardized_beta <- if (
    is.finite(beta_per_1sd_ehi) &&
    is.finite(outcome_sd)
  ) {
    beta_per_1sd_ehi / outcome_sd
  } else {
    NA_real_
  }

  data.frame(
    ehi_sd = ehi_sd,
    outcome_sd = outcome_sd,
    beta_per_1sd_ehi = beta_per_1sd_ehi,
    standardized_beta = standardized_beta,
    stringsAsFactors = FALSE
  )
}

paper1_extract_r2 <- function(model,
                              null_data,
                              null_formula_str,
                              country_var = "fid") {
  r2_vec <- tryCatch(
    fixest::r2(model, type = "all"),
    error = function(e) c(r2 = NA_real_, ar2 = NA_real_)
  )

  r2_full <- unname(r2_vec["r2"])
  ar2_full <- unname(r2_vec["ar2"])
  within_r2_full <- unname(r2_vec["wr2"])
  adj_within_r2_full <- unname(r2_vec["war2"])

  partial_r2_ehi <- tryCatch({
    null_model <- fixest::feols(
      stats::as.formula(null_formula_str),
      data = null_data,
      cluster = stats::as.formula(paste0("~", country_var)),
      notes = FALSE
    )

    r2_reduced <- unname(fixest::r2(null_model, type = "all")["r2"])

    if (
      is.finite(r2_reduced) &&
      is.finite(r2_full) &&
      r2_reduced < 1 - sqrt(.Machine$double.eps)
    ) {
      (r2_full - r2_reduced) / (1 - r2_reduced)
    } else {
      NA_real_
    }
  }, error = function(e) NA_real_)

  data.frame(
    r_squared = r2_full,
    adj_r_squared = ar2_full,
    within_r_squared = within_r2_full,
    adj_within_r_squared = adj_within_r2_full,
    partial_r_squared_ehi = partial_r2_ehi,
    stringsAsFactors = FALSE
  )
}

extract_fixest_term <- function(model, term) {
  result <- paper1_extract_fixest_term(model, term)
  result[, setdiff(names(result), "term_name"), drop = FALSE]
}

build_paper1_effect_scale <- function(data, beta, exposure, outcome = "val") {
  paper1_effect_scale(data, beta, exposure, outcome)
}

extract_paper1_r2 <- function(model, null_data, null_formula_str, country_var = "fid") {
  paper1_extract_r2(model, null_data, null_formula_str, country_var)
}

paper1_joint_wald_test <- function(model, terms) {
  terms <- unique(terms)
  coefficients <- stats::coef(model)
  missing <- setdiff(terms, names(coefficients))
  if (length(missing) > 0) {
    stop(
      "Joint Wald terms were not estimated: ",
      paste(missing, collapse = ", "),
      call. = FALSE
    )
  }

  beta <- coefficients[terms]
  covariance <- stats::vcov(model)[terms, terms, drop = FALSE]
  inverse_beta <- tryCatch(
    solve(covariance, beta),
    error = function(e) qr.solve(covariance, beta)
  )
  statistic <- as.numeric(crossprod(beta, inverse_beta))
  degrees_freedom <- length(terms)

  data.frame(
    joint_test_statistic = statistic,
    joint_test_df = as.integer(degrees_freedom),
    joint_test_terms = as.integer(degrees_freedom),
    p_value = stats::pchisq(
      statistic,
      df = degrees_freedom,
      lower.tail = FALSE
    ),
    stringsAsFactors = FALSE
  )
}
