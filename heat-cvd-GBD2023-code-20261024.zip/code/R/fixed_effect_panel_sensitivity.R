# Country/year FE is primary. These functions estimate associations only.
# Population-weighted exposure is a grid aggregation, never a regression weight.

paper1_sensitivity_controls <- function() {
  c("mean_value", "SEV_agestd_diet_fruit", "SEV_agestd_diet_veg",
    "SEV_agestd_metab_bmi", "SEV_agestd_metab_fpg", "SEV_agestd_metab_sbp")
}

paper1_sensitivity_complete <- function(data, variables) {
  check_required_columns(data, variables, "Sensitivity input")
  keep <- stats::complete.cases(data[variables])
  for (v in variables) if (is.numeric(data[[v]])) keep <- keep & is.finite(data[[v]])
  data[keep, , drop = FALSE]
}

paper1_sensitivity_fit <- function(data, rhs, fe = "fid + year_id") {
  fixest::feols(stats::as.formula(paste("val ~", paste(rhs, collapse = " + "), "|", fe)),
    data = data, cluster = ~fid, panel.id = ~fid + year_id, notes = FALSE,
    ssc = fixest::ssc(t.df = "min", G.df = "min"))
}

paper1_sensitivity_used <- function(model, data) {
  idx <- paper1_estimation_row_index(model, nrow(data))
  if (length(idx) != stats::nobs(model)) stop("Estimation row alignment failed")
  data[idx, , drop = FALSE]
}

paper1_sensitivity_contrast <- function(model, data, terms, weights = rep(1, length(terms))) {
  b <- stats::coef(model)[terms]
  if (any(!is.finite(b))) stop("Contrast terms not estimated")
  V <- stats::vcov(model)[terms, terms, drop = FALSE]
  estimate <- sum(weights * b)
  se <- sqrt(max(0, as.numeric(t(weights) %*% V %*% weights)))
  used <- paper1_sensitivity_used(model, data)
  G <- length(unique(used$fid))
  df <- G - 1L
  critical <- stats::qt(.975, df)
  data.frame(beta = estimate, se = se, ci_low = estimate - critical * se,
    ci_high = estimate + critical * se,
    p_value = 2 * stats::pt(-abs(estimate / se), df),
    n_obs = nrow(used), n_country = G, inference_df = df,
    sample_start_year = min(used$year_id), sample_end_year = max(used$year_id))
}

paper1_sensitivity_joint <- function(model, data, terms) {
  b <- stats::coef(model)[terms]
  V <- stats::vcov(model)[terms, terms, drop = FALSE]
  if (any(!is.finite(b)) || qr(V)$rank != length(terms)) stop("Joint test not identified")
  used <- paper1_sensitivity_used(model, data)
  q <- length(terms)
  G <- length(unique(used$fid))
  statistic <- as.numeric(crossprod(b, solve(V, b))) / q
  data.frame(test_statistic = statistic, df_num = q, df_den = G - 1L,
    p_value = stats::pf(statistic, q, G - 1L, lower.tail = FALSE),
    n_obs = nrow(used), n_country = G, inference = "country_cluster_Wald_F")
}

paper1_sensitivity_m4_fit <- function(data, exposure) {
  lags <- attr(data, "paper1_identification_lag_cols")
  controls <- attr(data, "paper1_identification_controls")
  d <- paper1_sensitivity_complete(data, c("val", exposure, lags, controls,
                                         "fid", "year_id", "paper1_region_year_fe"))
  d <- paper1_almon_basis(d, exposure, lags)
  basis <- attr(d, "paper1_almon_cols")
  fit <- paper1_sensitivity_fit(d, c(basis, controls),
    paper1_identification_fe(country_trend = TRUE))
  list(model = fit, data = d, basis = basis, controls = controls, lags = lags)
}

paper1_run_panel_sensitivity <- function(data, exposure = "ehi1",
                                        excluded_ids = c("230", "222", "237", "245")) {
  controls <- paper1_sensitivity_controls()
  own <- paper1_sensitivity_complete(data, c("val", exposure, controls, "fid", "year_id"))
  primary <- paper1_sensitivity_fit(own, c(exposure, controls))
  primary_row <- cbind(model_id = paper1_main_model_id(), sample_type = "own_sample",
    estimand = "current_exposure_association", is_primary_result = TRUE,
    paper1_sensitivity_contrast(primary, own, exposure))

  prepared <- paper1_prepare_identification_data(data, exposure)
  lags <- attr(prepared, "paper1_identification_lag_cols")
  leads <- attr(prepared, "paper1_identification_lead_cols")
  id_controls <- attr(prepared, "paper1_identification_controls")
  common <- paper1_sensitivity_complete(prepared,
    c("val", exposure, controls, id_controls, lags, leads, "fid", "year_id",
      "paper1_region_year_fe"))
  # The richest FE specification can remove singleton region-year cells.
  # Harmonise on its actual estimation rows, rather than just complete cases.
  common <- paper1_sensitivity_used(
    paper1_sensitivity_m4_fit(common, exposure)$model, common)
  common$paper1_common_row_id <- seq_len(nrow(common))
  attr(common, "paper1_identification_lag_cols") <- lags
  attr(common, "paper1_identification_lead_cols") <- leads
  attr(common, "paper1_identification_controls") <- id_controls

  specs <- list(
    TWFE_unadjusted = list(rhs = exposure, fe = "fid + year_id"),
    TWFE_fully_adjusted = list(rhs = c(exposure, controls), fe = "fid + year_id"),
    TWFE_fully_adjusted_country_trend = list(rhs = c(exposure, controls), fe = "fid[year_id] + year_id"),
    region_year_country_trend_same_controls = list(rhs = c(exposure, controls),
      fe = paper1_identification_fe(country_trend = TRUE)),
    M3_identification_controls = list(rhs = c(exposure, id_controls),
      fe = paper1_identification_fe(country_trend = TRUE)))
  ladder <- list()
  used_keys <- paste(common$fid, common$year_id)
  for (id in names(specs)) {
    s <- specs[[id]]
    fit <- paper1_sensitivity_fit(common, s$rhs, s$fe)
    used <- paper1_sensitivity_used(fit, common)
    if (!identical(paste(used$fid, used$year_id), used_keys)) stop("Ladder samples differ")
    ladder[[id]] <- cbind(model_id = id, sample_type = "lag_lead_common_sample",
      estimand = "current_exposure_association", is_primary_result = FALSE,
      used_controls = paste(setdiff(s$rhs, exposure), collapse = ";"),
      paper1_sensitivity_contrast(fit, common, exposure))
  }
  m4 <- paper1_sensitivity_m4_fit(common, exposure)
  # B = 3 theta0 + 3 theta1 + 5 theta2 for lags k=0,1,2.
  m4_row <- cbind(model_id = "M4_quadratic_Almon_parameterization",
    sample_type = "lag_lead_common_sample", estimand = "lag_0_2_coefficient_sum",
    is_primary_result = FALSE, used_controls = paste(id_controls, collapse = ";"),
    paper1_sensitivity_contrast(m4$model, m4$data, m4$basis, c(3, 3, 5)))
  ladder[["M4"]] <- m4_row
  lag_fit <- paper1_sensitivity_fit(common, c(exposure, lags, id_controls),
    paper1_identification_fe(country_trend = TRUE))
  audit <- data.frame(max_abs_fitted_difference = max(abs(fitted(lag_fit) - fitted(m4$model))),
    unconstrained_sum = sum(stats::coef(lag_fit)[c(exposure, lags)]),
    almon_sum = m4_row$beta, lag_count = 3L, parameter_count = 3L,
    additional_smoothing_constraints = 0L)

  placebos <- list()
  placebo_specs <- list(
    TWFE_lag_lead_joint = list(rhs = c(exposure, lags, leads, controls),
      fe = "fid + year_id"),
    M4_lag_lead_joint = list(rhs = c(m4$basis, leads, id_controls),
      fe = paper1_identification_fe(country_trend = TRUE)))
  common_basis <- paper1_almon_basis(common, exposure, lags)
  for (id in names(placebo_specs)) {
    s <- placebo_specs[[id]]
    fit <- paper1_sensitivity_fit(common_basis, s$rhs, s$fe)
    used <- paper1_sensitivity_used(fit, common_basis)
    if (!identical(paste(used$fid, used$year_id), used_keys)) stop("Placebo samples differ from ladder")
    placebos[[id]] <- cbind(model_id = id, tested_terms = paste(leads, collapse = ";"),
      sample_type = "lag_lead_common_sample",
      paper1_sensitivity_joint(fit, common_basis, leads))
  }

  variants <- c(list(full_new_panel = character()),
    stats::setNames(lapply(excluded_ids, function(x) x), paste0("exclude_", excluded_ids)),
    list(exclude_all_four = excluded_ids))
  influence <- list()
  for (v in names(variants)) {
    d <- data[!as.character(data$fid) %in% variants[[v]], , drop = FALSE]
    p <- paper1_sensitivity_complete(d, c("val", exposure, controls, "fid", "year_id"))
    pf <- paper1_sensitivity_fit(p, c(exposure, controls))
    prep <- paper1_prepare_identification_data(d, exposure)
    mf <- paper1_sensitivity_m4_fit(prep, exposure)
    influence[[paste0(v, "_twfe")]] <- cbind(sample_variant = v,
      excluded_ids = paste(variants[[v]], collapse = ";"), model_id = paper1_main_model_id(),
      estimand = "current_exposure_association",
      paper1_sensitivity_contrast(pf, p, exposure))
    influence[[paste0(v, "_m4")]] <- cbind(sample_variant = v,
      excluded_ids = paste(variants[[v]], collapse = ";"),
      model_id = "M4_quadratic_Almon_parameterization", estimand = "lag_0_2_coefficient_sum",
      paper1_sensitivity_contrast(mf$model, mf$data, mf$basis, c(3, 3, 5)))
  }
  retained <- paper1_sensitivity_used(primary, own)
  list(primary = primary_row, ladder = do.call(rbind, ladder),
    placebos = do.call(rbind, placebos), influence = do.call(rbind, influence),
    almon_audit = audit,
    common_keys = common[c("fid", "year_id")],
    primary_keys = retained[c("fid", "year_id")],
    primary_fit = primary)
}

# Restricted cubic spline of RAW exposure, with three knots and full primary FE.
paper1_raw_cahe_nonlinear_basis <- function(x, knots) {
  a <- knots[1L]; b <- knots[2L]; c <- knots[3L]
  if (length(knots) != 3L || any(diff(knots) <= 0)) stop("Spline knots must be distinct")
  (pmax(x - a, 0)^3 - pmax(x - b, 0)^3 * (c - a) / (c - b) +
     pmax(x - c, 0)^3 * (b - a) / (c - b)) / (c - a)^2
}

paper1_fit_raw_cahe_spline <- function(data, exposure = "ehi1") {
  controls <- paper1_sensitivity_controls()
  d <- paper1_sensitivity_complete(data, c("val", exposure, controls, "fid", "year_id"))
  knots <- unname(stats::quantile(d[[exposure]], c(.1, .5, .9)))
  d$paper1_raw_cahe_nonlinear <- paper1_raw_cahe_nonlinear_basis(d[[exposure]], knots)
  fit <- paper1_sensitivity_fit(d, c(exposure, "paper1_raw_cahe_nonlinear", controls))
  tests <- rbind(
    cbind(test = "nonlinearity", paper1_sensitivity_joint(fit, d, "paper1_raw_cahe_nonlinear")),
    cbind(test = "overall_exposure", paper1_sensitivity_joint(fit, d,
      c(exposure, "paper1_raw_cahe_nonlinear"))))
  ref <- unname(stats::median(d[[exposure]]))
  grid <- seq(min(d[[exposure]]), max(d[[exposure]]), length.out = 151L)
  curve <- lapply(grid, function(x) {
    weights <- c(x - ref,
      paper1_raw_cahe_nonlinear_basis(x, knots) - paper1_raw_cahe_nonlinear_basis(ref, knots))
    cbind(exposure_value = x, reference_exposure = ref,
      paper1_sensitivity_contrast(fit, d, c(exposure, "paper1_raw_cahe_nonlinear"), weights))
  })
  list(tests = tests, curve = do.call(rbind, curve),
    knots = data.frame(probability = c(.1, .5, .9), exposure_value = knots), fit = fit)
}

paper1_compare_population_exposure <- function(data, pop_panel) {
  check_required_columns(pop_panel, c("fid", "year_id", "population_weighted_cahe"))
  check_country_year_unique(pop_panel)
  a <- paste(data$fid, data$year_id)
  b <- paste(pop_panel$fid, pop_panel$year_id)
  data$paper1_population_weighted_cahe <- pop_panel$population_weighted_cahe[match(a, b)]
  controls <- paper1_sensitivity_controls()
  d <- paper1_sensitivity_complete(data,
    c("val", "ehi1", "paper1_population_weighted_cahe", controls, "fid", "year_id"))
  if (!nrow(d)) stop("No matching population-weighted exposure")
  rows <- lapply(c("ehi1", "paper1_population_weighted_cahe"), function(exposure) {
    fit <- paper1_sensitivity_fit(d, c(exposure, controls))
    used <- paper1_sensitivity_used(fit, d)
    if (!identical(paste(used$fid, used$year_id), paste(d$fid, d$year_id))) {
      stop("Population-exposure comparison lost common rows")
    }
    cbind(exposure = exposure, regression_weights = "none",
      sample_type = "population_exposure_matched_sample",
      paper1_sensitivity_contrast(fit, d, exposure))
  })
  do.call(rbind, rows)
}
