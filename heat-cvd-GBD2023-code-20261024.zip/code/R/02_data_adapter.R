paper1_normalize_raw <- function(raw, outcome_measure = NULL) {
  d <- raw
  .rn <- function(from, to) {
    if (from %in% names(d) && !to %in% names(d)) {
      names(d)[names(d) == from] <<- to
    }
  }
  # New GBD age-standardized long-panel column names -> paper1 contract.
  .rn("year", "year_id")
  .rn("pop", "population")
  .rn("SDI", "mean_value")
  .rn("absolute_cumulative_heat", "ehi1")
  .rn("relative_cumulative_heat", "ehi13")
  .rn("mixed_cumulative_heat", "ehi14")
  .rn("GBDregion", "world_region")
  .rn("WBregion", "world_region")
  .rn("FID", "fid")

  # Long panel mixes four measures; keep only the requested outcome.
  if ("measure_id" %in% names(d) && !is.null(outcome_measure)) {
    mid <- switch(as.character(outcome_measure),
      "Death" = 1L, "Deaths" = 1L,
      "DALYs" = 2L,
      "Incidence" = 6L, "CBD" = 6L, "Leukemia" = 6L,
      "Prevalence" = 5L,
      NULL
    )
    if (!is.null(mid)) {
      d <- d[as.integer(d$measure_id) == mid, , drop = FALSE]
    }
  }
  d
}

load_paper1_raw_data <- function(config) {
  if (is.null(config$input_data_path)) {
    stop("config must contain input_data_path", call. = FALSE)
  }
  data <- utils::read.csv(config$input_data_path, stringsAsFactors = FALSE,
                          check.names = FALSE)
  data
}

# Country-year keys that cannot identify a panel unit are unusable. The new
# age-standardized panel ships a small block of rows whose fid was never
# matched to a country (one country-year series); keeping them breaks every
# fixed-effects fit and the uniqueness contract.
paper1_drop_invalid_keys <- function(data,
                                     country_var = "fid",
                                     year_var = "year_id",
                                     context = "Paper 1 panel") {
  country <- trimws(as.character(data[[country_var]]))
  year <- suppressWarnings(as.numeric(as.character(data[[year_var]])))
  invalid <- is.na(country) | !nzchar(country) |
    country %in% c("NA", "NaN") | !is.finite(year)
  if (any(invalid)) {
    message(
      context, ": dropping ", sum(invalid),
      " row(s) with an unusable country-year key."
    )
    data <- data[!invalid, , drop = FALSE]
  }
  data
}

prepare_paper1_panel <- function(raw_data, outcome_measure, config = NULL) {
  raw_data <- paper1_normalize_raw(raw_data, outcome_measure)

  required_cols <- c("fid", "year_id", "val", "population")
  missing_cols <- setdiff(required_cols, names(raw_data))
  if (length(missing_cols) > 0) {
    stop("Paper 1 panel data is missing required columns: ",
         paste(missing_cols, collapse = ", "), call. = FALSE)
  }

  raw_data <- paper1_drop_invalid_keys(raw_data)

  d <- raw_data[order(raw_data$fid, raw_data$year_id), , drop = FALSE]

  d$paper1_outcome_measure <- outcome_measure

  year_num <- suppressWarnings(as.numeric(as.character(d$year_id)))
  d$paper1_year_num <- year_num
  d$paper1_year_c <- year_num - mean(year_num, na.rm = TRUE)
  d$paper1_year_c2 <- d$paper1_year_c^2
  d$paper1_country_factor <- as.factor(d$fid)
  d$paper1_year_factor <- as.factor(d$year_id)

  d
}

validate_paper1_panel <- function(panel,
                                  exposure_vars = paper1_ehi_all(),
                                  min_countries = 2,
                                  min_rows = 10,
                                  context = "Paper 1 panel") {
  core <- c("fid", "year_id", "val", "ehi1")
  check_required_columns(panel, core, context)
  missing_exposure <- setdiff(exposure_vars, names(panel))
  if (length(missing_exposure) > 0) {
    warning(context, ": optional exposure columns absent (skipped): ",
            paste(missing_exposure, collapse = ", "), call. = FALSE)
  }
  check_country_year_unique(
    panel,
    country_var = "fid",
    year_var = "year_id",
    context = context
  )
  check_min_panel_size(
    panel,
    country_var = "fid",
    min_countries = min_countries,
    min_rows = min_rows,
    context = context
  )

  invisible(TRUE)
}

prepare_paper1_analysis_data <- function(raw_data, outcome_measure, exposure, config = NULL) {
  panel <- prepare_paper1_panel(raw_data, outcome_measure, config)
  validate_paper1_panel(panel, exposure)

  needed <- c("val", exposure, "year_id", "fid")
  d <- panel[stats::complete.cases(panel[needed]), , drop = FALSE]

  attr(d, "paper1_outcome_measure") <- outcome_measure
  attr(d, "paper1_exposure") <- exposure
  attr(d, "paper1_n_original") <- nrow(panel)
  attr(d, "paper1_n_complete") <- nrow(d)

  d
}
