check_required_columns <- function(data, required, context = "data") {
  missing <- setdiff(required, names(data))
  if (length(missing) > 0) {
    stop(
      context, " is missing required columns: ",
      paste(missing, collapse = ", "),
      call. = FALSE
    )
  }
  invisible(TRUE)
}

require_columns <- check_required_columns

check_country_year_unique <- function(data,
                                      country_var = "fid",
                                      year_var = "year_id",
                                      context = "data") {
  check_required_columns(data, c(country_var, year_var), context)

  country <- trimws(as.character(data[[country_var]]))
  year <- suppressWarnings(as.numeric(as.character(data[[year_var]])))

  invalid <- is.na(country) | !nzchar(country) | !is.finite(year)
  if (any(invalid)) {
    stop(context, " has invalid country-year keys.", call. = FALSE)
  }

  key <- paste(country, year, sep = "\r")
  if (anyDuplicated(key)) {
    stop(context, " has duplicated country-year rows.", call. = FALSE)
  }

  invisible(TRUE)
}

check_min_panel_size <- function(data,
                                 country_var = "fid",
                                 min_countries = 2,
                                 min_rows = 10,
                                 context = "model data") {
  if (nrow(data) < min_rows) {
    stop(context, " has insufficient rows.", call. = FALSE)
  }

  n_country <- length(unique(data[[country_var]]))
  if (n_country < min_countries) {
    stop(context, " has insufficient countries.", call. = FALSE)
  }

  invisible(TRUE)
}

validate_paper1_input <- function(data,
                                  exposure,
                                  outcome = "val",
                                  year_var = "year_id",
                                  country_var = "fid",
                                  context = "Paper 1 input") {
  required <- c(outcome, exposure, year_var, country_var)

  check_required_columns(data, required, context)
  check_country_year_unique(data, country_var, year_var, context)
  check_min_panel_size(data, country_var, context = context)

  invisible(TRUE)
}