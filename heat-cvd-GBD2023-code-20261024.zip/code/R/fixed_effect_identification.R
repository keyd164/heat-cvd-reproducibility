# Identification strategy for the country-year CAHE--CVD panel.
#
# This module deliberately separates annual anomalous-exposure association from
# slow co-movement.  It never supplies population weights: each country-year
# is one observation in every estimation below.

paper1_identification_bind_rows <- function(...) {
  rows <- list(...)
  rows <- Filter(Negate(is.null), rows)
  columns <- unique(unlist(lapply(rows, names), use.names = FALSE))
  rows <- lapply(rows, function(x) {
    missing <- setdiff(columns, names(x))
    for (column in missing) x[[column]] <- NA
    x[columns]
  })
  do.call(rbind, rows)
}

paper1_identification_region_var <- function(data,
                                             candidates = c(
                                               "gbd_super_region",
                                               "GBD_super_region",
                                               "world_region",
                                               "world_bank_region",
                                               "World_Bank_region",
                                               "region"
                                             )) {
  hit <- candidates[candidates %in% names(data)]
  if (length(hit) == 0L) {
    stop(
      "The identification strategy requires a prespecified region variable. ",
      "Provide one of: ", paste(candidates, collapse = ", "),
      call. = FALSE
    )
  }
  hit[[1L]]
}

paper1_add_identification_shifts <- function(data,
                                             exposure,
                                             year_var = "year_id",
                                             country_var = "fid",
                                             max_lag = 2L,
                                             max_lead = 2L,
                                             prefix = "paper1_id") {
  required <- c(exposure, year_var, country_var)
  missing <- setdiff(required, names(data))
  if (length(missing) > 0L) {
    stop("Identification data is missing: ", paste(missing, collapse = ", "),
         call. = FALSE)
  }

  d <- data[order(data[[country_var]], data[[year_var]]), , drop = FALSE]
  lag_cols <- paste0(prefix, "_lag", seq_len(max_lag), "_", exposure)
  lead_cols <- paste0(prefix, "_lead", seq_len(max_lead), "_", exposure)
  for (column in c(lag_cols, lead_cols)) d[[column]] <- NA_real_

  for (idx in split(seq_len(nrow(d)), d[[country_var]])) {
    years <- suppressWarnings(as.integer(d[[year_var]][idx]))
    values <- suppressWarnings(as.numeric(d[[exposure]][idx]))
    for (k in seq_len(max_lag)) {
      matched <- match(years - k, years)
      valid <- !is.na(matched)
      d[[lag_cols[[k]]]][idx] <- ifelse(valid, values[matched], NA_real_)
    }
    for (k in seq_len(max_lead)) {
      matched <- match(years + k, years)
      valid <- !is.na(matched)
      d[[lead_cols[[k]]]][idx] <- ifelse(valid, values[matched], NA_real_)
    }
  }

  attr(d, "paper1_identification_lag_cols") <- lag_cols
  attr(d, "paper1_identification_lead_cols") <- lead_cols
  d
}

paper1_identification_climate_controls <- function(data) {
  candidates <- c(
    "temp_variation", "humidity", "relative_humidity", "mean_humidity",
    "precipitation", "mean_precipitation", "rainfall"
  )
  candidates[candidates %in% names(data)]
}

paper1_add_identification_controls <- function(data,
                                               country_var = "fid",
                                               year_var = "year_id",
                                               sdi_var = "mean_value") {
  d <- data
  controls <- paper1_identification_climate_controls(d)
  if (sdi_var %in% names(d)) {
    d <- paper1_add_identification_shifts(
      d, sdi_var, year_var, country_var,
      max_lag = 1L, max_lead = 0L, prefix = "paper1_id_sdi"
    )
    sdi_lag <- attr(d, "paper1_identification_lag_cols")[[1L]]
    names(d)[names(d) == sdi_lag] <- "paper1_lag1_sdi"
    d$paper1_lag1_sdi_sq <- d$paper1_lag1_sdi ^ 2
    controls <- c(controls, "paper1_lag1_sdi", "paper1_lag1_sdi_sq")
  }
  attr(d, "paper1_identification_controls") <- unique(controls)
  d
}

paper1_prepare_identification_data <- function(data,
                                               exposure,
                                               outcome = "val",
                                               year_var = "year_id",
                                               country_var = "fid",
                                               region_var = NULL) {
  required <- c(outcome, exposure, year_var, country_var)
  missing <- setdiff(required, names(data))
  if (length(missing) > 0L) {
    stop("Identification data is missing: ", paste(missing, collapse = ", "),
         call. = FALSE)
  }
  if (is.null(region_var)) region_var <- paper1_identification_region_var(data)
  d <- data[order(data[[country_var]], data[[year_var]]), , drop = FALSE]
  region <- trimws(as.character(d[[region_var]]))
  region[is.na(region) | !nzchar(region)] <- "Unknown_region"
  year <- suppressWarnings(as.integer(d[[year_var]]))
  if (any(!is.finite(year))) {
    stop("Identification strategy needs numeric country-year observations.",
         call. = FALSE)
  }
  d$paper1_region_year_fe <- interaction(region, year, drop = TRUE)
  d$paper1_country_factor <- factor(d[[country_var]])
  d$paper1_year_c <- year - mean(year, na.rm = TRUE)
  d <- paper1_add_anomalous_exposure(d, exposure, year_var, country_var)
  anomalous_cols <- c(
    attr(d, "paper1_expected_exposure_col"),
    attr(d, "paper1_anomalous_exposure_col"),
    attr(d, "paper1_standardized_anomalous_exposure_col")
  )
  d <- paper1_add_identification_shifts(
    d, exposure, year_var, country_var, max_lag = 2L, max_lead = 2L
  )
  exposure_lags <- attr(d, "paper1_identification_lag_cols")
  exposure_leads <- attr(d, "paper1_identification_lead_cols")
  d <- paper1_add_identification_controls(d, country_var, year_var)
  attr(d, "paper1_identification_lag_cols") <- exposure_lags
  attr(d, "paper1_identification_lead_cols") <- exposure_leads
  attr(d, "paper1_expected_exposure_col") <- anomalous_cols[[1L]]
  attr(d, "paper1_anomalous_exposure_col") <- anomalous_cols[[2L]]
  attr(d, "paper1_standardized_anomalous_exposure_col") <- anomalous_cols[[3L]]
  attr(d, "paper1_region_var") <- region_var
  d
}

paper1_standardize_identification_controls <- function(data, controls) {
  controls <- unique(controls[controls %in% names(data)])
  if (length(controls) == 0L) {
    return(list(data = data, controls = character(), raw_controls = character()))
  }
  standardized <- standardize_paper1_controls(data, controls)
  list(
    data = standardized$data,
    controls = standardized$model_controls,
    raw_controls = controls
  )
}

paper1_identification_complete_cases <- function(data, variables) {
  variables <- unique(variables[variables %in% names(data)])
  data[stats::complete.cases(data[variables]), , drop = FALSE]
}

paper1_anomalous_exposure_names <- function(exposure) {
  list(
    expected = paste0("paper1_expected_", exposure),
    shock = paste0("paper1_anomalous_", exposure),
    zshock = paste0("paper1_z_anomalous_", exposure)
  )
}

paper1_identification_fe <- function(country_var = "fid",
                                    year_var = "year_id",
                                    region_year_var = "paper1_region_year_fe",
                                    country_trend = FALSE) {
  country_part <- if (country_trend) {
    paste0(country_var, "[", year_var, "]")
  } else {
    country_var
  }
  paste(country_part, region_year_var, sep = " + ")
}

paper1_fit_identification_model <- function(data,
                                            outcome,
                                            rhs,
                                            fe = NULL,
                                            country_var = "fid",
                                            year_var = "year_id") {
  formula <- if (is.null(fe) || !nzchar(fe)) {
    stats::as.formula(paste(outcome, "~", rhs))
  } else {
    stats::as.formula(paste(outcome, "~", rhs, "|", fe))
  }
  fixest::feols(
    formula,
    data = data,
    cluster = stats::as.formula(paste0("~", country_var)),
    panel.id = stats::as.formula(paste0("~", country_var, " + ", year_var)),
    notes = FALSE
  )
}

# fixest drops observations (NA fixed effects, singleton region-year cells,
# collinear country trends), so fitted()/resid() are shorter than the input
# data. Map them back through the estimation index instead of assuming 1:1.
paper1_estimation_row_index <- function(model, n_obs) {
  selection <- model$obs_selection
  if (is.list(selection)) selection <- unlist(selection)
  if (is.null(selection) || length(selection) == 0L) {
    return(seq_len(n_obs))
  }
  kept <- if (any(selection < 0L)) {
    seq_len(n_obs)[selection]
  } else {
    as.integer(selection)
  }
  if (length(kept) != length(stats::fitted(model))) {
    stop(
      "Cannot align the fixest estimation sample: index length ",
      length(kept), " differs from fitted length ",
      length(stats::fitted(model)), ".", call. = FALSE
    )
  }
  kept
}

# Align a fixest fit back onto the rows of `data`. fixest drops observations
# (NA fixed effects, singleton region-year cells, collinear country trends), so
# fitted()/resid() are shorter than the estimation input. Rows that fixest
# dropped stay NA.
paper1_assigned_model_values <- function(data, model, value_fn) {
  n <- nrow(data)
  out <- rep(NA_real_, n)
  idx <- paper1_estimation_row_index(model, n)
  values <- value_fn(model)
  if (length(values) != length(idx)) {
    stop(
      "Cannot align a fixest fit onto its input data: ", length(values),
      " values for ", length(idx), " estimation rows.", call. = FALSE
    )
  }
  out[idx] <- values
  out
}

paper1_add_anomalous_exposure <- function(data,
                                          exposure,
                                          year_var = "year_id",
                                          country_var = "fid") {
  required <- c(exposure, year_var, country_var, "paper1_region_year_fe")
  missing <- setdiff(required, names(data))
  if (length(missing) > 0L) {
    stop(
      "Anomalous-exposure construction is missing: ",
      paste(missing, collapse = ", "),
      call. = FALSE
    )
  }

  names <- paper1_anomalous_exposure_names(exposure)
  d <- data
  d$paper1_anomalous_row_id <- seq_len(nrow(d))
  model_data <- paper1_identification_complete_cases(d, required)
  exposure_model <- paper1_fit_identification_model(
    model_data,
    exposure,
    "1",
    paper1_identification_fe(country_var, year_var, country_trend = TRUE),
    country_var,
    year_var
  )

  d[[names$expected]] <- NA_real_
  d[[names$shock]] <- NA_real_
  kept <- paper1_estimation_row_index(exposure_model, nrow(model_data))
  matched <- model_data$paper1_anomalous_row_id[kept]
  fitted_values <- as.numeric(stats::fitted(exposure_model))
  residual_values <- as.numeric(stats::resid(exposure_model))
  if (length(fitted_values) != length(matched)) {
    stop(
      "Anomalous-exposure alignment failed: model returned ",
      length(fitted_values), " fitted values for ", length(matched),
      " estimation rows.", call. = FALSE
    )
  }
  d[[names$expected]][matched] <- fitted_values
  d[[names$shock]][matched] <- residual_values

  d[[names$zshock]] <- NA_real_
  for (idx in split(seq_len(nrow(d)), d[[country_var]])) {
    values <- suppressWarnings(as.numeric(d[[names$shock]][idx]))
    spread <- stats::sd(values, na.rm = TRUE)
    if (is.finite(spread) && spread > 0) {
      d[[names$zshock]][idx] <- values / spread
    }
  }
  d$paper1_anomalous_row_id <- NULL

  attr(d, "paper1_expected_exposure_col") <- names$expected
  attr(d, "paper1_anomalous_exposure_col") <- names$shock
  attr(d, "paper1_standardized_anomalous_exposure_col") <- names$zshock
  attr(d, "paper1_anomalous_exposure_model") <- exposure_model
  d
}

paper1_almon_basis <- function(data, exposure, lag_cols, prefix = "paper1_almon") {
  lag_vars <- c(exposure, lag_cols)
  for (power in 0:2) {
    weights <- (0:2) ^ power
    name <- paste0(prefix, "_", power)
    dmat <- as.matrix(data[lag_vars])
    data[[name]] <- as.numeric(dmat %*% weights)
  }
  attr(data, "paper1_almon_cols") <- paste0(prefix, "_", 0:2)
  data
}

paper1_almon_lag_effects <- function(model,
                                     almon_cols,
                                     lag_count = 3L,
                                     covariance = NULL) {
  coefficients <- stats::coef(model)[almon_cols]
  if (any(!is.finite(coefficients))) {
    stop("The Almon basis coefficients were not estimated.", call. = FALSE)
  }
  if (is.null(covariance)) covariance <- stats::vcov(model)
  covariance <- covariance[almon_cols, almon_cols, drop = FALSE]
  weights <- cbind(1, 0:(lag_count - 1L), (0:(lag_count - 1L)) ^ 2)
  beta <- as.numeric(weights %*% coefficients)
  vcov_lag <- weights %*% covariance %*% t(weights)
  se <- sqrt(pmax(diag(vcov_lag), 0))
  data.frame(
    term_role = c("current", paste0("lag_", seq_len(lag_count - 1L))),
    lag_years = 0:(lag_count - 1L),
    beta = beta,
    se = se,
    ci_low = beta - 1.96 * se,
    ci_high = beta + 1.96 * se,
    p_value = 2 * stats::pnorm(-abs(beta / se)),
    stringsAsFactors = FALSE
  ) |> structure(vcov = vcov_lag)
}

paper1_linear_contrast <- function(beta, covariance, weights) {
  estimate <- sum(weights * beta)
  variance <- as.numeric(t(weights) %*% covariance %*% weights)
  se <- sqrt(max(variance, 0))
  data.frame(
    beta = estimate,
    se = se,
    ci_low = estimate - 1.96 * se,
    ci_high = estimate + 1.96 * se,
    p_value = 2 * stats::pnorm(-abs(estimate / se)),
    stringsAsFactors = FALSE
  )
}

paper1_identification_effect_rows <- function(model_id,
                                              model,
                                              lag_effects,
                                              model_data,
                                              exposure,
                                              outcome,
                                              specification,
                                              inference = "country_cluster") {
  lag_covariance <- attr(lag_effects, "vcov")
  cumulative <- paper1_linear_contrast(
    lag_effects$beta, lag_covariance, rep(1, nrow(lag_effects))
  )
  scale <- paper1_effect_scale(model_data, cumulative$beta, exposure, outcome)
  individual <- transform(
    lag_effects,
    model_id = model_id,
    component = "distributed_lag",
    term = term_role,
    cumulative_window = "0-2 years",
    inference = inference,
    specification = specification,
    n_obs = as.integer(stats::nobs(model)),
    n_country = as.integer(length(unique(model_data$fid))),
    beta_per_100_cdays = 100 * beta,
    beta_per_1sd_within_country = NA_real_,
    stringsAsFactors = FALSE
  )
  individual$term_role <- NULL
  cumulative <- transform(
    cumulative,
    model_id = model_id,
    component = "cumulative_effect",
    term = "cumulative_lag_0_2",
    lag_years = NA_integer_,
    cumulative_window = "0-2 years",
    inference = inference,
    specification = specification,
    n_obs = as.integer(stats::nobs(model)),
    n_country = as.integer(length(unique(model_data$fid))),
    beta_per_100_cdays = 100 * beta,
    beta_per_1sd_within_country = scale$beta_per_1sd_ehi,
    stringsAsFactors = FALSE
  )
  rbind(individual, cumulative)
}

paper1_fit_m4_distributed_lag <- function(data,
                                          exposure,
                                          outcome = "val",
                                          year_var = "year_id",
                                          country_var = "fid") {
  lag_cols <- attr(data, "paper1_identification_lag_cols")
  controls <- attr(data, "paper1_identification_controls")
  required <- c(outcome, exposure, lag_cols, "paper1_region_year_fe")
  d <- paper1_identification_complete_cases(data, required)
  standardized <- paper1_standardize_identification_controls(d, controls)
  d <- standardized$data
  d <- paper1_identification_complete_cases(d, c(required, standardized$controls))
  d <- paper1_almon_basis(d, exposure, lag_cols)
  almon_cols <- attr(d, "paper1_almon_cols")
  rhs <- paste(c(almon_cols, standardized$controls), collapse = " + ")
  fe <- paper1_identification_fe(country_var, year_var, country_trend = TRUE)
  model <- paper1_fit_identification_model(d, outcome, rhs, fe, country_var)
  effects <- paper1_almon_lag_effects(model, almon_cols)
  list(
    model = model,
    data = d,
    almon_cols = almon_cols,
    lag_cols = lag_cols,
    lead_cols = attr(data, "paper1_identification_lead_cols"),
    controls = standardized$controls,
    raw_controls = standardized$raw_controls,
    lag_effects = effects,
    fe = fe,
    specification = "Country FE + region-year FE + country linear trend + 0-2y distributed lag (quadratic Almon parameterization; no additional constraint)"
  )
}

paper1_fit_m5_placebo <- function(primary_fit,
                                  outcome = "val",
                                  country_var = "fid") {
  d <- primary_fit$data
  lead_cols <- primary_fit$lead_cols
  if (is.null(lead_cols) || !all(lead_cols %in% names(d))) {
    stop("The M5 placebo requires one- and two-year future exposures.",
         call. = FALSE)
  }
  d <- paper1_identification_complete_cases(
    d, c("val", primary_fit$almon_cols, lead_cols, primary_fit$controls)
  )
  rhs <- paste(c(primary_fit$almon_cols, lead_cols, primary_fit$controls),
               collapse = " + ")
  model <- paper1_fit_identification_model(
    d, outcome, rhs, primary_fit$fe, country_var
  )
  lag_effects <- paper1_almon_lag_effects(model, primary_fit$almon_cols)
  lead_terms <- stats::coef(model)[lead_cols]
  lead_vcov <- stats::vcov(model)[lead_cols, lead_cols, drop = FALSE]
  lead_se <- sqrt(pmax(diag(lead_vcov), 0))
  lead_rows <- data.frame(
    model_id = "M5_future_exposure_placebo",
    component = "future_exposure_placebo",
    term = c("lead_1", "lead_2"),
    lag_years = c(1L, 2L),
    beta = as.numeric(lead_terms),
    se = lead_se,
    ci_low = as.numeric(lead_terms) - 1.96 * lead_se,
    ci_high = as.numeric(lead_terms) + 1.96 * lead_se,
    p_value = 2 * stats::pnorm(-abs(as.numeric(lead_terms) / lead_se)),
    joint_test_statistic = NA_real_,
    joint_test_df = NA_integer_,
    cumulative_window = NA_character_,
    inference = "country_cluster",
    specification = "M4 plus future CAHE at t+1 and t+2",
    n_obs = as.integer(stats::nobs(model)),
    n_country = as.integer(length(unique(d[[country_var]]))),
    beta_per_100_cdays = 100 * as.numeric(lead_terms),
    beta_per_1sd_within_country = NA_real_,
    stringsAsFactors = FALSE
  )
  wald <- paper1_joint_wald_test(model, lead_cols)
  wald_rows <- data.frame(
    model_id = "M5_future_exposure_placebo",
    component = "joint_future_exposure_test",
    term = "lead_1_and_lead_2",
    lag_years = NA_integer_,
    beta = NA_real_,
    se = NA_real_,
    ci_low = NA_real_,
    ci_high = NA_real_,
    p_value = wald$p_value,
    joint_test_statistic = wald$joint_test_statistic,
    joint_test_df = wald$joint_test_df,
    cumulative_window = NA_character_,
    inference = "country_cluster",
    specification = "Joint null: lead_1 = lead_2 = 0",
    n_obs = as.integer(stats::nobs(model)),
    n_country = as.integer(length(unique(d[[country_var]]))),
    beta_per_100_cdays = NA_real_,
    beta_per_1sd_within_country = NA_real_,
    stringsAsFactors = FALSE
  )
  list(model = model, data = d, lag_effects = lag_effects,
       rows = rbind(lead_rows, wald_rows), lead_cols = lead_cols)
}

paper1_shock_term_row <- function(model,
                                  data,
                                  coefficient,
                                  model_id,
                                  component,
                                  term,
                                  specification,
                                  outcome = "val",
                                  country_var = "fid",
                                  horizon_years = NA_integer_,
                                  cumulative_window = NA_character_) {
  estimate <- paper1_extract_fixest_term(model, coefficient)
  data.frame(
    model_id = model_id,
    component = component,
    term = term,
    horizon_years = horizon_years,
    lag_years = NA_integer_,
    beta = estimate$beta,
    se = estimate$se,
    ci_low = estimate$ci_low,
    ci_high = estimate$ci_high,
    p_value = estimate$p_value,
    cumulative_window = cumulative_window,
    inference = "country_cluster",
    specification = specification,
    n_obs = as.integer(stats::nobs(model)),
    n_country = as.integer(length(unique(data[[country_var]]))),
    beta_per_100_cdays = NA_real_,
    beta_per_1sd_within_country = estimate$beta,
    exposure_scale = "one within-country SD anomalous exposure shock",
    outcome_scale = outcome,
    stringsAsFactors = FALSE
  )
}

paper1_shock_effect_rows <- function(model_id,
                                     model,
                                     lag_effects,
                                     model_data,
                                     exposure,
                                     outcome,
                                     specification,
                                     inference = "country_cluster") {
  rows <- paper1_identification_effect_rows(
    model_id, model, lag_effects, model_data, exposure, outcome,
    specification, inference
  )
  rows$beta_per_100_cdays <- NA_real_
  rows$beta_per_1sd_within_country <- rows$beta
  rows$exposure_scale <- "one within-country SD anomalous exposure shock"
  rows$outcome_scale <- outcome
  rows
}

paper1_anomalous_exposure_diagnostics <- function(data,
                                                  exposure,
                                                  year_var = "year_id",
                                                  country_var = "fid") {
  expected <- attr(data, "paper1_expected_exposure_col")
  shock <- attr(data, "paper1_anomalous_exposure_col")
  zshock <- attr(data, "paper1_standardized_anomalous_exposure_col")
  required <- c(exposure, expected, shock, zshock, country_var, year_var)
  d <- paper1_identification_complete_cases(data, required)
  country_sd <- vapply(
    split(d[[shock]], d[[country_var]]),
    stats::sd,
    numeric(1),
    na.rm = TRUE
  )
  data.frame(
    exposure = exposure,
    expected_exposure = expected,
    anomalous_exposure = shock,
    standardized_anomalous_exposure = zshock,
    n_obs = nrow(d),
    n_country = length(unique(d[[country_var]])),
    year_min = min(d[[year_var]], na.rm = TRUE),
    year_max = max(d[[year_var]], na.rm = TRUE),
    shock_mean = mean(d[[shock]], na.rm = TRUE),
    shock_sd = stats::sd(d[[shock]], na.rm = TRUE),
    country_shock_sd_median = stats::median(country_sd, na.rm = TRUE),
    country_shock_sd_p25 = as.numeric(stats::quantile(
      country_sd, 0.25, na.rm = TRUE, names = FALSE
    )),
    country_shock_sd_p75 = as.numeric(stats::quantile(
      country_sd, 0.75, na.rm = TRUE, names = FALSE
    )),
    specification = "Exposure residual from country FE + region-year FE + country linear trend; then divided by country-specific residual SD",
    stringsAsFactors = FALSE
  )
}

paper1_fit_m11_shock_current <- function(data,
                                         outcome = "val",
                                         year_var = "year_id",
                                         country_var = "fid") {
  shock <- attr(data, "paper1_standardized_anomalous_exposure_col")
  controls <- attr(data, "paper1_identification_controls")
  required <- c(outcome, shock, controls, "paper1_region_year_fe")
  d <- paper1_identification_complete_cases(data, required)
  standardized <- paper1_standardize_identification_controls(d, controls)
  d <- paper1_identification_complete_cases(
    standardized$data, c(outcome, shock, standardized$controls, "paper1_region_year_fe")
  )
  rhs <- paste(c(shock, standardized$controls), collapse = " + ")
  fe <- paper1_identification_fe(country_var, year_var, country_trend = TRUE)
  model <- paper1_fit_identification_model(d, outcome, rhs, fe, country_var)
  row <- paper1_shock_term_row(
    model, d, shock, "M11_anomalous_shock_continuous_did",
    "same_year_anomalous_shock",
    "current_standardized_anomalous_exposure",
    "Association diagnostic using standardized residualized annual exposure",
    outcome, country_var, horizon_years = 0L,
    cumulative_window = "same year"
  )
  list(model = model, data = d, rows = row, shock = shock,
       controls = standardized$controls, fe = fe)
}

paper1_fit_m12_shock_distributed_lag <- function(data,
                                                 outcome = "val",
                                                 year_var = "year_id",
                                                 country_var = "fid") {
  shock <- attr(data, "paper1_standardized_anomalous_exposure_col")
  controls <- attr(data, "paper1_identification_controls")
  shifted <- paper1_add_identification_shifts(
    data, shock, year_var, country_var, max_lag = 2L, max_lead = 2L,
    prefix = "paper1_shock"
  )
  lag_cols <- attr(shifted, "paper1_identification_lag_cols")
  lead_cols <- attr(shifted, "paper1_identification_lead_cols")
  required <- c(outcome, shock, lag_cols, controls, "paper1_region_year_fe")
  d <- paper1_identification_complete_cases(shifted, required)
  standardized <- paper1_standardize_identification_controls(d, controls)
  d <- paper1_identification_complete_cases(
    standardized$data,
    c(outcome, shock, lag_cols, standardized$controls, "paper1_region_year_fe")
  )
  d <- paper1_almon_basis(d, shock, lag_cols, prefix = "paper1_shock_almon")
  almon_cols <- attr(d, "paper1_almon_cols")
  rhs <- paste(c(almon_cols, standardized$controls), collapse = " + ")
  fe <- paper1_identification_fe(country_var, year_var, country_trend = TRUE)
  model <- paper1_fit_identification_model(d, outcome, rhs, fe, country_var)
  effects <- paper1_almon_lag_effects(model, almon_cols)
  rows <- paper1_shock_effect_rows(
    "M12_shock_constrained_distributed_lag", model, effects, d, shock, outcome,
    "Association diagnostic with 0-2y distributed lags of standardized residualized exposure (quadratic Almon parameterization)"
  )
  list(
    model = model,
    data = d,
    rows = rows,
    lag_effects = effects,
    almon_cols = almon_cols,
    lag_cols = lag_cols,
    lead_cols = lead_cols,
    shock = shock,
    controls = standardized$controls,
    fe = fe
  )
}

paper1_fit_m13_shock_placebo <- function(shock_dlag_fit,
                                         outcome = "val",
                                         country_var = "fid") {
  d <- shock_dlag_fit$data
  lead_cols <- shock_dlag_fit$lead_cols
  d <- paper1_identification_complete_cases(
    d, c(outcome, shock_dlag_fit$almon_cols, lead_cols, shock_dlag_fit$controls)
  )
  rhs <- paste(c(shock_dlag_fit$almon_cols, lead_cols, shock_dlag_fit$controls),
               collapse = " + ")
  model <- paper1_fit_identification_model(
    d, outcome, rhs, shock_dlag_fit$fe, country_var
  )
  lag_effects <- paper1_almon_lag_effects(model, shock_dlag_fit$almon_cols)
  lag_rows <- paper1_shock_effect_rows(
    "M13_shock_future_exposure_placebo", model, lag_effects, d,
    shock_dlag_fit$shock, outcome,
    "M12 plus future standardized anomalous shocks at t+1 and t+2"
  )
  lead_rows <- lapply(seq_along(lead_cols), function(k) {
    paper1_shock_term_row(
      model, d, lead_cols[[k]], "M13_shock_future_exposure_placebo",
      "future_anomalous_shock_placebo", paste0("lead_", k),
      "M12 plus future standardized anomalous shocks at t+1 and t+2",
      outcome, country_var, horizon_years = k
    )
  })
  wald <- paper1_joint_wald_test(model, lead_cols)
  joint <- data.frame(
    model_id = "M13_shock_future_exposure_placebo",
    component = "joint_future_anomalous_shock_test",
    term = "lead_1_and_lead_2",
    horizon_years = NA_integer_,
    lag_years = NA_integer_,
    beta = NA_real_,
    se = NA_real_,
    ci_low = NA_real_,
    ci_high = NA_real_,
    p_value = wald$p_value,
    joint_test_statistic = wald$joint_test_statistic,
    joint_test_df = wald$joint_test_df,
    cumulative_window = NA_character_,
    inference = "country_cluster",
    specification = "Joint null: future standardized anomalous shocks at t+1 and t+2 = 0",
    n_obs = as.integer(stats::nobs(model)),
    n_country = as.integer(length(unique(d[[country_var]]))),
    beta_per_100_cdays = NA_real_,
    beta_per_1sd_within_country = NA_real_,
    exposure_scale = "one within-country SD anomalous exposure shock",
    outcome_scale = outcome,
    stringsAsFactors = FALSE
  )
  list(
    model = model,
    data = d,
    rows = paper1_identification_bind_rows(lag_rows, do.call(rbind, lead_rows), joint),
    lead_cols = lead_cols
  )
}

paper1_add_local_projection_outcomes <- function(data,
                                                 outcome = "val",
                                                 horizons = 0:3,
                                                 year_var = "year_id",
                                                 country_var = "fid") {
  d <- data[order(data[[country_var]], data[[year_var]]), , drop = FALSE]
  outcome_cols <- paste0("paper1_lp_h", horizons, "_", outcome)
  for (column in outcome_cols) d[[column]] <- NA_real_
  for (idx in split(seq_len(nrow(d)), d[[country_var]])) {
    years <- suppressWarnings(as.integer(d[[year_var]][idx]))
    values <- suppressWarnings(as.numeric(d[[outcome]][idx]))
    baseline <- match(years - 1L, years)
    for (pos in seq_along(horizons)) {
      h <- horizons[[pos]]
      future <- match(years + h, years)
      valid <- !is.na(baseline) & !is.na(future)
      d[[outcome_cols[[pos]]]][idx] <- ifelse(
        valid,
        values[future] - values[baseline],
        NA_real_
      )
    }
  }
  attr(d, "paper1_local_projection_outcome_cols") <- outcome_cols
  attr(d, "paper1_local_projection_horizons") <- horizons
  d
}

paper1_fit_m14_local_projection <- function(data,
                                            outcome = "val",
                                            year_var = "year_id",
                                            country_var = "fid",
                                            horizons = 0:3) {
  shock <- attr(data, "paper1_standardized_anomalous_exposure_col")
  controls <- attr(data, "paper1_identification_controls")
  d0 <- paper1_add_local_projection_outcomes(
    data, outcome, horizons, year_var, country_var
  )
  outcome_cols <- attr(d0, "paper1_local_projection_outcome_cols")
  rows <- list()
  models <- list()
  for (pos in seq_along(horizons)) {
    h <- horizons[[pos]]
    lp_outcome <- outcome_cols[[pos]]
    required <- c(lp_outcome, shock, controls, "paper1_region_year_fe")
    d <- paper1_identification_complete_cases(d0, required)
    standardized <- paper1_standardize_identification_controls(d, controls)
    d <- paper1_identification_complete_cases(
      standardized$data,
      c(lp_outcome, shock, standardized$controls, "paper1_region_year_fe")
    )
    rhs <- paste(c(shock, standardized$controls), collapse = " + ")
    fe <- paper1_identification_fe(country_var, year_var, country_trend = TRUE)
    model <- paper1_fit_identification_model(
      d, lp_outcome, rhs, fe, country_var, year_var
    )
    models[[paste0("h", h)]] <- model
    rows[[length(rows) + 1L]] <- paper1_shock_term_row(
      model, d, shock, "M14_shock_local_projection",
      "local_projection_cumulative_response",
      paste0("horizon_", h),
      "Local projection: outcome at t+h minus outcome at t-1 on standardized annual shock at t",
      outcome, country_var, horizon_years = h,
      cumulative_window = paste0("t-1 to t+", h)
    )
  }
  list(models = models, data = d0, rows = do.call(rbind, rows), shock = shock)
}

paper1_fit_shock_dynamic_framework <- function(data,
                                               exposure,
                                               outcome = "val",
                                               year_var = "year_id",
                                               country_var = "fid") {
  current <- paper1_fit_m11_shock_current(data, outcome, year_var, country_var)
  distributed <- paper1_fit_m12_shock_distributed_lag(
    data, outcome, year_var, country_var
  )
  placebo <- paper1_fit_m13_shock_placebo(distributed, outcome, country_var)
  local_projection <- paper1_fit_m14_local_projection(
    data, outcome, year_var, country_var
  )
  list(
    rows = paper1_identification_bind_rows(
      current$rows, distributed$rows, placebo$rows, local_projection$rows
    ),
    anomalous_exposure = paper1_anomalous_exposure_diagnostics(
      data, exposure, year_var, country_var
    ),
    current = current,
    distributed = distributed,
    placebo = placebo,
    local_projection = local_projection
  )
}

paper1_country_first_difference <- function(data,
                                            variables,
                                            country_var = "fid",
                                            year_var = "year_id",
                                            gap = 1L) {
  d <- data[order(data[[country_var]], data[[year_var]]), , drop = FALSE]
  for (variable in variables) {
    new_var <- paste0("paper1_d_", variable)
    d[[new_var]] <- NA_real_
    for (idx in split(seq_len(nrow(d)), d[[country_var]])) {
      years <- suppressWarnings(as.integer(d[[year_var]][idx]))
      values <- suppressWarnings(as.numeric(d[[variable]][idx]))
      matched <- match(years - gap, years)
      valid <- !is.na(matched)
      d[[new_var]][idx] <- ifelse(valid, values - values[matched], NA_real_)
    }
  }
  d
}

paper1_fit_m6_first_difference <- function(data,
                                           exposure,
                                           outcome = "val",
                                           year_var = "year_id",
                                           country_var = "fid") {
  lag_cols <- attr(data, "paper1_identification_lag_cols")
  controls <- attr(data, "paper1_identification_controls")
  variables <- unique(c(outcome, exposure, lag_cols, controls))
  d <- paper1_country_first_difference(data, variables, country_var, year_var)
  d$paper1_region_year_fe <- interaction(
    data$paper1_region_year_fe, data[[year_var]], drop = TRUE
  )
  diff_outcome <- paste0("paper1_d_", outcome)
  diff_terms <- paste0("paper1_d_", c(exposure, lag_cols))
  diff_controls <- paste0("paper1_d_", controls)
  d <- paper1_identification_complete_cases(
    d, c(diff_outcome, diff_terms, diff_controls, "paper1_region_year_fe")
  )
  standardized <- paper1_standardize_identification_controls(d, diff_controls)
  d <- standardized$data
  rhs <- paste(c(diff_terms, standardized$controls), collapse = " + ")
  model <- paper1_fit_identification_model(
    d, diff_outcome, rhs,
    fe = paste(country_var, "paper1_region_year_fe", sep = " + "),
    country_var = country_var
  )
  terms <- stats::coef(model)[diff_terms]
  covariance <- stats::vcov(model)[diff_terms, diff_terms, drop = FALSE]
  contrast <- paper1_linear_contrast(terms, covariance, rep(1, length(terms)))
  rows <- data.frame(
    model_id = "M6_first_difference_validation",
    component = "cumulative_first_difference",
    term = "delta_current_lag_1_lag_2",
    lag_years = NA_integer_,
    beta = contrast$beta,
    se = contrast$se,
    ci_low = contrast$ci_low,
    ci_high = contrast$ci_high,
    p_value = contrast$p_value,
    cumulative_window = "0-2 years",
    inference = "country_cluster",
    specification = "First differences with country FE and region-year FE",
    n_obs = as.integer(stats::nobs(model)),
    n_country = as.integer(length(unique(d[[country_var]]))),
    beta_per_100_cdays = 100 * contrast$beta,
    beta_per_1sd_within_country = NA_real_,
    stringsAsFactors = FALSE
  )
  list(model = model, data = d, rows = rows)
}

paper1_make_nonoverlap_blocks <- function(data,
                                          variables,
                                          year_var = "year_id",
                                          country_var = "fid",
                                          region_var = "paper1_region_year_fe",
                                          start_year = 1991L,
                                          block_width = 5L) {
  d <- data
  year <- suppressWarnings(as.integer(d[[year_var]]))
  block_id <- floor((year - start_year) / block_width)
  d$paper1_block_id <- ifelse(year >= start_year, block_id, NA_integer_)
  d$paper1_block_start <- start_year + block_width * d$paper1_block_id
  d <- d[is.finite(d$paper1_block_id), , drop = FALSE]
  d <- d[d[[year_var]] < (d$paper1_block_start + block_width), , drop = FALSE]
  region <- sub("[.]?[0-9]+$", "", as.character(d[[region_var]]))

  groups <- split(seq_len(nrow(d)), interaction(d[[country_var]], d$paper1_block_id,
                                                drop = TRUE))
  rows <- lapply(groups, function(idx) {
    years <- unique(d[[year_var]][idx])
    if (length(years) != block_width) return(NULL)
    out <- d[idx[[1L]], c(country_var, "paper1_block_id", "paper1_block_start"),
             drop = FALSE]
    out$paper1_region_block_fe <- interaction(region[idx[[1L]]],
                                               d$paper1_block_id[idx[[1L]]],
                                               drop = TRUE)
    for (variable in variables) {
      out[[variable]] <- mean(suppressWarnings(as.numeric(d[[variable]][idx])),
                              na.rm = TRUE)
    }
    out
  })
  rows <- Filter(Negate(is.null), rows)
  if (length(rows) == 0L) {
    stop("No complete non-overlapping five-year blocks were available.",
         call. = FALSE)
  }
  do.call(rbind, rows)
}

paper1_prepare_long_difference_data <- function(data,
                                                exposure,
                                                outcome = "val",
                                                year_var = "year_id",
                                                country_var = "fid",
                                                start_year = 1991L,
                                                block_width = 5L) {
  controls <- attr(data, "paper1_identification_controls")
  variables <- unique(c(outcome, exposure, controls))
  blocks <- paper1_make_nonoverlap_blocks(
    data, variables, year_var, country_var, start_year = start_year,
    block_width = block_width
  )
  differenced <- paper1_country_first_difference(
    blocks, variables, country_var, "paper1_block_start", gap = block_width
  )
  block_key <- paste(blocks[[country_var]], blocks$paper1_block_start, sep = "\r")
  difference_key <- paste(
    differenced[[country_var]], differenced$paper1_block_start, sep = "\r"
  )
  differenced$paper1_region_block_fe <- blocks$paper1_region_block_fe[
    match(difference_key, block_key)
  ]
  y <- paste0("paper1_d_", outcome)
  h <- paste0("paper1_d_", exposure)
  z <- paste0("paper1_d_", controls)
  d <- paper1_identification_complete_cases(
    differenced, c(y, h, z, "paper1_region_block_fe")
  )
  standardized <- paper1_standardize_identification_controls(d, z)
  d <- standardized$data
  block_index <- suppressWarnings(as.numeric(d$paper1_block_id))
  d$paper1_block_index_c <- block_index - mean(unique(block_index), na.rm = TRUE)
  d$paper1_block_index_sq <- d$paper1_block_index_c ^ 2
  list(
    data = d,
    outcome_diff = y,
    exposure_diff = h,
    controls = standardized$controls,
    raw_controls = standardized$raw_controls,
    block_width = as.integer(block_width)
  )
}

paper1_long_difference_fe <- function(country_var = "fid",
                                      trend = c("none", "linear", "quadratic")) {
  trend <- match.arg(trend)
  region_fe <- "paper1_region_block_fe"
  if (identical(trend, "none")) return(paste(country_var, region_fe, sep = " + "))
  if (identical(trend, "linear")) {
    return(paste0(country_var, "[paper1_block_index_c] + ", region_fe))
  }
  paste0(
    country_var, "[paper1_block_index_c] + ", country_var,
    "[paper1_block_index_sq] + ", region_fe
  )
}

paper1_fit_long_difference_model <- function(data,
                                             outcome_diff,
                                             exposure_diff,
                                             controls,
                                             country_var = "fid",
                                             trend = c("none", "linear", "quadratic"),
                                             additional_terms = character()) {
  rhs <- paste(c(exposure_diff, additional_terms, controls), collapse = " + ")
  paper1_fit_identification_model(
    data,
    outcome_diff,
    rhs,
    paper1_long_difference_fe(country_var, trend),
    country_var,
    year_var = "paper1_block_start"
  )
}

paper1_long_difference_region <- function(data) {
  sub("[.]?[0-9]+$", "", as.character(data$paper1_region_block_fe))
}

paper1_long_difference_term_row <- function(model,
                                            data,
                                            coefficient,
                                            model_id,
                                            component,
                                            term,
                                            specification,
                                            block_width,
                                            country_var = "fid",
                                            excluded_region = NA_character_) {
  estimate <- paper1_extract_fixest_term(model, coefficient)
  data.frame(
    model_id = model_id,
    component = component,
    term = term,
    lag_years = NA_integer_,
    beta = estimate$beta,
    se = estimate$se,
    ci_low = estimate$ci_low,
    ci_high = estimate$ci_high,
    p_value = estimate$p_value,
    cumulative_window = paste0("adjacent non-overlap ", block_width, "-year blocks"),
    inference = "country_cluster",
    specification = specification,
    n_obs = as.integer(stats::nobs(model)),
    n_country = as.integer(length(unique(data[[country_var]]))),
    block_width = as.integer(block_width),
    excluded_region = excluded_region,
    beta_per_100_cdays = 100 * estimate$beta,
    beta_per_1sd_within_country = NA_real_,
    status = "estimated",
    stringsAsFactors = FALSE
  )
}

paper1_add_long_difference_leads <- function(data,
                                             variable,
                                             country_var = "fid",
                                             year_var = "paper1_block_start",
                                             block_width = 5L,
                                             max_lead = 2L) {
  d <- data[order(data[[country_var]], data[[year_var]]), , drop = FALSE]
  lead_cols <- paste0("paper1_long_lead", seq_len(max_lead), "_", variable)
  for (column in lead_cols) d[[column]] <- NA_real_
  for (idx in split(seq_len(nrow(d)), d[[country_var]])) {
    years <- suppressWarnings(as.integer(d[[year_var]][idx]))
    values <- suppressWarnings(as.numeric(d[[variable]][idx]))
    for (k in seq_len(max_lead)) {
      matched <- match(years + k * block_width, years)
      valid <- !is.na(matched)
      d[[lead_cols[[k]]]][idx] <- ifelse(valid, values[matched], NA_real_)
    }
  }
  list(data = d, lead_cols = lead_cols)
}

paper1_fit_m7_long_difference <- function(data,
                                          exposure,
                                          outcome = "val",
                                          year_var = "year_id",
                                          country_var = "fid") {
  prepared <- paper1_prepare_long_difference_data(
    data, exposure, outcome, year_var, country_var, block_width = 5L
  )
  d <- prepared$data
  h <- prepared$exposure_diff
  fit <- function(trend = "none", model_data = d, additional_terms = character()) {
    paper1_fit_long_difference_model(
      model_data, prepared$outcome_diff, h, prepared$controls, country_var,
      trend = trend, additional_terms = additional_terms
    )
  }
  model <- fit("none")
  trend_model <- tryCatch(fit("linear"), error = function(e) NULL)
  quadratic_trend_model <- tryCatch(fit("quadratic"), error = function(e) NULL)
  rows <- paper1_long_difference_term_row(
    model, d, h, "M7_nonoverlap_five_year_long_difference",
    "five_year_long_difference", "delta_5y_mean_cahe",
    "Non-overlapping five-year long difference with country and region-block FE",
    prepared$block_width, country_var
  )
  if (!is.null(trend_model)) {
    rows <- paper1_identification_bind_rows(rows, paper1_long_difference_term_row(
      trend_model, d, h, "M7_country_trend_sensitivity",
      "five_year_long_difference", "delta_5y_mean_cahe",
      "M7 plus country-specific linear block trend", prepared$block_width, country_var
    ))
  }
  if (!is.null(quadratic_trend_model)) {
    rows <- paper1_identification_bind_rows(rows, paper1_long_difference_term_row(
      quadratic_trend_model, d, h, "M7_country_quadratic_trend_sensitivity",
      "five_year_long_difference", "delta_5y_mean_cahe",
      "M7 plus country-specific quadratic block trend", prepared$block_width, country_var
    ))
  }

  lead_setup <- paper1_add_long_difference_leads(
    d, h, country_var, block_width = prepared$block_width
  )
  placebo_data <- paper1_identification_complete_cases(
    lead_setup$data,
    c(prepared$outcome_diff, h, prepared$controls, lead_setup$lead_cols)
  )
  placebo_model <- tryCatch(
    fit("none", placebo_data, lead_setup$lead_cols), error = function(e) NULL
  )
  placebo_rows <- NULL
  if (!is.null(placebo_model)) {
    placebo_rows <- paper1_long_difference_term_row(
      placebo_model, placebo_data, h, "M7_long_difference_future_exposure_placebo",
      "five_year_long_difference", "delta_5y_mean_cahe",
      "M7 plus future one- and two-block CAHE changes", prepared$block_width,
      country_var
    )
    for (k in seq_along(lead_setup$lead_cols)) {
      placebo_rows <- paper1_identification_bind_rows(
        placebo_rows,
        paper1_long_difference_term_row(
          placebo_model, placebo_data, lead_setup$lead_cols[[k]],
          "M7_long_difference_future_exposure_placebo",
          "future_long_difference_placebo", paste0("lead_block_", k),
          "M7 plus future one- and two-block CAHE changes", prepared$block_width,
          country_var
        )
      )
    }
    wald <- paper1_joint_wald_test(placebo_model, lead_setup$lead_cols)
    placebo_rows <- paper1_identification_bind_rows(placebo_rows, data.frame(
      model_id = "M7_long_difference_future_exposure_placebo",
      component = "joint_future_long_difference_test",
      term = "lead_block_1_and_2",
      lag_years = NA_integer_, beta = NA_real_, se = NA_real_,
      ci_low = NA_real_, ci_high = NA_real_, p_value = wald$p_value,
      joint_test_statistic = wald$joint_test_statistic,
      joint_test_df = wald$joint_test_df,
      cumulative_window = paste0("adjacent non-overlap ", prepared$block_width, "-year blocks"),
      inference = "country_cluster",
      specification = "Joint null: future one- and two-block CAHE changes = 0",
      n_obs = as.integer(stats::nobs(placebo_model)),
      n_country = as.integer(length(unique(placebo_data[[country_var]]))),
      block_width = prepared$block_width,
      excluded_region = NA_character_,
      beta_per_100_cdays = NA_real_, beta_per_1sd_within_country = NA_real_,
      status = "estimated", stringsAsFactors = FALSE
    ))
  }

  leave_region_rows <- NULL
  regions <- sort(unique(paper1_long_difference_region(d)))
  for (excluded in regions) {
    keep <- paper1_long_difference_region(d) != excluded
    if (sum(keep) < 20L || length(unique(d[[country_var]][keep])) < 3L) next
    leave_fit <- tryCatch(fit("none", d[keep, , drop = FALSE]),
                          error = function(e) NULL)
    if (is.null(leave_fit)) next
    leave_region_rows <- paper1_identification_bind_rows(
      leave_region_rows,
      paper1_long_difference_term_row(
        leave_fit, d[keep, , drop = FALSE], h, "M7_leave_one_region_out",
        "five_year_long_difference", "delta_5y_mean_cahe",
        "M7 non-overlapping five-year long difference, leave-one-region-out",
        prepared$block_width, country_var, excluded
      )
    )
  }

  alternative_block_rows <- NULL
  for (width in c(3L, 7L)) {
    alternative <- tryCatch(
      paper1_prepare_long_difference_data(
        data, exposure, outcome, year_var, country_var, block_width = width
      ),
      error = function(e) NULL
    )
    if (is.null(alternative)) next
    alternative_fit <- tryCatch(
      paper1_fit_long_difference_model(
        alternative$data, alternative$outcome_diff, alternative$exposure_diff,
        alternative$controls, country_var, trend = "none"
      ),
      error = function(e) NULL
    )
    alternative_trend_fit <- tryCatch(
      paper1_fit_long_difference_model(
        alternative$data, alternative$outcome_diff, alternative$exposure_diff,
        alternative$controls, country_var, trend = "linear"
      ),
      error = function(e) NULL
    )
    if (!is.null(alternative_fit)) {
      alternative_block_rows <- paper1_identification_bind_rows(
        alternative_block_rows,
        paper1_long_difference_term_row(
          alternative_fit, alternative$data, alternative$exposure_diff,
          "M7_alternative_block_width_sensitivity",
          "alternative_block_length", paste0("delta_", width, "y_mean_cahe"),
          paste0("Non-overlapping ", width, "-year long difference with country and region-block FE"),
          width, country_var
        )
      )
    }
    if (!is.null(alternative_trend_fit)) {
      alternative_block_rows <- paper1_identification_bind_rows(
        alternative_block_rows,
        paper1_long_difference_term_row(
          alternative_trend_fit, alternative$data, alternative$exposure_diff,
          "M7_alternative_block_width_sensitivity",
          "alternative_block_length_country_trend",
          paste0("delta_", width, "y_mean_cahe"),
          paste0("Non-overlapping ", width, "-year long difference plus country linear block trend"),
          width, country_var
        )
      )
    }
  }
  list(
    model = model,
    trend_model = trend_model,
    quadratic_trend_model = quadratic_trend_model,
    data = d,
    rows = rows,
    placebo_rows = placebo_rows,
    leave_region_rows = leave_region_rows,
    alternative_block_rows = alternative_block_rows
  )
}

paper1_add_multiscale_block_components <- function(data,
                                                    exposure,
                                                    year_var = "year_id",
                                                    country_var = "fid",
                                                    start_year = 1991L,
                                                    block_width = 5L) {
  d <- data
  year <- suppressWarnings(as.integer(d[[year_var]]))
  d$paper1_multiscale_block_id <- ifelse(
    year >= start_year, floor((year - start_year) / block_width), NA_integer_
  )
  d$paper1_multiscale_block_start <- start_year +
    block_width * d$paper1_multiscale_block_id
  valid <- is.finite(d$paper1_multiscale_block_id) &
    year < d$paper1_multiscale_block_start + block_width
  block_mean <- paste0("paper1_block_mean_", exposure)
  annual_deviation <- paste0("paper1_annual_deviation_", exposure)
  d[[block_mean]] <- NA_real_
  d[[annual_deviation]] <- NA_real_
  groups <- split(
    which(valid),
    interaction(d[[country_var]][valid], d$paper1_multiscale_block_id[valid], drop = TRUE)
  )
  for (idx in groups) {
    years <- unique(d[[year_var]][idx])
    values <- suppressWarnings(as.numeric(d[[exposure]][idx]))
    if (length(years) != block_width || any(!is.finite(values))) next
    mean_value <- mean(values)
    d[[block_mean]][idx] <- mean_value
    d[[annual_deviation]][idx] <- values - mean_value
  }
  shifted <- paper1_add_identification_shifts(
    d, annual_deviation, year_var, country_var, max_lag = 2L,
    max_lead = 0L, prefix = "paper1_multiscale"
  )
  list(
    data = shifted,
    block_mean = block_mean,
    annual_deviation = annual_deviation,
    deviation_lags = attr(shifted, "paper1_identification_lag_cols"),
    block_width = as.integer(block_width)
  )
}

paper1_fit_m7_multiscale_decomposition <- function(data,
                                                    exposure,
                                                    outcome = "val",
                                                    year_var = "year_id",
                                                    country_var = "fid") {
  controls <- attr(data, "paper1_identification_controls")
  components <- paper1_add_multiscale_block_components(
    data, exposure, year_var, country_var, block_width = 5L
  )
  d <- paper1_identification_complete_cases(
    components$data,
    c(outcome, components$block_mean, components$annual_deviation,
      components$deviation_lags, controls, "paper1_region_year_fe")
  )
  standardized <- paper1_standardize_identification_controls(d, controls)
  d <- paper1_identification_complete_cases(
    standardized$data,
    c(outcome, components$block_mean, components$annual_deviation,
      components$deviation_lags, standardized$controls, "paper1_region_year_fe")
  )
  d <- paper1_almon_basis(
    d, components$annual_deviation, components$deviation_lags,
    prefix = "paper1_multiscale_almon"
  )
  almon_cols <- attr(d, "paper1_almon_cols")
  rhs <- paste(c(components$block_mean, almon_cols, standardized$controls),
               collapse = " + ")
  fe <- paper1_identification_fe(country_var, year_var, country_trend = TRUE)
  model <- paper1_fit_identification_model(d, outcome, rhs, fe, country_var)
  annual_effects <- paper1_almon_lag_effects(model, almon_cols)
  annual_rows <- paper1_identification_effect_rows(
    "M7_multiscale_block_mean_annual_deviation", model, annual_effects, d,
    components$annual_deviation, outcome,
    "Annual CAHE deviations and five-year country block mean CAHE in the same model"
  )
  annual_rows$component <- ifelse(
    annual_rows$component == "cumulative_effect",
    "annual_deviation_cumulative_lag", "annual_deviation_distributed_lag"
  )
  annual_rows$term <- sub("^cumulative_lag", "annual_deviation_cumulative_lag", annual_rows$term)
  annual_rows$term <- ifelse(
    grepl("^lag_|^current$", annual_rows$term),
    paste0("annual_deviation_", annual_rows$term), annual_rows$term
  )
  annual_rows$block_width <- components$block_width
  block_effect <- paper1_extract_fixest_term(model, components$block_mean)
  block_row <- data.frame(
    model_id = "M7_multiscale_block_mean_annual_deviation",
    component = "block_mean_long_term_association",
    term = "five_year_block_mean_cahe",
    lag_years = NA_integer_,
    beta = block_effect$beta,
    se = block_effect$se,
    ci_low = block_effect$ci_low,
    ci_high = block_effect$ci_high,
    p_value = block_effect$p_value,
    cumulative_window = "five-year non-overlap block mean",
    inference = "country_cluster",
    specification = "Annual CAHE deviations and five-year country block mean CAHE in the same model",
    n_obs = as.integer(stats::nobs(model)),
    n_country = as.integer(length(unique(d[[country_var]]))),
    beta_per_100_cdays = 100 * block_effect$beta,
    beta_per_1sd_within_country = NA_real_,
    block_width = components$block_width,
    stringsAsFactors = FALSE
  )
  list(
    model = model,
    data = d,
    rows = paper1_identification_bind_rows(annual_rows, block_row),
    block_mean = components$block_mean,
    annual_deviation = components$annual_deviation
  )
}

paper1_fit_m8_residual_spline <- function(data,
                                          exposure,
                                          outcome = "val",
                                          year_var = "year_id",
                                          country_var = "fid") {
  controls <- attr(data, "paper1_identification_controls")
  required <- c(outcome, exposure, controls, "paper1_region_year_fe")
  d <- paper1_identification_complete_cases(data, required)
  residual_model <- paper1_fit_identification_model(
    d, exposure, "1",
    paper1_identification_fe(country_var, year_var, country_trend = TRUE),
    country_var
  )
  d$paper1_residual_cahe <- paper1_assigned_model_values(
    d, residual_model, function(m) as.numeric(stats::resid(m))
  )
  knots <- as.numeric(stats::quantile(
    d$paper1_residual_cahe, probs = c(0.1, 0.5, 0.9), na.rm = TRUE, names = FALSE
  ))
  if (length(unique(knots)) < 3L) {
    stop("Residualized CAHE has insufficient support for the prespecified spline.",
         call. = FALSE)
  }
  basis <- splines::ns(d$paper1_residual_cahe, knots = knots,
                       Boundary.knots = range(d$paper1_residual_cahe, na.rm = TRUE))
  spline_cols <- paste0("paper1_residual_cahe_spline", seq_len(ncol(basis)))
  d[spline_cols] <- as.data.frame(basis)
  standardized <- paper1_standardize_identification_controls(d, controls)
  d <- standardized$data
  rhs <- paste(c(spline_cols, standardized$controls), collapse = " + ")
  fe <- paper1_identification_fe(country_var, year_var, country_trend = TRUE)
  model <- paper1_fit_identification_model(d, outcome, rhs, fe, country_var)
  wald <- paper1_joint_wald_test(model, spline_cols)
  row <- data.frame(
    model_id = "M8_residual_cahe_spline",
    component = "overall_nonlinearity_test",
    term = "residual_cahe_restricted_cubic_spline",
    lag_years = NA_integer_,
    beta = NA_real_,
    se = NA_real_,
    ci_low = NA_real_,
    ci_high = NA_real_,
    p_value = wald$p_value,
    joint_test_statistic = wald$joint_test_statistic,
    joint_test_df = wald$joint_test_df,
    cumulative_window = NA_character_,
    inference = "country_cluster",
    specification = "Residualized CAHE, knots at 10th/50th/90th percentiles",
    n_obs = as.integer(stats::nobs(model)),
    n_country = as.integer(length(unique(d[[country_var]]))),
    beta_per_100_cdays = NA_real_,
    beta_per_1sd_within_country = NA_real_,
    stringsAsFactors = FALSE
  )
  list(model = model, residual_model = residual_model, data = d,
       knots = knots, rows = row)
}

paper1_m10_robustness <- function(primary_fit,
                                  outcome = "val",
                                  exposure = "ehi1",
                                  country_var = "fid") {
  m4 <- primary_fit$model
  dk_error <- NA_character_
  effects_dk <- tryCatch(
    paper1_almon_lag_effects(
      m4, primary_fit$almon_cols, covariance = stats::vcov(m4, vcov = "DK")
    ),
    error = function(e) {
      dk_error <<- conditionMessage(e)
      NULL
    }
  )
  rows <- list()
  if (!is.null(effects_dk)) {
    contrast <- paper1_linear_contrast(
      effects_dk$beta, attr(effects_dk, "vcov"), rep(1, nrow(effects_dk))
    )
    rows[[length(rows) + 1L]] <- data.frame(
      model_id = "M10_Driscoll_Kraay",
      component = "cumulative_effect",
      term = "cumulative_lag_0_2",
      beta = contrast$beta,
      se = contrast$se,
      ci_low = contrast$ci_low,
      ci_high = contrast$ci_high,
      p_value = contrast$p_value,
      inference = "Driscoll-Kraay",
      specification = primary_fit$specification,
      status = "estimated",
      stringsAsFactors = FALSE
    )
  } else {
    rows[[length(rows) + 1L]] <- data.frame(
      model_id = "M10_Driscoll_Kraay",
      component = "cumulative_effect",
      term = "cumulative_lag_0_2",
      beta = NA_real_, se = NA_real_, ci_low = NA_real_, ci_high = NA_real_,
      p_value = NA_real_, inference = "Driscoll-Kraay",
      specification = primary_fit$specification,
      status = paste0("not_run_", dk_error),
      stringsAsFactors = FALSE
    )
  }

  d <- primary_fit$data
  region <- sub("[.]?[0-9]+$", "", as.character(d$paper1_region_year_fe))
  for (excluded in sort(unique(region))) {
    keep <- region != excluded
    if (sum(keep) < 20L || length(unique(d[[country_var]][keep])) < 3L) next
    fit <- tryCatch(
      paper1_fit_m4_distributed_lag(d[keep, , drop = FALSE], exposure, outcome,
                                    country_var = country_var),
      error = function(e) NULL
    )
    if (is.null(fit)) next
    contrast <- paper1_linear_contrast(
      fit$lag_effects$beta, attr(fit$lag_effects, "vcov"),
      rep(1, nrow(fit$lag_effects))
    )
    rows[[length(rows) + 1L]] <- data.frame(
      model_id = "M10_leave_one_region_out",
      component = "cumulative_effect",
      term = "cumulative_lag_0_2",
      beta = contrast$beta,
      se = contrast$se,
      ci_low = contrast$ci_low,
      ci_high = contrast$ci_high,
      p_value = contrast$p_value,
      inference = "country_cluster",
      specification = primary_fit$specification,
      excluded_region = excluded,
      status = "estimated",
      stringsAsFactors = FALSE
    )
  }
  rows[[length(rows) + 1L]] <- data.frame(
    model_id = "M10_Conley_HAC",
    component = "inference_availability",
    term = "country_centroid_coordinates",
    beta = NA_real_, se = NA_real_, ci_low = NA_real_, ci_high = NA_real_,
    p_value = NA_real_, inference = "Conley spatial HAC",
    specification = "Requires prespecified country centroids and a distance cutoff",
    status = "not_run_requires_coordinates",
    stringsAsFactors = FALSE
  )
  rows[[length(rows) + 1L]] <- data.frame(
    model_id = "M10_wild_cluster_bootstrap",
    component = "inference_availability",
    term = "country_cluster",
    beta = NA_real_, se = NA_real_, ci_low = NA_real_, ci_high = NA_real_,
    p_value = NA_real_, inference = "wild cluster bootstrap",
    specification = "To be run after choosing the bootstrap package and repetitions prospectively",
    status = "not_run_requires_bootstrap_configuration",
    stringsAsFactors = FALSE
  )
  all_columns <- unique(unlist(lapply(rows, names), use.names = FALSE))
  rows <- lapply(rows, function(x) {
    missing <- setdiff(all_columns, names(x))
    for (column in missing) x[[column]] <- NA
    x[all_columns]
  })
  do.call(rbind, rows)
}

paper1_identification_m0_m3 <- function(data,
                                         exposure,
                                         outcome = "val",
                                         year_var = "year_id",
                                         country_var = "fid") {
  controls <- attr(data, "paper1_identification_controls")
  d <- paper1_identification_complete_cases(
    data, c(outcome, exposure, controls, "paper1_region_year_fe")
  )
  standardized <- paper1_standardize_identification_controls(d, controls)
  d <- standardized$data
  models <- list(
    M0_ols_descriptive = list(rhs = exposure, fe = NULL,
                              label = "OLS descriptive association"),
    M1_country_year_fe = list(rhs = exposure,
                              fe = paste(country_var, year_var, sep = " + "),
                              label = "Country and global year fixed effects"),
    M2_country_region_year_fe = list(rhs = exposure,
                                     fe = paper1_identification_fe(country_var, year_var),
                                     label = "Country and region-year fixed effects"),
    M3_country_region_year_country_trend = list(
      rhs = paste(c(exposure, standardized$controls), collapse = " + "),
      fe = paper1_identification_fe(country_var, year_var, country_trend = TRUE),
      label = "Country and region-year fixed effects with country linear trends"
    )
  )
  rows <- lapply(names(models), function(id) {
    spec <- models[[id]]
    model <- paper1_fit_identification_model(d, outcome, spec$rhs, spec$fe,
                                              country_var)
    term <- paper1_extract_fixest_term(model, exposure)
    data.frame(
      model_id = id,
      component = "contemporaneous_association",
      term = "current_cahe",
      beta = term$beta,
      se = term$se,
      ci_low = term$ci_low,
      ci_high = term$ci_high,
      p_value = term$p_value,
      specification = spec$label,
      inference = "country_cluster",
      n_obs = as.integer(stats::nobs(model)),
      n_country = as.integer(length(unique(d[[country_var]]))),
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

paper1_fit_identification_framework <- function(data,
                                                 exposure,
                                                 outcome = "val",
                                                 year_var = "year_id",
                                                 country_var = "fid",
                                                 region_var = NULL) {
  d <- paper1_prepare_identification_data(
    data, exposure, outcome, year_var, country_var, region_var
  )
  m0_m3 <- paper1_identification_m0_m3(d, exposure, outcome, year_var,
                                        country_var)
  primary <- paper1_fit_m4_distributed_lag(d, exposure, outcome, year_var,
                                           country_var)
  shock_dynamic <- paper1_fit_shock_dynamic_framework(
    d, exposure, outcome, year_var, country_var
  )
  m4 <- paper1_identification_effect_rows(
    "M4_constrained_dlag_region_year_country_trend", primary$model,
    primary$lag_effects, primary$data, exposure, outcome, primary$specification
  )
  m5 <- paper1_fit_m5_placebo(primary, outcome, country_var)
  m5_lags <- paper1_identification_effect_rows(
    "M5_future_exposure_placebo", m5$model, m5$lag_effects, m5$data,
    exposure, outcome, "M4 plus future CAHE at t+1 and t+2"
  )
  m6 <- paper1_fit_m6_first_difference(d, exposure, outcome, year_var,
                                        country_var)
  m7 <- paper1_fit_m7_long_difference(d, exposure, outcome, year_var,
                                       country_var)
  multiscale <- paper1_fit_m7_multiscale_decomposition(
    d, exposure, outcome, year_var, country_var
  )
  m8 <- paper1_fit_m8_residual_spline(d, exposure, outcome, year_var,
                                      country_var)
  m9 <- data.frame(
    model_id = "M9_alternative_heat_definition",
    component = "exposure_definition",
    term = exposure,
    beta = NA_real_, se = NA_real_, ci_low = NA_real_, ci_high = NA_real_,
    p_value = NA_real_,
    specification = paper1_exposure_definition(exposure),
    inference = "not_applicable",
    status = if (identical(exposure, paper1_ehi_main())) "primary_definition" else "sensitivity_definition",
    stringsAsFactors = FALSE
  )
  m10 <- paper1_m10_robustness(primary, outcome, exposure, country_var)
  list(
    model_ladder = paper1_identification_bind_rows(m0_m3, m4),
    temporal_placebo = paper1_identification_bind_rows(m5_lags, m5$rows),
    first_difference = m6$rows,
    long_difference = m7$rows,
    long_term_decomposition = multiscale$rows,
    long_term_placebo = m7$placebo_rows,
    long_term_robustness = paper1_identification_bind_rows(
      m7$leave_region_rows, m7$alternative_block_rows
    ),
    nonlinearity = m8$rows,
    exposure_definition = m9,
    robustness = m10,
    residualized_exposure = m8$data[, c(country_var, year_var, "paper1_residual_cahe"), drop = FALSE],
    anomalous_exposure = shock_dynamic$anomalous_exposure,
    shock_dynamics = shock_dynamic$rows,
    primary = primary,
    long_term = m7,
    multiscale = multiscale,
    shock_dynamic = shock_dynamic
  )
}

paper1_long_difference_is_stable <- function(long_difference_rows) {
  rows <- long_difference_rows[
    long_difference_rows$model_id %in% c(
      "M7_nonoverlap_five_year_long_difference",
      "M7_country_trend_sensitivity",
      "M7_country_quadratic_trend_sensitivity"
    ), , drop = FALSE
  ]
  required <- c(
    "M7_nonoverlap_five_year_long_difference",
    "M7_country_trend_sensitivity",
    "M7_country_quadratic_trend_sensitivity"
  )
  if (!setequal(rows$model_id, required) || any(!is.finite(rows$beta))) return(FALSE)
  all(sign(rows$beta) == sign(rows$beta[[1L]])) && all(rows$p_value < 0.05)
}

paper1_primary_cumulative_beta <- function(primary_fit) {
  contrast <- paper1_linear_contrast(
    primary_fit$lag_effects$beta,
    attr(primary_fit$lag_effects, "vcov"),
    rep(1, nrow(primary_fit$lag_effects))
  )
  transform(
    contrast,
    beta_model_id = "M4_constrained_dlag_region_year_country_trend",
    beta_source = "annual_distributed_lag_association",
    effect_window = "0-2 years",
    stringsAsFactors = FALSE
  )
}

# Match the established `fit_paper1_*` naming convention used by the runner.
fit_paper1_identification_framework <- paper1_fit_identification_framework
