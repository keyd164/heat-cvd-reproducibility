paper1_outcomes_main <- function() {
  c("Death", "DALYs", "Incidence")
}

paper1_outcomes_all <- function() {
  c("Death", "DALYs", "Incidence", "Prevalence", "CBD", "Leukemia")
}

paper1_ehi_main <- function() {
  "ehi1"
}

paper1_ehi_sensitivity <- function() {
  c("ehi3", "ehi13", "ehi14")
}

paper1_ehi_all <- function() {
  c(paper1_ehi_main(), paper1_ehi_sensitivity())
}

paper1_exposure_definition <- function(exposure) {
  definitions <- c(
    ehi1 = "CAHE: area-weighted mean of grid-cell cumulative Tmax exceedances above 30 C in events lasting at least 2 days; degree C-days",
    ehi13 = "CRHE: calendar-day local Tmax P90 exceedances in events lasting at least 2 days",
    ehi3 = "Percentile-only cumulative heat-exposure sensitivity",
    ehi14 = "Mixed heat: Tmax above max(30 C, calendar-day local P90), events lasting at least 2 days"
  )
  if (exposure %in% names(definitions)) {
    unname(definitions[[exposure]])
  } else {
    paste("Prespecified heat-exposure sensitivity:", exposure)
  }
}

paper1_identification_model_ids <- function() {
  c(
    "M0_ols_descriptive",
    "M1_country_year_fe",
    "M2_country_region_year_fe",
    "M3_country_region_year_country_trend",
    "M4_constrained_dlag_region_year_country_trend",
    "M5_future_exposure_placebo",
    "M6_first_difference_validation",
    "M7_nonoverlap_five_year_long_difference",
    "M7_country_trend_sensitivity",
    "M7_country_quadratic_trend_sensitivity",
    "M7_multiscale_block_mean_annual_deviation",
    "M7_long_difference_future_exposure_placebo",
    "M7_leave_one_region_out",
    "M7_alternative_block_width_sensitivity",
    "M8_residual_cahe_spline",
    "M9_alternative_heat_definition",
    "M10_inference_and_leave_region_out",
    "M11_anomalous_shock_continuous_did",
    "M12_shock_constrained_distributed_lag",
    "M13_shock_future_exposure_placebo",
    "M14_shock_local_projection",
    "M15_baseline_sdi_continuous_interaction",
    "M16_baseline_sdi_tertile_interaction",
    "M17_sdi_tertile_linear_trend",
    "M18_region_linear_trend"
  )
}

paper1_main_model_id <- function() {
  "fully_adjusted_two_way_fe"
}

# NOTE: deliberately NOT "core_total_association". On the age-standardized
# long panel the climate context columns (temp_variation, humidity,
# precipitation) do not exist, so core_total_association collapses to SDI
# alone. fully_adjusted_all still supplies SDI plus the five metabolic and
# dietary SEV covariates on that panel and is the base draft's primary
# adjustment set, so it is kept.
paper1_main_covariate_set <- function() {
  "fully_adjusted_all"
}

paper1_baseline_model_id <- function() {
  "country_fe"
}

paper1_trend_diagnostic_model_id <- function() {
  "trend_country_linear"
}

# beta_source values this paper may emit. The shared runtime's
# paper_contract()/validate_beta_routing() only knows the legacy
# "global_country_fixed_effect" value, so the paper keeps its own list and
# warns on anything outside it instead of silently routing a stray beta.
paper1_known_beta_sources <- function() {
  c(
    "global_country_fixed_effect",
    "annual_anomalous_cahe_association",
    "annual_distributed_lag_association",
    "long_term_ecological_co_movement",
    "stratum_specific_fixed_effect_hc1",
    "full_sample_group_interaction_fixed_effect",
    "not_for_main_beta",
    "not_applicable"
  )
}

paper1_primary_sample_type <- function() {
  "own_sample"
}

paper1_primary_beta_source <- function() {
  "global_country_fixed_effect"
}

paper1_model_roles <- function() {
  trend_ids <- paper1_trend_adjustment_model_registry()$model_id
  fully_adjusted_trend_ids <- paper1_fully_adjusted_trend_model_ids()
  core <- data.frame(
    model_id = c(
      "ols_unadjusted",
      "country_fe",
      trend_ids,
      "fully_adjusted_two_way_fe",
      fully_adjusted_trend_ids
    ),
    analysis_stage = c(
      "level1_basic_association",
      "level1_basic_association",
      rep("level2_temporal_trend_adjustment", length(trend_ids)),
      "level3_covariate_adjustment",
      rep("level2_temporal_trend_adjustment", length(fully_adjusted_trend_ids))
    ),
    analysis_role = c(
      "descriptive_global_association",
      "baseline_country_fe_association",
      paste0(trend_ids, "_association"),
      "primary_observational_association",
      paste0(fully_adjusted_trend_ids, "_sensitivity")
    ),
    is_primary_result = c(
      FALSE,
      FALSE,
      rep(FALSE, length(trend_ids)),
      TRUE,
      rep(FALSE, length(fully_adjusted_trend_ids))
    ),
    is_diagnostic = c(
      FALSE,
      FALSE,
      rep(TRUE, length(trend_ids)),
      FALSE,
      rep(TRUE, length(fully_adjusted_trend_ids))
    ),
    is_placebo = FALSE,
    is_exploratory = FALSE,
    interpretation_level = c(
      "descriptive",
      "baseline_association",
      rep("trend_sensitivity", length(trend_ids)),
      "primary_observational_association",
      rep("trend_sensitivity", length(fully_adjusted_trend_ids))
    ),
    stringsAsFactors = FALSE
  )

  lag_ids <- paper1_lag_lead_model_ids()
  lag_roles <- data.frame(
    model_id = lag_ids,
    analysis_stage = "level4_temporal_specificity",
    analysis_role = "temporal_lag_specificity_diagnostic",
    is_primary_result = FALSE,
    is_diagnostic = TRUE,
    is_placebo = FALSE,
    is_exploratory = FALSE,
    interpretation_level = "temporal_lag_specificity_diagnostic",
    stringsAsFactors = FALSE
  )

  decomposition_ids <- paper1_decomposition_model_ids()
  is_placebo <- rep(FALSE, length(decomposition_ids))
  is_trend <- grepl(
    "country_trend|_trend_(global|year|sdi|country|region|climate)",
    decomposition_ids
  )
  is_main <- decomposition_ids %in% c(
    "model_C_long_short",
    "model_C_long_short_trend_year_fe"
  )
  decomposition_roles <- data.frame(
    model_id = decomposition_ids,
    analysis_stage = "level5_exposure_structure",
    analysis_role = ifelse(
      is_placebo,
      "exposure_structure_placebo_diagnostic",
      ifelse(
        is_main,
        "main_long_short_exposure_structure",
        ifelse(
          is_trend,
          "exposure_structure_trend_sensitivity",
          "supporting_exposure_structure"
        )
      )
    ),
    is_primary_result = FALSE,
    is_diagnostic = TRUE,
    is_placebo = is_placebo,
    is_exploratory = FALSE,
    interpretation_level = ifelse(
      is_placebo,
      "placebo_diagnostic",
      ifelse(is_trend, "trend_sensitivity", "exposure_structure_diagnostic")
    ),
    stringsAsFactors = FALSE
  )

  identification_roles <- data.frame(
    model_id = c(
      "M0_ols_descriptive",
      "M1_country_year_fe",
      "M2_country_region_year_fe",
      "M3_country_region_year_country_trend",
      "M4_constrained_dlag_region_year_country_trend",
      "M5_future_exposure_placebo",
      "M6_first_difference_validation",
      "M7_nonoverlap_five_year_long_difference",
      "M7_country_trend_sensitivity",
      "M7_country_quadratic_trend_sensitivity",
      "M7_multiscale_block_mean_annual_deviation",
      "M7_long_difference_future_exposure_placebo",
      "M7_leave_one_region_out",
      "M7_alternative_block_width_sensitivity",
      "M8_residual_cahe_spline",
      "M9_alternative_heat_definition",
      "M10_inference_and_leave_region_out",
      "M11_anomalous_shock_continuous_did",
      "M12_shock_constrained_distributed_lag",
      "M13_shock_future_exposure_placebo",
      "M14_shock_local_projection"
    ),
    analysis_stage = c(
      rep("identification_ladder", 5L),
      "temporal_direction_validation",
      "annual_change_validation",
      "long_term_co_movement",
      "long_term_co_movement",
      "long_term_co_movement",
      "long_term_scale_decomposition",
      "long_term_temporal_direction_validation",
      "long_term_robustness",
      "long_term_robustness",
      "nonlinearity_validation",
      "exposure_definition_sensitivity",
      "inference_robustness",
      "anomalous_exposure_diagnostic",
      "anomalous_exposure_diagnostic",
      "dynamic_shock_temporal_direction_validation",
      "dynamic_shock_response"
    ),
    analysis_role = c(
      "descriptive_reference", "baseline_panel_association",
      "region_year_shock_control", "country_trend_control",
      "distributed_lag_sensitivity_association",
      "future_exposure_placebo", "first_difference_cross_validation",
      "five_year_long_difference_association",
      "five_year_long_difference_linear_trend_sensitivity",
      "five_year_long_difference_quadratic_trend_sensitivity",
      "block_mean_and_annual_deviation_decomposition",
      "five_year_future_exposure_placebo",
      "five_year_leave_one_region_out",
      "alternative_block_width_sensitivity",
      "residualized_exposure_response",
      "alternative_exposure_definition", "robust_inference",
      "anomalous_exposure_association",
      "anomalous_exposure_distributed_lag_association",
      "future_anomalous_shock_placebo",
      "local_projection_dynamic_response"
    ),
    is_primary_result = rep(FALSE, 21L),
    is_diagnostic = c(rep(FALSE, 4L), rep(TRUE, 17L)),
    is_placebo = c(
      rep(FALSE, 5L), TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, TRUE,
      FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, TRUE, FALSE
    ),
    is_exploratory = c(rep(FALSE, 14L), TRUE, TRUE, TRUE, FALSE, FALSE, FALSE, FALSE),
    interpretation_level = c(
      "descriptive", "baseline_association", "conditional_association",
      "conditional_association", "distributed_lag_sensitivity_association",
      "temporal_direction_diagnostic", "annual_change_association",
      "long_term_ecological_co_movement",
      "long_term_ecological_co_movement",
      "long_term_ecological_co_movement",
      "scale_decomposition_association",
      "long_term_temporal_direction_diagnostic",
      "long_term_robustness_diagnostic",
      "long_term_robustness_diagnostic",
      "nonlinear_association",
      "exposure_definition_sensitivity", "inference_sensitivity",
      "anomalous_exposure_diagnostic",
      "anomalous_exposure_lag_diagnostic",
      "temporal_direction_diagnostic",
      "dynamic_response_diagnostic"
    ),
    stringsAsFactors = FALSE
  )

  heterogeneity_roles <- data.frame(
    model_id = c(
      "M15_baseline_sdi_continuous_interaction",
      "M16_baseline_sdi_tertile_interaction"
    ),
    analysis_stage = "level6_effect_modification",
    analysis_role = c(
      "continuous_baseline_sdi_effect_modification",
      "baseline_sdi_tertile_effect_modification"
    ),
    is_primary_result = FALSE,
    is_diagnostic = TRUE,
    is_placebo = FALSE,
    is_exploratory = TRUE,
    interpretation_level = "effect_modification_association",
    stringsAsFactors = FALSE
  )

  ladder_roles <- data.frame(
    model_id = c(
      "M17_sdi_tertile_linear_trend",
      "M18_region_linear_trend"
    ),
    analysis_stage = rep("level2_temporal_trend_adjustment", 2L),
    analysis_role = c(
      "sdi_tertile_linear_trend_association",
      "region_linear_trend_association"
    ),
    is_primary_result = c(FALSE, FALSE),
    is_diagnostic = c(TRUE, TRUE),
    is_placebo = c(FALSE, FALSE),
    is_exploratory = c(FALSE, FALSE),
    interpretation_level = c("trend_sensitivity", "trend_sensitivity"),
    stringsAsFactors = FALSE
  )

  roles <- rbind(
    core, lag_roles, decomposition_roles,
    identification_roles, heterogeneity_roles, ladder_roles
  )
  rownames(roles) <- NULL
  roles
}

paper1_covariate_sets <- function() {
  list(
    unadjusted = character(),

    diet = c(
      "SEV_agestd_diet_fruit",
      "SEV_agestd_diet_veg"
    ),

    sdi = c(
      "mean_value"
    ),

    climate = c(
      "temp_variation",
      "baseline_high"
    ),

    sdi_temperature_context = c(
      "mean_value",
      "temp_variation",
      "baseline_high"
    ),

    core_total_association = c(
      "mean_value",
      "temp_variation",
      "humidity",
      "precipitation"
    ),

    air_pollution = c(
      "SEV_agestd_air_hap",
      "SEV_agestd_air_pm"
    ),

    metabolic = c(
      "SEV_agestd_metab_bmi",
      "SEV_agestd_metab_fpg",
      "SEV_agestd_metab_sbp",
      "mean_LDL"
    ),

    nonclimate_risk_all = c(
      "SEV_agestd_air_hap",
      "SEV_agestd_air_pm",
      "SEV_agestd_diet_fruit",
      "SEV_agestd_diet_veg",
      "SEV_agestd_metab_bmi",
      "SEV_agestd_metab_fpg",
      "SEV_agestd_metab_sbp",
      "mean_LDL"
    ),

    fully_adjusted_all = c(
      "SEV_agestd_diet_fruit",
      "SEV_agestd_diet_veg",
      "SEV_agestd_metab_bmi",
      "SEV_agestd_metab_fpg",
      "SEV_agestd_metab_sbp",
      "mean_value",
      "temp_variation",
      "baseline_high"
    )
  )
}

paper1_covariate_roles <- function() {
  data.frame(
    covariate_set = c(
      "unadjusted",
      "diet",
      "sdi",
      "climate",
      "sdi_temperature_context",
      "core_total_association",
      "fully_adjusted_all",
      "air_pollution",
      "metabolic",
      "nonclimate_risk_all"
    ),
    covariate_role = c(
      "reference",
      "final_adjustment_component",
      "development_context_adjustment",
      "climate_context_adjustment",
      "development_and_climate_context_adjustment",
      "core_total_association_adjustment",
      "primary_final_adjustment",
      "potential_mediator_adjustment",
      "mixed_pathway_sensitivity",
      "overadjustment_or_pathway_sensitivity"
    ),
    manuscript_role = c(
      "baseline",
      "main_adjustment_component",
      "main_adjustment_component",
      "main_adjustment_component",
      "main_adjustment_component",
      "identification_model_component",
      "primary_model",
      "supplementary_pathway_sensitivity",
      "supplementary_pathway_sensitivity",
      "supplementary_pathway_sensitivity"
    ),
    stringsAsFactors = FALSE
  )
}

paper1_main_beta_filter <- function() {
  list(
    outcome_measure = paper1_outcomes_main(),
    ehi_var = paper1_ehi_main(),
    model_id = paper1_main_model_id(),
    sample_type = paper1_primary_sample_type()
  )
}

paper1_association_model_registry <- function(outcome = "val",
                                              exposure = "ehi1",
                                              year_var = "year_id",
                                              country_var = "fid") {
  data.frame(
    model_id = c(
      "ols_unadjusted",
      "country_fe"
    ),
    formula = c(
      paste0(outcome, " ~ ", exposure),
      paste0(outcome, " ~ ", exposure, " | ", country_var)
    ),
    null_formula = c(
      paste0(outcome, " ~ 1"),
      paste0(outcome, " ~ 1 | ", country_var)
    ),
    analysis_stage = "level1_basic_association",
    stringsAsFactors = FALSE
  )
}

paper1_trend_adjustment_model_registry <- function(outcome = "val",
                                                   exposure = "ehi1",
                                                   year_var = "year_id",
                                                   country_var = "fid") {
  paper1_build_trend_adjustment_registry(
    outcome = outcome,
    exposure_terms = exposure,
    null_terms = character(),
    year_var = year_var,
    country_var = country_var
  )
}

paper1_trend_ladder_specs <- function(country_var = "fid",
                                      year_var = "year_id") {
  global_spline <- paste0(
    "paper1_year_spline1 + ",
    "paper1_year_spline2 + ",
    "paper1_year_spline3"
  )
  country_spline <- paste0(
    "paper1_country_factor:paper1_year_spline1 + ",
    "paper1_country_factor:paper1_year_spline2 + ",
    "paper1_country_factor:paper1_year_spline3"
  )
  list(
    trend_global_spline3 = list(
      label = "Country FE + global year spline (df=3)",
      rhs_extra = global_spline,
      fe_part = country_var,
      required_vars = c(
        "paper1_year_spline1",
        "paper1_year_spline2",
        "paper1_year_spline3"
      ),
      trend_level = "global",
      trend_control = "global_spline3"
    ),
    trend_year_fe = list(
      label = "Country + year FE",
      rhs_extra = character(),
      fe_part = paste(country_var, year_var, sep = " + "),
      required_vars = character(),
      trend_level = "none",
      trend_control = "country_year_fe"
    ),
    trend_sdi_tertile_linear = list(
      label = "Country + year FE + SDI-tertile linear trend",
      rhs_extra = "paper1_sdi_tertile_factor:paper1_year_c",
      fe_part = paste(country_var, year_var, sep = " + "),
      required_vars = c("paper1_sdi_tertile_factor", "paper1_year_c"),
      trend_level = "sdi_tertile",
      trend_control = "sdi_tertile_linear"
    ),
    trend_region_linear = list(
      label = "Country + year FE + region linear trend",
      rhs_extra = "paper1_region_factor:paper1_year_c",
      fe_part = paste(country_var, year_var, sep = " + "),
      required_vars = c("paper1_region_factor", "paper1_year_c"),
      trend_level = "region",
      trend_control = "region_linear"
    ),
    trend_country_linear = list(
      label = "Country + year FE + country-specific linear trend",
      rhs_extra = "paper1_country_factor:paper1_year_c",
      fe_part = paste(country_var, year_var, sep = " + "),
      required_vars = c("paper1_country_factor", "paper1_year_c"),
      trend_level = "country",
      trend_control = "country_specific_linear"
    ),
    trend_country_spline3 = list(
      label = "Country + year FE + country-specific spline trend (df=3)",
      rhs_extra = country_spline,
      fe_part = paste(country_var, year_var, sep = " + "),
      required_vars = c(
        "paper1_country_factor",
        "paper1_year_spline1",
        "paper1_year_spline2",
        "paper1_year_spline3"
      ),
      trend_level = "country",
      trend_control = "country_specific_spline3"
    )
  )
}

paper1_long_exposure_trend_specs <- function(country_var = "fid",
                                             year_var = "year_id") {
  paper1_trend_ladder_specs(country_var, year_var)
}

paper1_compose_model_rhs <- function(terms) {
  terms <- terms[!is.na(terms) & nzchar(terms)]
  if (length(terms) == 0L) {
    return("1")
  }
  paste(terms, collapse = " + ")
}

paper1_build_trend_adjustment_registry <- function(outcome = "val",
                                                   exposure_terms = "ehi1",
                                                   null_terms = character(),
                                                   year_var = "year_id",
                                                   country_var = "fid",
                                                   model_prefix = "") {
  specs <- paper1_trend_ladder_specs(country_var, year_var)
  rows <- lapply(names(specs), function(model_id) {
    spec <- specs[[model_id]]
    data.frame(
      model_id = paste0(model_prefix, model_id),
      formula = paste0(
        outcome,
        " ~ ",
        paper1_compose_model_rhs(c(exposure_terms, spec$rhs_extra)),
        " | ",
        spec$fe_part
      ),
      null_formula = paste0(
        outcome,
        " ~ ",
        paper1_compose_model_rhs(c(null_terms, spec$rhs_extra)),
        " | ",
        spec$fe_part
      ),
      analysis_stage = "level2_temporal_trend_adjustment",
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

paper1_fully_adjusted_trend_model_ids <- function() {
  paste0("fully_adjusted_", names(paper1_trend_ladder_specs()))
}

paper1_mediation_mediators <- function() {
  list(
    air_pollution = c(
      "SEV_agestd_air_hap",
      "SEV_agestd_air_pm"
    ),
    metabolic = c(
      "SEV_agestd_metab_bmi",
      "SEV_agestd_metab_fpg",
      "SEV_agestd_metab_sbp",
      "mean_LDL"
    )
  )
}

get_paper1_covariate_sets <- function() {
  paper1_covariate_sets()
}

paper1_output_sections <- function() {
  data.frame(
    section_id = sprintf("%02d_%s", 1:14, c(
      "association",
      "model_consistency",
      "covariate_adjustment",
      "grouped_fixed_effects",
      "historical_attribution",
      "future_projection",
      "manuscript_assets",
      "mediation",
      "temporal_specificity",
      "ehi_structure_analysis",
      "pop_weighted_sensitivity",
      "exploratory_population_scaled_ehi1",
      "identification_strategy",
      "effect_modification"
    )),
    section_order = 1:14,
    section_name = c(
      "Basic Association",
      "Model Consistency",
      "Covariate Adjustment",
      "Grouped Fixed Effects",
      "Historical Attribution",
      "Future Projection",
      "Manuscript Assets",
      "Mediation",
      "Temporal Specificity",
      "CHE Structure Analysis",
      "Population Weighted Sensitivity",
      "Exploratory Population-Scaled CHE",
      "Identification Strategy",
      "Socioeconomic Effect Modification"
    ),
    analysis_family = c(
      "fixed_effect_association",
      "fixed_effect_association",
      "fixed_effect_association",
      "fixed_effect_association",
      "fixed_effect_attribution",
      "fixed_effect_projection",
      "manuscript_asset",
      "fixed_effect_mediation",
      "fixed_effect_temporal_specificity",
      "fixed_effect_exposure_structure",
      "fixed_effect_association",
      "exploratory_population_scaled_ehi1",
      "fixed_effect_identification_strategy",
      "fixed_effect_heterogeneity"
    ),
    stringsAsFactors = FALSE
  )
}

paper1_lag_lead_model_ids <- function() {
  c(
    "same_year_fe_clinyear",
    "same_year_twoway_fe",
    "same_year_country_trend",
    "ehi_lag1_3_distributed_clinyear",
    "ehi_lag1_3_distributed_twoway_fe",
    "ehi_lag1_3_distributed_country_trend"
  )
}

paper1_decomposition_model_ids <- function() {
  legacy <- c(
    "model_A_long5",
    "model_A_long10",
    "model_B_short_only",
    "model_C_long_short",
    "model_A_long5_country_trend",
    "model_C_long_short_country_trend"
  )
  ladder <- as.vector(outer(
    c(
      "model_A_long5",
      "model_C_long_short"
    ),
    names(paper1_long_exposure_trend_specs()),
    paste,
    sep = "_"
  ))
  unique(c(legacy, ladder))
}

paper1_all_model_ids <- function() {
  c(
    paper1_association_model_registry()$model_id,
    paper1_trend_adjustment_model_registry()$model_id,
    paper1_lag_lead_model_ids(),
    paper1_decomposition_model_ids(),
    paper1_identification_model_ids(),
    "fully_adjusted_two_way_fe",
    paper1_fully_adjusted_trend_model_ids()
  )
}
