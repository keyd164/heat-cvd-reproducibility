paper1_numeric_matrix <- function(data, variables) {
  variables <- unique(variables[variables %in% names(data)])
  if (length(variables) == 0) {
    return(data.frame())
  }

  out <- as.data.frame(lapply(variables, function(variable) {
    suppressWarnings(as.numeric(data[[variable]]))
  }))
  names(out) <- variables
  keep <- vapply(out, function(x) {
    finite <- is.finite(x)
    any(finite) && is.finite(stats::sd(x[finite], na.rm = TRUE)) &&
      stats::sd(x[finite], na.rm = TRUE) > 0
  }, logical(1))
  out[, keep, drop = FALSE]
}

standardize_paper1_controls <- function(data, controls) {
  controls <- unique(controls[controls %in% names(data)])
  out <- data
  if (length(controls) == 0) {
    return(list(
      data = out,
      model_controls = character(),
      metadata = data.frame(
        raw_covariate = character(),
        model_covariate = character(),
        center = numeric(),
        scale = numeric(),
        stringsAsFactors = FALSE
      )
    ))
  }

  metadata <- lapply(seq_along(controls), function(i) {
    raw <- controls[[i]]
    model <- sprintf("paper1_covariate_z_%03d", i)
    x <- suppressWarnings(as.numeric(out[[raw]]))
    center <- mean(x, na.rm = TRUE)
    scale <- stats::sd(x, na.rm = TRUE)

    if (!is.finite(center)) {
      center <- NA_real_
    }
    if (!is.finite(scale) || scale == 0) {
      out[[model]] <<- 0
      scale <- NA_real_
    } else {
      out[[model]] <<- (x - center) / scale
    }

    data.frame(
      raw_covariate = raw,
      model_covariate = model,
      center = center,
      scale = scale,
      stringsAsFactors = FALSE
    )
  })

  metadata <- do.call(rbind, metadata)
  list(
    data = out,
    model_controls = metadata$model_covariate,
    metadata = metadata
  )
}

format_paper1_standardization_values <- function(metadata, column) {
  if (nrow(metadata) == 0) {
    return("")
  }
  paste(
    sprintf(
      "%s=%s",
      metadata$raw_covariate,
      format(metadata[[column]], digits = 8, scientific = TRUE)
    ),
    collapse = "; "
  )
}

max_abs_control_correlation <- function(data, controls) {
  x <- paper1_numeric_matrix(data, controls)
  if (ncol(x) < 2) {
    return(NA_real_)
  }

  correlation <- suppressWarnings(stats::cor(x, use = "pairwise.complete.obs"))
  if (length(correlation) == 0) {
    return(NA_real_)
  }
  diag(correlation) <- NA_real_
  values <- abs(correlation[upper.tri(correlation)])
  values <- values[is.finite(values)]
  if (length(values) == 0) {
    return(NA_real_)
  }
  max(values)
}

max_control_vif <- function(data, controls) {
  x <- paper1_numeric_matrix(data, controls)
  if (ncol(x) < 2) {
    return(NA_real_)
  }
  complete <- stats::complete.cases(x)
  x <- x[complete, , drop = FALSE]
  if (nrow(x) <= ncol(x)) {
    return(NA_real_)
  }

  quote_name <- function(name) paste0("`", gsub("`", "``", name), "`")
  vifs <- vapply(names(x), function(target) {
    others <- setdiff(names(x), target)
    formula <- stats::as.formula(paste(
      quote_name(target),
      "~",
      paste(vapply(others, quote_name, character(1)), collapse = " + ")
    ))
    fit <- tryCatch(
      stats::lm(formula, data = x),
      error = function(e) NULL
    )
    if (is.null(fit)) {
      return(NA_real_)
    }
    r_squared <- suppressWarnings(summary(fit)$r.squared)
    if (!is.finite(r_squared)) {
      return(NA_real_)
    }
    if (r_squared >= 1 - sqrt(.Machine$double.eps)) {
      return(Inf)
    }
    1 / (1 - r_squared)
  }, numeric(1))

  if (any(is.infinite(vifs))) {
    return(Inf)
  }
  vifs <- vifs[is.finite(vifs)]
  if (length(vifs) == 0) {
    return(NA_real_)
  }
  max(vifs)
}

build_collinearity_diagnostics <- function(model,
                                           data,
                                           controls,
                                           raw_controls = controls,
                                           vif_threshold = 10,
                                           correlation_threshold = 0.95) {
  collinear_terms <- model[["collin.var"]]
  if (is.null(collinear_terms)) {
    collinear_terms <- character()
  }
  dropped_covariates <- raw_controls[controls %in% collinear_terms]
  max_correlation <- max_abs_control_correlation(data, controls)
  max_vif <- max_control_vif(data, controls)
  has_high_vif <- is.infinite(max_vif) ||
    (is.finite(max_vif) && max_vif >= vif_threshold)
  has_high_correlation <- is.finite(max_correlation) &&
    max_correlation >= correlation_threshold

  data.frame(
    collinearity_flag = length(collinear_terms) > 0 ||
      has_high_vif || has_high_correlation,
    collinear_terms = paste(collinear_terms, collapse = "; "),
    dropped_covariates = paste(dropped_covariates, collapse = "; "),
    max_vif = max_vif,
    max_abs_control_correlation = max_correlation,
    stringsAsFactors = FALSE
  )
}

fit_one_adjusted_fe <- function(data,
                                exposure,
                                 controls,
                                 outcome = "val",
                                 year_var = "year_id",
                                 country_var = "fid",
                                 weight_var = NULL) {
  standardized <- standardize_paper1_controls(data, controls)
  model_data <- standardized$data
  model_controls <- standardized$model_controls
  metadata <- standardized$metadata
  rhs <- paste(c(exposure, model_controls), collapse = " + ")
  formula <- stats::as.formula(
    paste0(outcome, " ~ ", rhs, " | ", country_var, " + ", year_var)
  )
  weight_formula <- if (!is.null(weight_var) && weight_var %in% names(model_data)) {
    stats::as.formula(paste0("~", weight_var))
  } else {
    NULL
  }
  model <- fixest::feols(
    formula,
    data = model_data,
    cluster = stats::as.formula(paste0("~", country_var)),
    weights = weight_formula,
    notes = FALSE
  )
  term <- extract_fixest_term(model, exposure)
  effect_scale <- build_paper1_effect_scale(
    model_data,
    term$beta,
    exposure,
    outcome
  )
  null_formula_str <- if (length(model_controls) > 0) {
    paste0(outcome, " ~ ",
           paste(model_controls, collapse = " + "), " | ", country_var, " + ", year_var)
  } else {
    paste0(outcome, " ~ 1 | ", country_var, " + ", year_var)
  }
  r2_info <- extract_paper1_r2(
    model = model,
    null_data = model_data,
    null_formula_str = null_formula_str,
    country_var = country_var
  )
  cbind(
    term,
    effect_scale,
    r2_info,
    n_obs = as.integer(stats::nobs(model)),
    n_country = as.integer(length(unique(model_data[[country_var]]))),
    build_collinearity_diagnostics(
      model,
      model_data,
      model_controls,
      raw_controls = metadata$raw_covariate
    ),
    covariate_standardization = if (length(model_controls) == 0) {
      "none"
    } else {
      "z_score_mean_sd_within_sample"
    },
    model_covariates = paste(model_controls, collapse = "; "),
    control_centers = format_paper1_standardization_values(metadata, "center"),
    control_scales = format_paper1_standardization_values(metadata, "scale")
  )
}

fit_paper1_covariate_sets <- function(data,
                                      exposure,
                                      outcome = "val",
                                      year_var = "year_id",
                                      country_var = "fid",
                                      weight_var = NULL) {
  basic <- c(outcome, exposure, year_var, country_var)
  missing_basic <- setdiff(basic, names(data))
  if (length(missing_basic) > 0) {
    stop("Covariate model data is missing: ",
         paste(missing_basic, collapse = ", "), call. = FALSE)
  }

  requested <- get_paper1_covariate_sets()
  covariate_roles <- paper1_covariate_roles()
  available <- lapply(requested, function(x) x[x %in% names(data)])
  common_controls <- unique(unlist(available, use.names = FALSE))
  common_vars <- unique(c(basic, common_controls))
  if (!is.null(weight_var) && weight_var %in% names(data)) {
    common_vars <- unique(c(common_vars, weight_var))
  }
  common_rows <- stats::complete.cases(data[common_vars])
  rows <- list()

  for (set_name in names(requested)) {
    controls <- available[[set_name]]
    own_vars <- unique(c(basic, controls))
    if (!is.null(weight_var) && weight_var %in% names(data)) {
      own_vars <- unique(c(own_vars, weight_var))
    }
    samples <- list(
      own_sample = data[
        stats::complete.cases(data[own_vars]),
        ,
        drop = FALSE
      ],
      common_sample = data[common_rows, , drop = FALSE]
    )

    for (sample_name in names(samples)) {
      d <- samples[[sample_name]]
      adjusted <- fit_one_adjusted_fe(
        d, exposure, controls, outcome, year_var, country_var, weight_var
      )
      reference <- fit_one_adjusted_fe(
        d, exposure, character(), outcome, year_var, country_var, weight_var
      )
      beta_change <- adjusted$beta - reference$beta

      role_row <- covariate_roles[covariate_roles$covariate_set == set_name, , drop = FALSE]
      covariate_role <- if (nrow(role_row) > 0) role_row$covariate_role else "reference"
      manuscript_role <- if (nrow(role_row) > 0) role_row$manuscript_role else "baseline"

      # The unweighted extended country/year FE on its own sample is primary.
      is_primary <- identical(set_name, paper1_main_covariate_set()) &&
        identical(sample_name, paper1_primary_sample_type()) && is.null(weight_var)
      is_exploratory <- set_name %in% c("air_pollution", "metabolic", "nonclimate_risk_all")
      model_id <- if (identical(set_name, paper1_main_covariate_set())) {
        paper1_main_model_id()
      } else {
        paste0("covariate_two_way_fe_", set_name)
      }

      rows[[length(rows) + 1]] <- data.frame(
        model_id = model_id,
        covariate_set = set_name,
        sample_type = sample_name,
        requested_covariates = paste(requested[[set_name]], collapse = "; "),
        used_covariates = paste(controls, collapse = "; "),
        missing_covariates = paste(
          setdiff(requested[[set_name]], controls),
          collapse = "; "
        ),
        weight_var = if (!is.null(weight_var)) weight_var else NA_character_,
        beta = adjusted$beta,
        se = adjusted$se,
        ci_low = adjusted$ci_low,
        ci_high = adjusted$ci_high,
        p_value = adjusted$p_value,
        ehi_sd = adjusted$ehi_sd,
        outcome_sd = adjusted$outcome_sd,
        beta_per_1sd_ehi = adjusted$beta_per_1sd_ehi,
        standardized_beta = adjusted$standardized_beta,
        beta_unadjusted_matched = reference$beta,
        beta_change = beta_change,
        percent_beta_change = if (reference$beta == 0) {
          NA_real_
        } else {
          100 * beta_change / abs(reference$beta)
        },
        same_direction = sign(adjusted$beta) == sign(reference$beta),
        n_obs = adjusted$n_obs,
        n_country = adjusted$n_country,
        collinearity_flag = adjusted$collinearity_flag,
        collinear_terms = adjusted$collinear_terms,
        dropped_covariates = adjusted$dropped_covariates,
        max_vif = adjusted$max_vif,
        max_abs_control_correlation = adjusted$max_abs_control_correlation,
        covariate_standardization = adjusted$covariate_standardization,
        model_covariates = adjusted$model_covariates,
        control_centers = adjusted$control_centers,
        control_scales = adjusted$control_scales,
        r_squared = adjusted$r_squared,
        adj_r_squared = adjusted$adj_r_squared,
        within_r_squared = adjusted$within_r_squared,
        adj_within_r_squared = adjusted$adj_within_r_squared,
        partial_r_squared_ehi = adjusted$partial_r_squared_ehi,
        analysis_stage = "level2_covariate_adjustment",
        analysis_role = covariate_role,
        manuscript_role = manuscript_role,
        is_primary_result = is_primary,
        is_diagnostic = FALSE,
        is_placebo = FALSE,
        is_exploratory = is_exploratory,
        interpretation_level = if (is_primary) "primary_observational_association" else "association",
        stringsAsFactors = FALSE
      )
    }
  }
  tibble::as_tibble(do.call(rbind, rows))
}
