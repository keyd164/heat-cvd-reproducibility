# Scoped refit: SDI exposure inequality and historical ACH--DALYs contrasts.
# Usage: Rscript run_SDI_historical_ACH_20261015.R EXTERNAL_OUTPUT [DRAWS]
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args)>=1)
out <- normalizePath(args[1],winslash='/',mustWork=FALSE)
B <- if(length(args)>1) as.integer(args[2]) else 2000L
stopifnot(B>=2000L)
dir.create(out,recursive=TRUE,showWarnings=FALSE)
if(file.exists(file.path(out,'refit_completed.json'))) stop('Use a new output directory')
paper1_new_panel_path <- function() 'data/input/historical_panel.csv.gz'
sources <- c('00_registry.R','02_data_contracts.R','02_data_adapter.R',
 '03_model_helpers.R','fixed_effect_covariate_adjustment.R',
 'fixed_effect_identification.R','fixed_effect_panel_sensitivity.R')
for(n in sources) source(file.path('code/R',n),encoding='UTF-8')
fixest::setFixest_nthreads(1)
raw <- read.csv(gzfile(paper1_new_panel_path()),check.names=FALSE)
controls <- paper1_sensitivity_controls()
d <- prepare_paper1_panel(raw,'DALYs')
d <- paper1_sensitivity_complete(d,c('val','ehi1',controls,'fid','year_id'))
stopifnot(nrow(d)==6293,length(unique(d$fid))==203,
 !anyDuplicated(d[c('fid','year_id')]),identical(sort(unique(d$year_id)),1990:2020))
nat_path <- 'data/input/natural_forcing_panel.csv.gz'
old_path <- 'data/input'
nat <- read.csv(gzfile(nat_path)); nat$ACH <- nat$ACH_natural_calibrated
idx <- match(paste(d$fid,d$year_id),paste(nat$fid,nat$year))
stopifnot(!anyNA(idx),!anyDuplicated(nat[c('fid','year')]),
 max(abs(d$ehi1-nat$ACH_observed[idx]))<1e-5)
d$ACH_natural <- nat$ACH[idx]
groups <- c('Low','Middle','High')
base <- aggregate(mean_value~fid,d[d$year_id %in% 1990:1994,],mean)
names(base)[2] <- 'baseline_SDI'
cuts <- as.numeric(quantile(base$baseline_SDI,c(0,1/3,2/3,1),type=7))
base$group <- as.character(cut(base$baseline_SDI,cuts,groups,include.lowest=TRUE))
old_groups <- read.csv(file.path(old_path,'country_SDI_groups.csv'))
stopifnot(all(base$group==old_groups$group[match(base$fid,old_groups$fid)]))
d$group <- base$group[match(d$fid,base$fid)]
early <- aggregate(ehi1~fid,d[d$year_id %in% 1990:1994,],mean)
d$ACH_own_1990_1994 <- early$ehi1[match(d$fid,early$fid)]
for(g in groups) d[[paste0('heat_',g)]] <- d$ehi1*(d$group==g)
base$location_name <- d$location_name[match(base$fid,d$fid)]
write.csv(base,file.path(out,'country_SDI_groups.csv'),row.names=FALSE)
write.csv(d[c('fid','year_id','location_name','val','ehi1',controls,
 'group','ACH_natural','ACH_own_1990_1994')],file.path(out,'estimation_panel.csv'),row.names=FALSE)
specs <- c('primary_TWFE')
fit <- function(z,s,grouped=FALSE,cluster=TRUE) {
 rhs <- c(if(grouped) paste0('heat_',groups) else 'ehi1',controls)
 fe <- if(s=='primary_TWFE') 'fid + year_id' else 'fid[year_id] + year_id'
 if(cluster) return(paper1_sensitivity_fit(z,rhs,fe))
 fixest::feols(as.formula(paste('val ~',paste(rhs,collapse='+'),'|',fe)),z,notes=FALSE)
}
coefs <- list(); covs <- list(); tests <- list()
for(s in specs) for(grouped in c(FALSE,TRUE)) {
 m <- fit(d,s,grouped)
 terms <- if(grouped) paste0('heat_',groups) else 'ehi1'
 for(term in terms) coefs[[length(coefs)+1L]] <- cbind(specification=s,
  slope_model=if(grouped) 'SDI_interaction' else 'pooled',term=term,
  paper1_sensitivity_contrast(m,d,term))
 for(t1 in terms) for(t2 in terms) covs[[length(covs)+1L]] <- data.frame(
  specification=s,slope_model=if(grouped) 'SDI_interaction' else 'pooled',
  term1=t1,term2=t2,covariance=vcov(m)[t1,t2])
 if(grouped) {
  D <- rbind(c(-1,1,0),c(-1,0,1)); b <- coef(m)[terms]; V <- vcov(m)[terms,terms]
  db <- D%*%b; Fval <- as.numeric(t(db)%*%solve(D%*%V%*%t(D),db))/2
  tests[[length(tests)+1L]] <- data.frame(specification=s,contrast='all_slopes_equal',
   estimate=NA,se=NA,ci_low=NA,ci_high=NA,statistic=Fval,df_num=2,df_den=202,
   p_value=pf(Fval,2,202,lower.tail=FALSE))
  for(pair in list(c('Middle','Low'),c('High','Low'),c('High','Middle'))) {
   z <- paper1_sensitivity_contrast(m,d,paste0('heat_',pair),c(1,-1))
   tests[[length(tests)+1L]] <- data.frame(specification=s,contrast=paste(pair,collapse='_minus_'),
    estimate=z$beta,se=z$se,ci_low=z$ci_low,ci_high=z$ci_high,
    statistic=z$beta/z$se,df_num=1,df_den=202,p_value=z$p_value)
  }
 }
}
write.csv(do.call(rbind,coefs),file.path(out,'coefficients.csv'),row.names=FALSE)
write.csv(do.call(rbind,covs),file.path(out,'coefficient_covariances.csv'),row.names=FALSE)
write.csv(do.call(rbind,tests),file.path(out,'SDI_slope_tests.csv'),row.names=FALSE)
ids <- sort(unique(d$fid)); N <- length(ids)
blocks <- lapply(ids,function(i) d[d$fid==i,])
set.seed(20261015)
draws <- matrix(sample(seq_len(N),B*N,replace=TRUE),nrow=B)
write.csv(draws,file.path(out,'bootstrap_country_indices.csv'),row.names=FALSE)
make_draw <- function(b) do.call(rbind,lapply(seq_len(N),function(k) {
 z <- blocks[[draws[b,k]]];z$fid <- k;z
}))
results <- vector('list',B)
for(b in seq_len(B)) {
 z <- make_draw(b); stopifnot(all(groups %in% z$group))
 results[[b]] <- do.call(rbind,lapply(specs,function(s) {
  pooled <- coef(fit(z,s,FALSE,FALSE))['ehi1']
  bg <- coef(fit(z,s,TRUE,FALSE))[paste0('heat_',groups)]
  stopifnot(all(is.finite(c(pooled,bg))))
  data.frame(draw=b,specification=s,pooled=unname(pooled),
   Low=unname(bg[1]),Middle=unname(bg[2]),High=unname(bg[3]))
 }))
 if(b%%250==0) {cat('ACH historical/SDI bootstrap',b,'/',B,'\n');flush.console()}
}
boot <- do.call(rbind,results)
write.csv(boot,file.path(out,'bootstrap_coefficients.csv'),row.names=FALSE)
verification <- do.call(rbind,lapply(c(1L,as.integer(B/2),B),function(b) {
 z <- make_draw(b)
 do.call(rbind,lapply(specs,function(s) {
  recomputed <- c(coef(fit(z,s))['ehi1'],coef(fit(z,s,TRUE))[paste0('heat_',groups)])
  saved <- as.numeric(boot[boot$draw==b & boot$specification==s,c('pooled',groups)])
  data.frame(draw=b,specification=s,term=c('pooled',groups),saved_beta=saved,
   recomputed_beta=unname(recomputed),absolute_difference=abs(saved-recomputed))
 }))
}))
stopifnot(max(verification$absolute_difference)<1e-10)
write.csv(verification,file.path(out,'bootstrap_draw_verification.csv'),row.names=FALSE)
jsonlite::write_json(list(completed=TRUE,seed=20261015,draws=B,successful=B,failed=0,
 rows=nrow(d),countries=N,years=c(1990,2020),controls=controls,
 input=paper1_new_panel_path(),input_md5=unname(tools::md5sum(paper1_new_panel_path())),
 natural_input=nat_path,old_SDI_directory=old_path,cuts=cuts,reference_ACH=0,
 own_baseline='Country-specific 1990-1994 mean ACH; supplementary historical change estimand',
 bootstrap='Country blocks, fixed historical groups/references, refit pooled and group slopes in both specifications',
 R=R.version.string,fixest=as.character(packageVersion('fixest')),
 sources_md5=as.list(tools::md5sum(c('code/run_SDI_historical_ACH_20261015.R',file.path('code/R',sources))))),
 file.path(out,'refit_completed.json'),auto_unbox=TRUE,pretty=TRUE,digits=16)
print(do.call(rbind,coefs));cat('Scoped ACH historical/SDI refit complete\n')
