# Run from the repository root: Rscript code/fit_models.R [output-directory]
# Reproduces the reported regressions; it does not execute proposed B1 extensions.
suppressPackageStartupMessages(library(fixest))
setFixest_nthreads(1)
args <- commandArgs(trailingOnly=TRUE)
out <- if(length(args)) args[1] else 'results/models'
edition <- if(length(args)>1) args[2] else 'GBD2023'
legacy <- identical(edition,'GBD2021')
dir.create(out,recursive=TRUE,showWarnings=FALSE)
raw <- read.csv(gzfile('data/input/historical_panel.csv.gz'),check.names=FALSE)
stopifnot(all(raw$cause_id==491),all(raw$age_id==27),all(raw$sex_id==3),all(raw$metric_id==3))
controls <- c('mean_value','SEV_agestd_diet_fruit','SEV_agestd_diet_veg','SEV_agestd_metab_bmi','SEV_agestd_metab_fpg','SEV_agestd_metab_sbp')
prepare <- function(measure) {
 d <- raw[raw$measure_id==measure & !is.na(raw$fid),]
 names(d)[match(c('year','absolute_cumulative_heat','relative_cumulative_heat','mixed_cumulative_heat','SDI','GBDregion'),names(d))] <- c('year_id','ehi1','ehi13','ehi14','mean_value','world_region')
 patch <- d$fid==95 & (is.na(d$world_region)|!nzchar(trimws(d$world_region)))
 d$world_region[patch] <- 'Western Sub-Saharan Africa'
 d <- d[order(d$fid,d$year_id),]
 needed <- c('val','ehi1',controls,'fid','year_id')
 d <- d[complete.cases(d[needed]),]
 stopifnot(nrow(d)==6293,length(unique(d$fid))==203,!anyDuplicated(d[c('fid','year_id')]))
 d
}
fit <- function(form,d) feols(form,d,cluster=~fid,notes=FALSE,ssc=ssc(t.df='min',G.df='min'))
extract <- function(m,d,label,term='ehi1') {
 used <- d[obs(m),];df <- length(unique(used$fid))-1;b <- unname(coef(m)[term]);s <- sqrt(vcov(m)[term,term])
 data.frame(model=label,term=term,beta=b,se=s,ci_low=b-qt(.975,df)*s,ci_high=b+qt(.975,df)*s,p_value=2*pt(-abs(b/s),df),within_r2=if(is.null(m$fixef_vars)) NA_real_ else unname(r2(m,'wr2')),overall_r2=unname(r2(m,'r2')),n_obs=nobs(m),n_countries=df+1,inference_df=df)
}
d <- prepare(2);rhs <- paste(c('ehi1',controls),collapse=' + ')
forms <- list(OLS=val~ehi1,GBD_region_year_FE=as.formula(paste('val ~',rhs,'| world_region^year_id')),country_year_FE=as.formula(paste('val ~',rhs,'| fid + year_id')),country_linear_trends=as.formula(paste('val ~',rhs,'| fid[year_id] + year_id')))
ladder <- do.call(rbind,lapply(names(forms),function(n) extract(fit(forms[[n]],d),d,n)))
if(legacy) {
ref <- read.csv('GBD2021_reference_results/four_model_robustness.csv',fileEncoding='UTF-8-BOM')
for(n in names(forms)) for(k in c('beta','se','ci_low','ci_high','p_value','within_r2','overall_r2')) {
 x <- ladder[ladder$model==n,k];y <- ref[ref$model==n,k]
 if(length(y)!=1) stop(paste(n,k,'reference matches',length(y)))
 stopifnot(isTRUE(all.equal(x,y,tolerance=1e-7,check.attributes=FALSE)))
}
}
write.csv(ladder,file.path(out,'four_models.csv'),row.names=FALSE)
three <- do.call(rbind,lapply(c(ASDR=2,ASIR=6,ASMR=1),function(id) {z<-prepare(id);extract(fit(forms$country_year_FE,z),z,names(c(ASDR=2,ASIR=6,ASMR=1))[match(id,c(2,6,1))])}))
if(legacy) {
expected <- read.csv('GBD2021_reference_figure_source/F1_three_outcome_models.csv',fileEncoding='UTF-8-BOM')
for(i in seq_len(nrow(three))) for(k in c('beta','se','ci_low','ci_high','p_value')) stopifnot(isTRUE(all.equal(three[i,k],expected[expected$metric==three$model[i],k],tolerance=1e-7,check.attributes=FALSE)))
}
write.csv(three,file.path(out,'three_outcomes.csv'),row.names=FALSE)
alt <- list(RCH=c('ehi13'),MCH=c('ehi14'),joint=c('ehi1','ehi13'))
a <- do.call(rbind,lapply(names(alt),function(n) {terms<-alt[[n]];m<-fit(as.formula(paste('val ~',paste(c(terms,controls),collapse='+'),'| fid + year_id')),d);do.call(rbind,lapply(terms,function(term) extract(m,d,n,term)))}))
write.csv(a,file.path(out,'alternative_exposures.csv'),row.names=FALSE)
# Published lead-lag diagnostic, with explicit within-country calendar alignment.
for(k in 1:2) {
 d[[paste0('lag',k)]] <- d$ehi1[match(paste(d$fid,d$year_id-k),paste(d$fid,d$year_id))]
 d[[paste0('lead',k)]] <- d$ehi1[match(paste(d$fid,d$year_id+k),paste(d$fid,d$year_id))]
}
z <- d[complete.cases(d[c('lag1','lag2','lead1','lead2')]),];stopifnot(nrow(z)==5481)
m <- fit(as.formula(paste('val ~',paste(c('ehi1','lag1','lag2','lead1','lead2',controls),collapse='+'),'| fid + year_id')),z)
b <- coef(m)[c('lead1','lead2')];V<-vcov(m)[c('lead1','lead2'),c('lead1','lead2')];F<-as.numeric(t(b)%*%solve(V,b))/2
if(legacy) stopifnot(abs(F-14.7465)<1e-4)
write.csv(data.frame(F=F,df1=2,df2=202,p_value=pf(F,2,202,lower.tail=FALSE),n_obs=nobs(m),n_countries=203),file.path(out,'published_lead_diagnostic.csv'),row.names=FALSE)
writeLines(capture.output(sessionInfo()),file.path(out,'sessionInfo.txt'))
cat('Models and existing lead diagnostic fitted for',edition,'\n')
# Existing country-exclusion variants, same primary fit and original IDs.
variants <- c(list(full_new_panel=character()),stats::setNames(lapply(c('230','222','237','245'),function(x)x),paste0('exclude_',c('230','222','237','245'))),list(exclude_all_four=c('230','222','237','245')))
influence <- do.call(rbind,lapply(names(variants),function(v) {z<-d[!as.character(d$fid)%in%variants[[v]],];cbind(sample_variant=v,excluded_ids=paste(variants[[v]],collapse=';'),extract(fit(forms$country_year_FE,z),z,'country_year_FE'))}))
write.csv(influence,file.path(out,'country_exclusions.csv'),row.names=FALSE)
