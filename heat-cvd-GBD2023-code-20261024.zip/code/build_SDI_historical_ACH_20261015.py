"""Build the scoped ACH/DALY historical delivery after the companion R refit.

No upstream climate or SSP outputs are written. All numerical outputs are
external; manuscript documents live in docs/SDI_historical_delivery_20261015.
"""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile
import numpy as np
import pandas as pd
from scipy.stats import t

ROOT = Path(__file__).resolve().parent
GROUPS = ['Low', 'Middle', 'High']
SPECS = ['primary_TWFE']
MODULES = ['zero_exposure']
CONTROLS = ['mean_value', 'SEV_agestd_diet_fruit', 'SEV_agestd_diet_veg',
            'SEV_agestd_metab_bmi', 'SEV_agestd_metab_fpg', 'SEV_agestd_metab_sbp']


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def check(condition, message):
    if not bool(condition):
        raise ValueError(message)


def interval(values):
    check(np.isfinite(values).all(), 'Nonfinite bootstrap target')
    return np.quantile(values, [.025, .975])


def project(a, trend):
    a = a-a.mean(1, keepdims=True)-a.mean(0, keepdims=True)+a.mean((0, 1), keepdims=True)
    if trend:
        time = np.arange(31, dtype=float)-15
        a -= np.einsum('ntk,t->nk', a, time)[:, None, :]*time[None, :, None]/(time@time)
    return a.reshape(-1, a.shape[-1])


def main(out):
    done = json.loads((out/'refit_completed.json').read_text(encoding='utf-8'))
    check(done['successful'] == 2000 and done['failed'] == 0, 'Incomplete refit')
    p = pd.read_csv(out/'estimation_panel.csv').sort_values(['fid', 'year_id']).reset_index(drop=True)
    c = pd.read_csv(out/'coefficients.csv')
    cv = pd.read_csv(out/'coefficient_covariances.csv')
    boot = pd.read_csv(out/'bootstrap_coefficients.csv')
    gi = pd.read_csv(out/'country_SDI_groups.csv').sort_values('fid').reset_index(drop=True)
    n, B = len(gi), done['draws']
    check(len(p) == 6293 and n == 203 and not p.duplicated(['fid', 'year_id']).any(), 'Sample/key')
    check(p.groupby('fid').year_id.apply(lambda y: list(y) == list(range(1990, 2021))).all(), 'Years')
    check(np.isfinite(p[['val', 'ehi1', *CONTROLS, 'ACH_natural', 'ACH_own_1990_1994']]).all().all(), 'Missing data')
    base = p[p.year_id.between(1990, 1994)].groupby('fid').mean_value.mean()
    cuts = np.quantile(base, [0, 1/3, 2/3, 1])
    reconstructed = pd.cut(base, cuts, labels=GROUPS, include_lowest=True).astype(str)
    check((reconstructed.to_numpy() == gi.group.to_numpy()).all(), 'SDI labels')
    check(np.max(np.abs(cuts-done['cuts'])) < 1e-12, 'SDI cuts')
    verification = []
    for spec in SPECS:
        for model in ['pooled', 'SDI_interaction']:
            terms = ['ehi1'] if model == 'pooled' else ['heat_'+g for g in GROUPS]
            z = p[['val', 'ehi1', *CONTROLS]].copy()
            if model == 'SDI_interaction':
                for g in GROUPS:
                    z['heat_'+g] = p.ehi1*(p.group == g)
            a = project(z[['val', *terms, *CONTROLS]].to_numpy().reshape(n, 31, -1), spec == 'country_trend_sensitivity')
            independent = np.linalg.lstsq(a[:, 1:], a[:, 0], rcond=None)[0]
            for j, term in enumerate(terms):
                row = c[(c.specification == spec) & (c.slope_model == model) & (c.term == term)].iloc[0]
                check(abs(row.beta-independent[j]) < 1e-8, 'Independent FWL beta mismatch')
                verification.append(dict(specification=spec, slope_model=model, term=term,
                    R_beta=row.beta, independent_Python_beta=independent[j], 
                    independent_absolute_difference=abs(row.beta-independent[j])))
    pd.DataFrame(verification).to_csv(out/'independent_coefficient_verification.csv', index=False)
    raw = Path(done['input'])
    check(hashlib.md5(raw.read_bytes()).hexdigest() == done['input_md5'], 'Raw input MD5')
    ref = 0.0
    # The legacy jsonlite manifest rounded numeric metadata to four decimals;
    # all calculations use the full-precision median reconstructed from rows.
    draws = pd.read_csv(out/'bootstrap_country_indices.csv').to_numpy(int)-1
    check(draws.shape == (B, n) and draws.min() >= 0 and draws.max() < n, 'Draw indices')
    W = np.zeros((B, n))
    np.add.at(W, (np.repeat(np.arange(B), n), draws.ravel()), 1)
    check((W.sum(1) == n).all(), 'Draw sizes')
    bc = {}
    for spec in SPECS:
        z = boot[boot.specification == spec].sort_values('draw')
        check(list(z.draw) == list(range(1, B+1)), 'Draw coverage')
        bc[spec] = z[['pooled', *GROUPS]].to_numpy()
    X = p.ehi1.to_numpy().reshape(n, 31)
    NAT = p.ACH_natural.to_numpy().reshape(n, 31)
    OWN = p.ACH_own_1990_1994.to_numpy().reshape(n, 31)
    deltas = dict(common_median=X-ref, zero_exposure=X.copy(), own_1990_1994=X-OWN,
                  constructed_natural=X-NAT)
    group = gi.group.to_numpy()
    select = {g: group == g for g in GROUPS}
    select['Overall'] = np.ones(n, dtype=bool)
    pairs = [('High', 'Low'), ('Middle', 'Low'), ('High', 'Middle')]
    # All periods retain equal country weights; bootstrap aggregates within each draw.
    window_ix = {'1990_2020': np.arange(31), '1990_1994': np.arange(5),
                 '2016_2020': np.arange(26, 31), '1990_1999': np.arange(10),
                 '2011_2020': np.arange(21, 31)}
    window_ix.update({str(y): np.array([y-1990]) for y in range(1990, 2021)})
    windows = {}
    for name, ix in window_ix.items():
        tw = np.zeros(31)
        tw[ix] = 1/len(ix)
        windows[name] = tw
    # A paired temporal change, not subtraction of separately computed CI limits.
    windows['change_2016_2020_vs_1990_1994'] = windows['2016_2020']-windows['1990_1994']
    exposure_rows, exposure_gaps, health_rows, health_gaps = [], [], [], []
    gcoef, gcov, pooled = {}, {}, {}
    for spec in SPECS:
        pooled[spec] = c[(c.specification == spec) & (c.slope_model == 'pooled')].iloc[0]
        gcoef[spec] = c[(c.specification == spec) & (c.slope_model == 'SDI_interaction')].set_index('term').loc[['heat_'+g for g in GROUPS], 'beta'].to_numpy()
        v = cv[(cv.specification == spec) & (cv.slope_model == 'SDI_interaction')]
        gcov[spec] = v.pivot(index='term1', columns='term2', values='covariance').loc[['heat_'+g for g in GROUPS], ['heat_'+g for g in GROUPS]].to_numpy()

    def summarize_target(v, subset):
        mask = select[subset]
        denom = W[:, mask].sum(1)
        check((denom > 0).all(), 'Empty resampled group')
        return float(v[mask].mean()), (W[:, mask]@v[mask])/denom

    def group_loadings(v, subset):
        mask = select[subset]
        point = np.array([v[mask & select[g]].sum()/mask.sum() for g in GROUPS])
        denom = W[:, mask].sum(1)
        rep = np.column_stack([(W[:, mask & select[g]]@v[mask & select[g]])/denom for g in GROUPS])
        return point, rep

    for window, tw in windows.items():
        v = X@tw
        exp = {g: summarize_target(v, g) for g in select}
        for g, (point, rep) in exp.items():
            low, high = interval(rep)
            exposure_rows.append(dict(window=window, group=g, estimate=point,
                bootstrap_ci_low=low, bootstrap_ci_high=high, n_country=int(select[g].sum()),
                unit='C_days', valid_draws=B))
        for hi, lo in pairs:
            low, high = interval(exp[hi][1]-exp[lo][1])
            exposure_gaps.append(dict(window=window, contrast=hi+'_minus_'+lo,
                estimate=exp[hi][0]-exp[lo][0], bootstrap_ci_low=low, bootstrap_ci_high=high, valid_draws=B))
        for module in MODULES:
            dx = deltas[module]@tw
            dsum = {g: summarize_target(dx, g) for g in select}
            loads = {g: group_loadings(dx, g) for g in select}
            for spec in SPECS:
                for model in ['pooled']:
                    values = {}
                    for g in select:
                        dpoint, drep = dsum[g]
                        if model == 'pooled':
                            cc = pooled[spec]
                            point = dpoint*cc.beta
                            ends = sorted([dpoint*cc.ci_low, dpoint*cc.ci_high])
                            rep = drep*bc[spec][:, 0]
                        else:
                            loading, rep_loading = loads[g]
                            point = float(loading@gcoef[spec])
                            se = np.sqrt(max(0, loading@gcov[spec]@loading))
                            ends = [point-t.ppf(.975, 202)*se, point+t.ppf(.975, 202)*se]
                            rep = np.sum(rep_loading*bc[spec][:, 1:], axis=1)
                        low, high = interval(rep)
                        values[g] = (point, rep)
                        health_rows.append(dict(module=module, specification=spec, slope_model=model,
                            window=window, group=g, delta_ACH=dpoint, rate_difference=point,
                            coefficient_ci_low=ends[0], coefficient_ci_high=ends[1],
                            bootstrap_ci_low=low, bootstrap_ci_high=high, valid_draws=B,
                            n_country=int(select[g].sum()), rate_unit='age_standardised_DALY_rate_per_100000'))
                    for hi, lo in pairs:
                        point = values[hi][0]-values[lo][0]
                        low, high = interval(values[hi][1]-values[lo][1])
                        dd = dsum[hi][0]-dsum[lo][0]
                        if model == 'pooled':
                            ends = sorted([dd*pooled[spec].ci_low, dd*pooled[spec].ci_high])
                        else:
                            loading = loads[hi][0]-loads[lo][0]
                            se = np.sqrt(max(0, loading@gcov[spec]@loading))
                            ends = [point-t.ppf(.975, 202)*se, point+t.ppf(.975, 202)*se]
                        health_gaps.append(dict(module=module, specification=spec, slope_model=model,
                            window=window, contrast=hi+'_minus_'+lo, delta_ACH_difference=dd,
                            rate_difference=point, coefficient_ci_low=ends[0], coefficient_ci_high=ends[1],
                            bootstrap_ci_low=low, bootstrap_ci_high=high, valid_draws=B))
    exposure = pd.DataFrame(exposure_rows)
    exposure.to_csv(out/'SDI_exposure_summary.csv', index=False)
    pd.DataFrame(exposure_gaps).to_csv(out/'SDI_exposure_gaps.csv', index=False)
    health = pd.DataFrame(health_rows)
    gaps = pd.DataFrame(health_gaps)
    health.to_csv(out/'historical_health_summary.csv', index=False)
    gaps.to_csv(out/'SDI_health_gaps.csv', index=False)
    # Full country-year output: pooled main/trend and explicitly separate group slopes.
    frames = []
    country = []
    support = []
    xmin, xmax = X.min(1), X.max(1)
    refs = dict(common_median=np.full_like(X, ref), zero_exposure=np.zeros_like(X),
                own_1990_1994=OWN, constructed_natural=NAT)
    for module in MODULES:
        within = (refs[module] >= xmin[:, None]) & (refs[module] <= xmax[:, None])
        for g, mask in select.items():
            support.append(dict(module=module, group=g, n_country=int(mask.sum()),
                supported_country_years=int(within[mask].sum()), n_obs=int(mask.sum()*31),
                countries_all_years_supported=int(within[mask].all(1).sum()),
                negative_delta_years=int((deltas[module][mask] < 0).sum())))
        for spec in SPECS:
            for model in ['pooled']:
                z = p[['fid', 'year_id', 'location_name', 'group', 'ehi1', 'val']].rename(
                    columns={'year_id': 'year', 'ehi1': 'ACH_observed', 'val': 'observed_DALY_rate'}).copy()
                z['module'], z['specification'], z['slope_model'] = module, spec, model
                z['reference_ACH'] = refs[module].ravel()
                z['delta_ACH'] = deltas[module].ravel()
                z['reference_within_country_observed_range'] = within.ravel()
                if model == 'pooled':
                    cc = pooled[spec]
                    beta, low, high = cc.beta, cc.ci_low, cc.ci_high
                else:
                    sub = c[(c.specification == spec) & (c.slope_model == model)].set_index('term')
                    beta, low, high = [z.group.map({g: sub.loc['heat_'+g, col] for g in GROUPS}).to_numpy()
                                       for col in ['beta', 'ci_low', 'ci_high']]
                z['beta'] = beta
                z['rate_difference'] = z.delta_ACH*beta
                a, b = z.delta_ACH*low, z.delta_ACH*high
                z['coefficient_ci_low'], z['coefficient_ci_high'] = np.minimum(a, b), np.maximum(a, b)
                z['rate_unit'] = 'age_standardised_CVD_DALY_rate_per_100000'
                frames.append(z)
                for (fid, name, g), h in z.groupby(['fid', 'location_name', 'group']):
                    dd = h.delta_ACH.mean()
                    # Recompute signed endpoints after country aggregation.
                    cc = pooled[spec] if model == 'pooled' else sub.loc['heat_'+g]
                    ends = sorted([dd*cc.ci_low, dd*cc.ci_high])
                    country.append(dict(fid=fid, location_name=name, group=g, module=module,
                        specification=spec, slope_model=model, ACH_mean=h.ACH_observed.mean(),
                        delta_ACH=dd, rate_difference=dd*cc.beta,
                        coefficient_ci_low=ends[0], coefficient_ci_high=ends[1]))
    full = pd.concat(frames, ignore_index=True)
    check(np.max(abs(full.rate_difference-full.delta_ACH*full.beta)) < 1e-10, 'Translation identity')
    check(not full.duplicated(['fid', 'year', 'module', 'specification', 'slope_model']).any(), 'Output keys')
    full.to_csv(out/'historical_ACH_DALYs_country_year.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(country).to_csv(out/'historical_country_means.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(support).to_csv(out/'reference_support.csv', index=False)
    dist = []
    for g, mask in select.items():
        for level, values in [('country_year', X[mask].ravel()), ('country_mean', X[mask].mean(1))]:
            q = np.quantile(values, [.05, .25, .5, .75, .95])
            dist.append(dict(group=g, level=level, n=len(values), mean=values.mean(),
                p05=q[0], p25=q[1], median=q[2], p75=q[3], p95=q[4], minimum=values.min(), maximum=values.max()))
    pd.DataFrame(dist).to_csv(out/'SDI_exposure_distributions.csv', index=False)
    print('GBD2023 zero-ACH summaries and independent coefficient verification complete.')

if __name__ == '__main__':
    import sys
    main(Path(sys.argv[1]))
